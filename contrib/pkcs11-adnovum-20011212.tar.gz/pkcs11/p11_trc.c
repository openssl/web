/* p11_trc.c -- OpenSSL pkcs11 code -- tracing. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* [have this first to assert it is self-contained.] */
#include "p11_trc.h"


/* 'empty translation unit' warning preventor */
int p11_trc_dummy = 'x';


#if defined(P11_TRACE)


#include "p11_ver.h"

#include <stdio.h>
#include <stdlib.h>


/* Note: these variables are implemeted as sigletons
** and are (at startup time) not thread save.
*/

static int p11_traceinitialized = 0;

static const char* p11_traceenv = "PKCS11_TRACE";

/* "pkcs11_trace.out" */
static const char* p11_tracefile = "pkcs11.trc";

static int p11_dotrace;

static FILE* p11_traceout;


/* De-initialize the singleton variables.
** [Currently not called.]
*/
static void p11_tracedeinitialize(void)
{
	if (!p11_traceinitialized) {
		return;
	}

	p11_traceinitialized = 0;

	p11_dotrace = 0;

	if (p11_traceout != NULL) {

		/* write a final message */
		fprintf(p11_traceout, "---- end\n");
		fflush(p11_traceout);

		fclose(p11_traceout);
		p11_traceout = NULL;
	}
}


/* Initialize the singleton variables. */
static void p11_traceinitialize(void)
{
	int dotrace;
	FILE* out;

	if (p11_traceinitialized) {
		return;
	}

	p11_traceinitialized++;

	p11_dotrace = 0;
	p11_traceout = NULL;

	/* [guard(s)] */
	if (p11_traceenv == NULL || p11_tracefile == NULL) {
		return;
	}

	/* get setting from environment */
	dotrace = getenv(p11_traceenv) != NULL;
	if (!dotrace) {
		return;
	}

	/* open the trace output file for append */
	out = fopen(p11_tracefile, "a");

	if (out == NULL) {
		return;
	}

	/* write an initial message */
	fprintf(out, "---- start %s\n", p11_version());
	fflush(out);

	p11_traceout = out;
	p11_dotrace = 1;

	/* Note: Not registering de-init code.
	** [p11_traceout closing is done in regular file-stream atexit-code.]
	** atexit(p11_tracedeinitialize);
	*/

	(void)p11_tracedeinitialize;
}


/* Tracing flag. */
int p11_doTrace(void)
{
	p11_traceinitialize();
	return p11_dotrace;
}


/* Tracing output. */
FILE* p11_traceOut(void)
{
	return p11_traceout;
}


#endif

