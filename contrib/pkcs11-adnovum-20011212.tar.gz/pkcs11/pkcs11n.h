/* pkcs11n.h -- wrapper to the PKCS#11 API specification. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* This interface sets the platform specific macros required by the PKCS#11
 * specification.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */

/* Note: only WIN32 platform is handled as special platform.  Everything
** else is assumed to follow the Unix model.  Especially WIN16 with its
** possible 'far' pointer declarations isn't handled (yet).  [See
** pkcs11s.h for a suggestion (but be sure to test it!).]
*/


/* [include guard] */
#ifndef PKCS11N_H
#define PKCS11N_H


/* __cplusplus check done in the PKCS#11 specification included below */


/* appreciate OpenSSL platform macro */
#if defined(OPENSSL_SYS_WIN32) && !defined(WIN32)
#define WIN32 1
#endif

/* appreciate compiler platform macro */
#if defined(_WIN32) && !defined(WIN32)
#define WIN32 1
#endif


/* packing pragma needed by PKCS#11 API, see PKCS#11 specification */
#if defined(WIN32)
#pragma pack(push, cryptoki, 1)
#endif


/* macros needed by PKCS#11 API, see PKCS#11 specification */

#if defined(WIN32)
#define CK_PTR *
#else
#define CK_PTR *
#endif

#if defined(WIN32)
#define CK_DEFINE_FUNCTION(returnType, name) \
  returnType __declspec(dllexport) name
#else
#define CK_DEFINE_FUNCTION(returnType, name) \
  returnType name
#endif

#if defined(WIN32)
#define CK_DECLARE_FUNCTION(returnType, name) \
  returnType __declspec(dllimport) name
#else
#define CK_DECLARE_FUNCTION(returnType, name) \
  returnType name
#endif

#if defined(WIN32)
#define CK_DECLARE_FUNCTION_POINTER(returnType, name) \
  returnType __declspec(dllimport) (* name)
#else
#define CK_DECLARE_FUNCTION_POINTER(returnType, name) \
  returnType (* name)
#endif

#if defined(WIN32)
#define CK_CALLBACK_FUNCTION(returnType, name) \
  returnType (* name)
#else
#define CK_CALLBACK_FUNCTION(returnType, name) \
  returnType (* name)
#endif

#ifndef NULL_PTR
#define NULL_PTR 0
#endif


/* the PKCS#11 specification */
#include "pkcs11s.h"


/* release packing pragma, see PKCS#11 specification */
#if defined(WIN32)
#pragma pack(pop, cryptoki)
#endif


#endif

