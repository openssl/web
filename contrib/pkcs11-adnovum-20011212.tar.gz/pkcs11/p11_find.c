/* p11_find.c -- OpenSSL pkcs11 code -- token object finder. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


#include "p11_int.h"


#include <stdlib.h>
#include <string.h>


/* data types */

/* done @ p11_int.h:
** typedef struct p11_RSAOBJECTSPECIFICATION_struct p11_RSAOBJECTSPECIFICATION;
*/
struct p11_RSAOBJECTSPECIFICATION_struct
{
	/* Array of name/value pairs that make up the object specification. */
	char** objectSpecification;

	/* Optional PIN getter callback and its data.
	** Note: we can't use pkcs11's callback data since that
	** 1) may be only temporary and 2) is only established later.
	*/
	int (*pinCallback)(
		char* pin,
		int pinsize,
		const char* usertypename,
		const char* slotname,
		const char* tokenname,
		void* data);
	void* pinCallbackData;

	/* Keep-resources / early-binding flag. */
	int keep;

	/* The resources. */
	PKCS11* pkcs11;
	CK_SESSION_HANDLE session;
};


/* TODO: remove the define directive */
#define PKCS11_OBJECTSPECIFICATIONSUPPORTOLDVERSIONS 1

#if defined(PKCS11_OBJECTSPECIFICATIONSUPPORTOLDVERSIONS)


/* Check if an rsaobjectspecification has (the) old version format. */
static int p11_rsaObjectSpecificationIsVersion1(
	const char* objectspecification)
{
	/* [guard(s)] */
	if (objectspecification == NULL) {
		return 0;
	}

	/* actually, we're testing whether it's not the current format */

	/* current must begin with "pkcs11:" (all lower case, colon) */
	if (strncmp(objectspecification, "pkcs11:", strlen("pkcs11:"))) {
		return 1;
	}

	/* current must use '=' */
	if (strchr(objectspecification, '=') == NULL) {
		return 1;
	}

	return 0;
}


/* Convert rsaobjectspecification from version 1 format. */
static char* p11_rsaObjectSpecificationConvertVersion1(
	const char* objectspecification)
{
	const char* p;
	char delimiter;
	int n, i;
	int size;
	char* q;

	/* 'old' parameters and its possible defaults */
	const char* library;
	const char* tokenlabel;
	const char* objectid;
	const char* objectlabel;
	int dologin = 0;

	/* [guard(s)] */
	if (objectspecification == NULL) {
		return NULL;
	}

	/* This format is assumed to look like:
	** "PKCS11|library|tokenlabel|objectid|objectlabel"
	*/

	/* Check the format.
	** Note that | and & are best suited as delimiter.
	** -, _, etc. often are part of filenames, : is needed as id-bytes delimiter.
	*/

	p = objectspecification;

	/*assert(strlen("PKCS11")==strlen("pkcs11"));*/

	if ((strncmp(p, "PKCS11", strlen("pkcs11")) &&
		strncmp(p, "pkcs11", strlen("pkcs11")))) {
bad :
		PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATIONCONVERTVERSION1,
			PKCS11_R_BAD_OBJECTSPECIFICATION);
		return NULL;
	}

	if (p11_isalnum(p[strlen("pkcs11")])) {
		goto bad;
	}

	p += strlen("pkcs11");

	delimiter = p[0];

/*
**	if (strchr("$/\\:", delimiter)) {
**		goto bad;
**	}
**
**	if (!isgraph((unsigned char)delimiter)) {
**		goto bad;
**	}
*/

	/* count delimiters */
	n = 0;
	for (i = 0; p[i] != '\0'; i++) {
		if (p[i] == delimiter) {
			n++;
		}
	}

	/* must be four of them. */
	if (n != 4) {
		goto bad;
	}

	p++;
	if (*p == '!') {
		dologin = 1;
		p++;
	}

	library = p;

	p = strchr(p, delimiter);
	if (p == NULL) {
		goto bad;
	}

	p++;
	tokenlabel = p;

	p = strchr(p, delimiter);
	if (p == NULL) {
		goto bad;
	}

	p++;
	objectid = p;

	p = strchr(p, delimiter);
	if (p == NULL) {
		goto bad;
	}

	p++;
	objectlabel = p;

	/* put the thing together */
	/* note that the strings aren't terminated */

	size = strlen(objectspecification) + 1;
	/* >strlen("library=&tokenlabel=&objectid=&objectlabel=&dologin=&") */
	/* +strlen("keep=true&cache=true&") */
	size += 128;

	q = (char*)OPENSSL_malloc(size);
	if (q == NULL) {
		PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATIONCONVERTVERSION1,
			PKCS11_R_OUT_OF_MEMORY);
		return NULL;
	}

	memset(q, 0, size);

	sprintf(q, "pkcs11:");

	/*assert(library != NULL)*/
	/*assert(tokenlabel != NULL)*/
	/*assert(objectid != NULL)*/
	/*assert(objectlabel != NULL)*/

	if (library[0] != delimiter) {
		sprintf(&q[strlen(q)], "library=%.*s&", (tokenlabel - library) - 1, library);
	}
	if (tokenlabel[0] != delimiter) {
		sprintf(&q[strlen(q)], "tokenlabel=%.*s&", (objectid - tokenlabel) - 1, tokenlabel);
	}
	if (objectid[0] != delimiter) {
		sprintf(&q[strlen(q)], "objectid=%.*s&", (objectlabel - objectid) - 1, objectid);
	}
	if (objectlabel[0] != '\0') {
		sprintf(&q[strlen(q)], "objectlabel=%s&", objectlabel);
	}
	if (dologin) {
		sprintf(&q[strlen(q)], "dologin=true&");
	}

	sprintf(&q[strlen(q)], "keep=true&");
	sprintf(&q[strlen(q)], "cache=true&");

	if (q[strlen(q) - 1] == '&') {
		q[strlen(q) - 1] = '\0';
	}

	return q;
}


#endif


/* Cache for objectspecifications. */
static LHASH* cached_objectspecifications = NULL;


static p11_RSAOBJECTSPECIFICATION* p11_handleObjectSpecificationCache(
	const char* objectspecification,
	p11_RSAOBJECTSPECIFICATION* ros)
{
	p11_RSAOBJECTSPECIFICATION* cached_ros;

	/* [guard(s)] */
	if (objectspecification == NULL || ros == NULL) {
		return NULL;
	}

	/* create a cache */
	if (cached_objectspecifications == NULL) {
		/* NOTE: never freed */
		cached_objectspecifications = p11_nvlh_new();
		if (cached_objectspecifications == NULL) {
			/*return NULL;*/
			return ros;
		}
	}

	cached_ros = (p11_RSAOBJECTSPECIFICATION*)p11_nvlh_retrieve(
		cached_objectspecifications,
		objectspecification);

	/* return cached */
	if (cached_ros != NULL) {
		return cached_ros;
	}

	/* add this to the cache */
	p11_nvlh_insert(
		cached_objectspecifications,
		objectspecification,
		ros);
	return ros;
}


/* Establish a p11_RSAOBJECTSPECIFICATION. */
p11_RSAOBJECTSPECIFICATION* p11_RSAOBJECTSPECIFICATION_new(
	const char* objectspecification)
{
	int converted = 0;
	p11_RSAOBJECTSPECIFICATION* ros = NULL;
	const char* keep;
	const char* cache;
	p11_RSAOBJECTSPECIFICATION* cached_ros;

	/* [guard(s)] */
	if (objectspecification == NULL) {
		PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_NEW, PKCS11_R_NULL_POINTER_PROVIDED);
		return NULL;
	}

#if defined(PKCS11_OBJECTSPECIFICATIONSUPPORTOLDVERSIONS)
	/* check for older format and translate */
	if (p11_rsaObjectSpecificationIsVersion1(objectspecification)) {
		objectspecification = p11_rsaObjectSpecificationConvertVersion1(
			objectspecification);
		if (objectspecification == NULL) {
			/* error code push already done at called function */
			return NULL;
		}
		converted = 1;
	}
#endif

	/* check format */
	/* just check the head */
	/* note: case sensitive */
	if (strncmp(objectspecification, "pkcs11:", strlen("pkcs11:"))) {
		PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_NEW,
			PKCS11_R_BAD_OBJECTSPECIFICATION);
		goto err;
	}

	ros = (p11_RSAOBJECTSPECIFICATION*)OPENSSL_malloc(sizeof(*ros));
	if (ros == NULL) {
		PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_NEW, PKCS11_R_OUT_OF_MEMORY);
		goto err;
	}

	memset(ros, 0, sizeof(*ros));

	/* slice the thing, so it's easier to access and return */
	ros->objectSpecification = p11_sliceNVPairs(&objectspecification[strlen("pkcs11:")]);
	if (ros->objectSpecification == NULL) {
		/* error code push already done at called function */
		goto err;
	}

	/* init */

	ros->pinCallback = NULL;
	ros->pinCallbackData = NULL;

	ros->keep = 0;
	ros->pkcs11 = NULL;
	ros->session = CK_INVALID_HANDLE;

	/* Set flag that indicates early/late binding. */
	keep = p11_findNVPair((const char* const*)ros->objectSpecification, "keep");
	if (keep != NULL && p11_booleanString(keep)) {
		ros->keep = 1;
	}

	/* check for caching */
	cache = p11_findNVPair((const char* const*)ros->objectSpecification, "cache");
	if (cache != NULL && p11_booleanString(cache)) {

		/* For the time being, we're only comparing exact object
		** specifications; we can't really 'normalize' them here
		** (i.e. we can't/don't want to match token names with
		** slot numbers, object labels with object ids, etc.
		*/
		cached_ros = p11_handleObjectSpecificationCache(
			objectspecification,
			ros);

		if (cached_ros != ros) {
			if (ros->objectSpecification != NULL) {
				p11_freeNVPairs(ros->objectSpecification);
			}
			memset(ros, 0, sizeof(*ros));
			OPENSSL_free(ros);

			ros = cached_ros;
		}
	}

	/* Set up early the resources we need if keep-flag is set. */
	if (ros->keep) {
		if (!p11_RSAOBJECTSPECIFICATION_setup(ros)) {
			goto err;
		}
	}

	/* release the possible copy */
	if (converted) {
		OPENSSL_free((char*)objectspecification);
		objectspecification = NULL;
	}

	return ros;

err :

	if (converted && objectspecification != NULL) {
		OPENSSL_free((char*)objectspecification);
	}
	if (ros != NULL) {
		OPENSSL_free(ros);
	}

	return NULL;
}


/* Free a p11_RSAOBJECTSPECIFICATION. */
void p11_RSAOBJECTSPECIFICATION_free(p11_RSAOBJECTSPECIFICATION* ros)
{
	const char* cache;

	/* NULL is, as always, ok */
	if (ros == NULL) {
		return;
	}

	/* check for caching */
	if (ros->objectSpecification != NULL) {
		cache = p11_findNVPair((const char* const*)ros->objectSpecification, "cache");
		if (cache != NULL && p11_booleanString(cache)) {
			/* don't free cached stuff, it'll still be needed */
			return;
		}
	}

	/* Tear down the resources we don't need. */
	/* ignore errors */
	p11_RSAOBJECTSPECIFICATION_teardown(ros);
	p11_discard_errors();

	if (ros->objectSpecification != NULL) {
		p11_freeNVPairs(ros->objectSpecification);
	}

	memset(ros, 0, sizeof(*ros));

	OPENSSL_free(ros);
}


/* Set PIN callback. */
int p11_RSAOBJECTSPECIFICATION_setPinCallback(
	p11_RSAOBJECTSPECIFICATION* ros,
	int (*pincallback)(
		char* pin,
		int pinsize,
		const char* usertypename,
		const char* slotname,
		const char* tokenname,
		void* data),
	void* pincallbackdata)
{
	/* [guard(s)] */
	if (ros == NULL) {
		PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_SETPINCALLBACK,
			PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	ros->pinCallback = pincallback;
	ros->pinCallbackData = pincallbackdata;

	/* OK. */
	return 1;
}


/* Get the keep-resources flag. */
int p11_RSAOBJECTSPECIFICATION_getKeep(p11_RSAOBJECTSPECIFICATION* ros)
{
	/* [guard(s)] */
	if (ros == NULL) {
		PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_GETKEEP,
			PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	return ros->keep;
}


/* Get the PKCS11 resource. */
PKCS11* p11_RSAOBJECTSPECIFICATION_getPKCS11(p11_RSAOBJECTSPECIFICATION* ros)
{
	/* [guard(s)] */
	if (ros == NULL) {
		PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_GETPKCS11,
			PKCS11_R_NULL_POINTER_PROVIDED);
		return NULL;
	}

	return ros->pkcs11;
}


/* Get the session resource. */
CK_SESSION_HANDLE p11_RSAOBJECTSPECIFICATION_getSession(
	p11_RSAOBJECTSPECIFICATION* ros)
{
	/* [guard(s)] */
	if (ros == NULL) {
		PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_GETSESSION,
			PKCS11_R_NULL_POINTER_PROVIDED);
		return CK_INVALID_HANDLE;
	}

	return ros->session;
}


/* Set up the resources we need (driver, session, login, ...). */
int  p11_RSAOBJECTSPECIFICATION_setup(p11_RSAOBJECTSPECIFICATION* ros)
{
	const char* library;
	const char* dologin;
	const char* tokenlabel;
	const char* slotnumber;
	CK_SLOT_ID slot, sslot, tslot, xslot;
	char* p;

	/* NULL is ok. */
	if (ros == NULL) {
		/* OK. */
		return 1;
	}

	/* A note to the p11_findNVPair casts: (some) compiler complains
	** about implicit consting on two levels.
	*/

	if (ros->pkcs11 == NULL) {

		/* Load the specified cryproki library. */

		/* Now this may return NULL, which will trigger the 'default library'. */
		library = p11_findNVPair((const char* const*)ros->objectSpecification, "library");
		ros->pkcs11 = PKCS11_new(library);

		if (ros->pkcs11 == NULL) {
			goto err;
		}

		/* propagate pin callback data */
		if (ros->pinCallback != NULL) {
			PKCS11_setPinCallback(ros->pkcs11, ros->pinCallback, ros->pinCallbackData);
		}

		dologin = p11_findNVPair((const char* const*)ros->objectSpecification, "dologin");
		if (dologin != NULL && p11_booleanString(dologin)) {
			PKCS11_setDoLogin(ros->pkcs11, 1);
		}
	}

	if (ros->session == CK_INVALID_HANDLE) {

		/* Note: we don't support unspecified tokenlabel/slotnumber,
		** unless there is only one token around.
		** That would require to loop over the slots and possibly
		** (if dologin-flag is set) try to log into every token that's there.
		*/
		/* TODO: support for tokenlabel=NULL with multiple tokens? */

		tokenlabel = p11_findNVPair(
			(const char* const*)ros->objectSpecification,
			"tokenlabel");
		slotnumber = p11_findNVPair(
			(const char* const*)ros->objectSpecification,
			"slotnumber");

		tslot = (CK_SLOT_ID)-1;
		if (tokenlabel != NULL) {
			/* get slot id by token */
			xslot = p11_findToken(ros->pkcs11, tokenlabel);

			/* check for error */
			if (xslot == (CK_SLOT_ID)-1) {
				PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_SETUP,
					PKCS11_R_CANNOT_FIND_TOKEN);
				goto err;
			} else {
				tslot = xslot;
			}
		}

		sslot = (CK_SLOT_ID)-1;
		if (slotnumber != NULL) {
			xslot = (CK_SLOT_ID)strtol(slotnumber, &p, 10);
			if (p == slotnumber) {
				PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_SETUP,
					PKCS11_R_BAD_SLOT_NUMBER);
				goto err;
			} else {
				sslot = xslot;
			}
		}

		slot = (CK_SLOT_ID)-1;
		if (tslot != (CK_SLOT_ID)-1) {
			slot = tslot;
		}
		if (sslot != (CK_SLOT_ID)-1) {
			/* [consistency check(s)] */
			if (slot != (CK_SLOT_ID)-1 && sslot != slot) {
				PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_SETUP,
					PKCS11_R_CONTRADICTING_TOKEN_NAME_AND_SLOT_NUMBER_SPECIFIED);
				goto err;
			}
			slot = sslot;
		}

		/* check if there is only one slot, get it */
		if (slot == (CK_SLOT_ID)-1) {
			slot = p11_findOneToken(ros->pkcs11);
			/* ignore error code(s) */
			p11_discard_errors();
		}

		if (slot == (CK_SLOT_ID)-1) {
			PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_SETUP,
				PKCS11_R_TOKEN_NOT_SPECIFIED);
			PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_SETUP,
				PKCS11_R_HINT_EITHER_SPECIFY_TOKEN_LABEL_OR_SLOT_NUMBER);
			goto err;
		}

		/* a new session */
		ros->session = p11_session_new(ros->pkcs11, slot);
		if (ros->session == CK_INVALID_HANDLE) {
			PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_SETUP,
				PKCS11_R_CANNOT_GET_NEW_SESSION);
			goto err;
		}

		/* Log in, if desired. */
		/* TODO: check login-required flag too? */
		if (ros->pkcs11->doLogin) {
			/* TODO: automatisize this? */
			if (!p11_login(ros->pkcs11, ros->session)) {
				PKCS11err(PKCS11_F_P11_RSAOBJECTSPECIFICATION_SETUP,
					PKCS11_R_LOGIN_FAILED);
				goto err;
			}
		}
	}

	/* OK. */
	return 1;

err :

	if (ros != NULL) {
		p11_RSAOBJECTSPECIFICATION_teardown(ros);
	}

	return 0;
}


/* Tear down the resources we don't need anymore
** (..., login, session, driver).
*/
int  p11_RSAOBJECTSPECIFICATION_teardown(p11_RSAOBJECTSPECIFICATION* ros)
{
	/* NULL is ok */
	if (ros == NULL) {
		/* OK. */
		return 1;
	}

	/* ignore return values */

	/* Note: We actually don't log out, we just free the session. */

	if (ros->session != CK_INVALID_HANDLE) {
		(void)p11_session_free(ros->pkcs11, ros->session);
		ros->session = CK_INVALID_HANDLE;
	}

	if (ros->pkcs11 != NULL) {
		(void)PKCS11_free(ros->pkcs11);
		ros->pkcs11 = NULL;
	}

	/* OK. */
	return 1;
}


/* Find an RSA token object. */
CK_OBJECT_HANDLE p11_findRSAObject(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_CLASS rsaobjectclass,
	const char* objectlabel,
	const void* objectid,
	int objectidsize)
{
	int objectidconverted = 0;
	int finalizesession = 0;
	CK_ATTRIBUTE at[4];
	int n;
	int dokeytype = 1;
	CK_KEY_TYPE ckk;
	CK_RV rv;
	CK_OBJECT_HANDLE objects[2];
	CK_ULONG count;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_FINDRSAOBJECT, PKCS11_R_NULL_POINTER_PROVIDED);
		return CK_INVALID_HANDLE;
	}
	/* [Note the CKO_, CKK_, etc. constants are somewhat in the same
	** ranges, and zero is part of it (endianess problem detection!).]
	*/
	if (
		rsaobjectclass != CKO_CERTIFICATE &&
		rsaobjectclass != CKO_PUBLIC_KEY &&
		rsaobjectclass != CKO_PRIVATE_KEY
	) {
		PKCS11err(PKCS11_F_P11_FINDRSAOBJECT, PKCS11_R_UNSUPPORTED_RSA_OBJECT_CLASS);
		return CK_INVALID_HANDLE;
	}
	/* [need not to check objectlabel, objectid, may be NULL] */
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_FindObjectsInit == NULL ||
		pkcs11->functionList->C_FindObjects == NULL ||
		pkcs11->functionList->C_FindObjectsFinal == NULL
	) {
		PKCS11err(PKCS11_F_P11_FINDRSAOBJECT, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return CK_INVALID_HANDLE;
	}

	/* Note: If the object is underspecified, return one object
	** (typically the first, see code below).
	** If the object is overspecified, return none.
	*/

	/* if (objectlabel == NULL && objectid == NULL) {
	** 	PKCS11err(PKCS11_F_P11_FINDRSAOBJECT, PKCS11_R_NO_OBJECT_TAG_SPECIFIED);
	** 	PKCS11err(PKCS11_F_P11_FINDRSAOBJECT,
	**		PKCS11_R_HINT_EITHER_OBJECTLABEL_OR_OBJECTID_REQUIRED);
	** 	return CK_INVALID_HANDLE;
	** }
	** if (objectlabel != NULL && objectid != NULL) {
	** 	PKCS11err(PKCS11_F_P11_FINDRSAOBJECT, PKCS11_R_TOO_MANY_OBJECT_TAGS_SPECIFIED);
	** 	PKCS11err(PKCS11_F_P11_FINDRSAOBJECT,
	**		PKCS11_R_HINT_EITHER_OBJECTLABEL_OR_OBJECTID_REQUIRED);
	** 	return CK_INVALID_HANDLE;
	** }
	*/

	/* convert object id, if necessary */
	if (objectid != NULL && objectidsize == -1) {
		objectid = (const void*)p11_idString(objectid, &objectidsize);
		if (objectid == NULL) {
			goto err;
		}
		objectidconverted = 1;
	}

	/* Find the (one) RSA object of secified type
	** (certificate, private key, public key).
	*/

	/* "class=certificate|publickey|privatekey&keytype=rsa&label=&id=" */

	/* A note to the (two) casts:
	** The attribute template array and the data it points to,
	** should, in the call to C_FindObjectsInit, be treated const.
	** However, unfortunately, the attribute template data type
	** (CK_ATTRIBUTE) is shared with writing functions such as
	** C_GetAttributeValue.
	*/

	/* A note on the string lengths: don't count the terminating nul. */

again :

	memset(at, 0, sizeof(at));
	n = 0;

	/* Note: we're neither using the flag attribute CKA_TOKEN,,
	** nor the flags CKA_PRIVATE, CKA_SENSITIVE, CKA_EXTRACTABLE,
	** CKA_NEVER_EXTRACTABLE, CKA_ALWAYS_SENSITIVE, nor the flags
	** CKA_ENCRYPT, CKA_DECRYPT, CKA_SIGN, CKA_VERIFY in the
	** search-template.
	*/

	at[n].type = CKA_CLASS;
	/* CKO_CERTIFICATE, CKO_PUBLIC_KEY, CKO_PRIVATE_KEY */
	at[n].pValue = (void*)(const void*)&rsaobjectclass;
	at[n].ulValueLen = sizeof(rsaobjectclass);
	n++;

	/* Note: The (RSA) key type attribute may not be set
	** on the token object (especially with certificates).
	*/
	if (dokeytype) {
		at[n].type = CKA_KEY_TYPE;
		ckk = CKK_RSA;
		at[n].pValue = (void*)(const void*)&ckk;
		at[n].ulValueLen = sizeof(ckk);
		n++;
	}

	if (objectlabel != NULL) {
		at[n].type = CKA_LABEL;
		at[n].pValue = (void*)(const void*)objectlabel;
		at[n].ulValueLen = strlen(objectlabel);
		n++;
	}

	if (objectid != NULL) {
		at[n].type = CKA_ID;
		at[n].pValue = (void*)(const void*)objectid;
		at[n].ulValueLen = objectidsize;
		n++;
	}

	/* Note: we're possibly overspecified or underspecified now.
	** Let the user decide.
	*/

	/* Note: not using CKA_CERTIFICATE_TYPE CKC_X_509. */

	rv = (*pkcs11->functionList->C_FindObjectsInit)(session, at, n);
	if (rv != CKR_OK) {
		P11_TRC1("C_FindObjectsInit returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_FINDRSAOBJECT, PKCS11_R_CANNOT_INIT_OBJECTFINDER);
		goto err;
	}
	finalizesession = 1;

	/* Note the specification states: "The object search operation will
	** only find objects that the session can view.  For example, an
	** object search in an R/W Public Session will not find any private
	** objects (even if one of the attributes in the search template
	** specifies that the search is for private objects)."
	** This requires us to use appropriate heuristics when to log in.
	*/

	/* Get the (hopefully) one object. */

	/*assert(sizeof(objects)/sizeof(*objects)>=2)*/
	objects[0] = CK_INVALID_HANDLE;
	objects[1] = CK_INVALID_HANDLE;
	count = 0;
	rv = (*pkcs11->functionList->C_FindObjects)(session, objects, 2, &count);
	if (rv != CKR_OK) {
		P11_TRC1("C_FindObjects returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_FINDRSAOBJECT, PKCS11_R_CANNOT_FIND_OBJECTS_FAILED);
		/* [must terminate the find operation] */
		goto err;
	}

	/* ignore error */
	rv = (*pkcs11->functionList->C_FindObjectsFinal)(session);
	finalizesession = 0;
	if (rv != CKR_OK) {
		/*EMPTY*/
		P11_TRC1("C_FindObjectsFinal returned %s", p11_errorName(rv));
	}

	if (count == 0) {
		P11_TRC0("[object not found]");

		/* try to find the object without keytype */
		if (dokeytype) {
			dokeytype = 0;
			goto again;
		}

		PKCS11err(PKCS11_F_P11_FINDRSAOBJECT, PKCS11_R_TOKEN_OBJECT_NOT_FOUND);
		goto err;
	}

	if (count > 1) {
		/*EMPTY*/
		P11_TRC0("[more than one object found]");

		/* TODO: assert one object? */
		/* TODO: shall we return an appropriate status? */
	}

	if (objectidconverted) {
		/* [ugly cast, sorry] */
		OPENSSL_free((void*)objectid);
		objectidconverted = 0;
	}

	/* TODO: what if many?  the first?  the best?  (what is the best?) */

	return objects[0];

err :

	if (finalizesession) {
		(*pkcs11->functionList->C_FindObjectsFinal)(session);
	}

	if (objectidconverted) {
		OPENSSL_free((void*)objectid);
	}

	return CK_INVALID_HANDLE;
}


/* Find a certificate and its contents in a rsa object specification. */
char* p11_findRSACertificateContents(
	p11_RSAOBJECTSPECIFICATION* ros,
	int* certsize)
{
	const char* objectlabel;
	const char* objectid;
	CK_OBJECT_HANDLE object;
	int size;
	void* cert = NULL;

	/* [guard(s)] */
	if (ros == NULL) {
		PKCS11err(PKCS11_F_P11_FINDRSACERTIFICATECONTENTS, PKCS11_R_NULL_POINTER_PROVIDED);
		return NULL;
	}

	/* Set up the required resources (unless done by early-binding),
	** e.g. cryproki library, session, login.
	*/

	if (!p11_RSAOBJECTSPECIFICATION_setup(ros)) {
		return NULL;
	}

	/* Note: Since we don't do any consistency checks on these values
	** anyhow (e.g. one must be set, but not both, etc.), we don't
	** need to consider doing it before setting up (logging in).
	*/

	objectlabel = p11_findNVPair((const char* const*)ros->objectSpecification, "objectlabel");
	objectid = p11_findNVPair((const char* const*)ros->objectSpecification, "objectid");

	object = p11_findRSAObject(
		ros->pkcs11,
		ros->session,
		CKO_CERTIFICATE,
		objectlabel,
		objectid,
		-1);
	if (object == CK_INVALID_HANDLE) {
		goto err;
	}

/* TODO: support for doing the public rsa operations on the hardware */
/* TODO: support for sensitive and non-extractable certificates */

	/* now get the certificate object's value */

	/* TODO: What about sensitive and non-extractable?
	** We don't really need the value...  (since it can be done
	** on the hardware...)
	*/

	size = 0;
	cert = p11_getObjectValue(ros->pkcs11, ros->session, object, &size);
	if (cert == NULL) {
		goto err;
	}

	/* Tear down the not-longer required resources (unless keep flag set). */
	if (!ros->keep) {
		p11_RSAOBJECTSPECIFICATION_teardown(ros);
	}

	*certsize = size;
	return cert;

err :

	if (cert != NULL) {
		(void)OPENSSL_free(cert);
	}

	/* Tear down the not-longer required resources (unless keep flag set). */
	if (ros != NULL && !ros->keep) {
		p11_RSAOBJECTSPECIFICATION_teardown(ros);
	}

	return NULL;
}


/* Find a private key in a rsa object specification. */
EVP_PKEY* p11_findRSAPrivateKeyEvp(p11_RSAOBJECTSPECIFICATION* ros)
{
	const char* objectlabel;
	const char* objectid;
	CK_OBJECT_HANDLE object, proxyobject;
	int idsize;
	void* id = NULL;
	EVP_PKEY* key = NULL;

	/* [guard(s)] */
	if (ros == NULL) {
		PKCS11err(PKCS11_F_P11_FINDRSAPRIVATEKEYEVP, PKCS11_R_NULL_POINTER_PROVIDED);
		return NULL;
	}

	/* Set up the required resources (unless done by early-binding),
	** e.g. cryproki library, session, login.
	*/

	if (!p11_RSAOBJECTSPECIFICATION_setup(ros)) {
		return NULL;
	}

	/* Note: Since we don't do any consistency checks on these values
	** anyhow (e.g. one must be set, but not both, etc.), we don't
	** need to consider doing it before setting up (logging in).
	*/

	objectlabel = p11_findNVPair((const char* const*)ros->objectSpecification, "objectlabel");
	objectid = p11_findNVPair((const char* const*)ros->objectSpecification, "objectid");

	/* try to find the key by id or label first */

	object = p11_findRSAObject(
		ros->pkcs11,
		ros->session,
		CKO_PRIVATE_KEY,
		objectlabel,
		objectid,
		-1);

	/* try to find the key certificate label then */

	if (object == CK_INVALID_HANDLE && objectid == NULL) {
		proxyobject = p11_findRSAObject(
			ros->pkcs11,
			ros->session,
			CKO_CERTIFICATE,
			objectlabel,
			objectid,
			-1);
		if (proxyobject == CK_INVALID_HANDLE) {
			goto err;
		}

		/* get certificate's id */
		idsize = 0;
		id = p11_getObjectId(
			ros->pkcs11,
			ros->session,
			proxyobject,
			&idsize);
		if (id == NULL) {
			goto err;
		}

		/* try to find the key by id */
		object = p11_findRSAObject(
			ros->pkcs11,
			ros->session,
			CKO_PRIVATE_KEY,
			NULL,
			id,
			idsize);
		OPENSSL_free(id);
		id = NULL;

		/* TODO: next thing to try may be to check
		** whether we're logged in and try or ask
		** to log in...
		*/
	}

	if (object == CK_INVALID_HANDLE) {
		goto err;
	}

	/* Instanciate an RSA method, get a private key handle on it. */
	key = p11_RSAPrivateKeyEvp(ros->pkcs11, ros->session, object, ros);
	if (key == NULL) {
		goto err;
	}

	/* Tear down the not-longer required resources (unless keep flag set). */
	if (!ros->keep) {
		p11_RSAOBJECTSPECIFICATION_teardown(ros);
	}

	return key;

err :

	if (id != NULL) {
		OPENSSL_free(id);
	}

	/* Tear down the not-longer required resources (unless keep flag set). */
	if (ros != NULL && !ros->keep) {
		p11_RSAOBJECTSPECIFICATION_teardown(ros);
	}

	return NULL;
}


/* Find a token by its label -- callback. */
static int p11_findTokenByLabel_cb(PKCS11* pkcs11, CK_SLOT_ID id, void* cbdata)
{
	const char* name = *(const char**)((void**)cbdata)[0];
	CK_SLOT_ID* slot = (CK_SLOT_ID*)((void**)cbdata)[1];
	CK_RV rv;
	CK_TOKEN_INFO tokeninfo;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_FINDTOKENBYLABEL_CB, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetTokenInfo == NULL
	) {
		PKCS11err(PKCS11_F_P11_FINDTOKENBYLABEL_CB, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* Note: (most probably in any case) we don't need to log in
	** to get _all_ available token information, do we?
	*/

	memset(&tokeninfo, 0, sizeof(tokeninfo));
	rv = (*pkcs11->functionList->C_GetTokenInfo)(id, &tokeninfo);

	if (rv == CKR_TOKEN_NOT_PRESENT) {
		/* go on */
		return 1;
	}

	if (rv != CKR_OK) {
		P11_TRC1("C_GetTokenInfo returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_FINDTOKENBYLABEL_CB, PKCS11_R_CANNOT_GET_TOKENINFO);
		/* stop, error */
		return 0;
	}

	if (!p11_stringEqual(
		tokeninfo.label,
		sizeof(tokeninfo.label),
		(const CK_UTF8CHAR*)name,
		-1)
	) {
		/* go on */
		return 1;
	}

	/* return first found */
	*slot = id;

	/* stop, found */
	return 0;
}


/* Find a Token. */
CK_SLOT_ID p11_findToken(PKCS11* pkcs11, const char* name)
{
	void* cbdata[2];
	CK_SLOT_ID slot;

	/* Note: there is unfortunately no notation for 'invalid slot'.
	** We're using '-1', assuming that, typically, it is not a valid slot id.
	*/

	/* TODO: or return it in a reference parameter and return a status? */

	/* [guard(s)] */
	/* Note: We're not considering empty token name here, it's done in the caller. */
	if (pkcs11 == NULL || name == NULL || name[0] == '\0') {
		return (CK_SLOT_ID)-1;
	}

	/* [callback data holder] */
	cbdata[0] = (void*)&name;
	slot = (CK_SLOT_ID)-1;
	cbdata[1] = (void*)&slot;

	p11_enumerateSlots(pkcs11, p11_findTokenByLabel_cb, (void*)cbdata);

	/* check for error */
	if (slot == (CK_SLOT_ID)-1) {
		PKCS11err(PKCS11_F_P11_FINDTOKEN, PKCS11_R_CANNOT_FIND_TOKEN);
		return (CK_SLOT_ID)-1;
	}

	return slot;
}


/* Find one single Token -- callback. */
static int p11_findOneToken_cb(PKCS11* pkcs11, CK_SLOT_ID id, void* cbdata)
{
	CK_SLOT_ID* firstslot = (CK_SLOT_ID*)((void**)cbdata)[0];
	int* count = (int*)((void**)cbdata)[1];

	CK_RV rv;
	CK_TOKEN_INFO tokeninfo;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_FINDONETOKEN_CB, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetTokenInfo == NULL
	) {
		PKCS11err(PKCS11_F_P11_FINDONETOKEN_CB, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* Note: (most probably in any case) we don't need to log in
	** to get _all_ available token information, do we?
	*/

	memset(&tokeninfo, 0, sizeof(tokeninfo));
	rv = (*pkcs11->functionList->C_GetTokenInfo)(id, &tokeninfo);

	if (rv == CKR_TOKEN_NOT_PRESENT) {
		/* skip, go on */
		return 1;
	}

	if (rv != CKR_OK) {
		P11_TRC1("C_GetTokenInfo returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_FINDONETOKEN_CB, PKCS11_R_CANNOT_GET_TOKENINFO);
		/* error, go on */
		return 1;
	}

	(*count)++;

	if (*count == 1) {
		*firstslot = id;
	}

	/* go on */
	return 1;
}


/* Find one single Token. */
CK_SLOT_ID p11_findOneToken(PKCS11* pkcs11)
{
	void* cbdata[2];
	CK_SLOT_ID slot;
	int count;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		return (CK_SLOT_ID)-1;
	}

	/* [callback data holder] */
	slot = (CK_SLOT_ID)-1;
	cbdata[0] = (void*)&slot;
	count = 0;
	cbdata[1] = (void*)&count;

	p11_enumerateSlots(pkcs11, p11_findOneToken_cb, (void*)cbdata);

	if (count == 0) {
		PKCS11err(PKCS11_F_P11_FINDONETOKEN, PKCS11_R_NO_TOKENS_AROUND);
		return (CK_SLOT_ID)-1;
	}

	if (count > 1) {
		PKCS11err(PKCS11_F_P11_FINDONETOKEN, PKCS11_R_MORE_THAN_ONE_TOKEN_AROUND);
		return (CK_SLOT_ID)-1;
	}

	return slot;
}

