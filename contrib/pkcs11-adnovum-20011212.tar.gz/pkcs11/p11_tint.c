/* p11_tint.c -- OpenSSL pkcs11 code -- unit testing, internal interface. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* interface to be tested */
#include "p11_int.h"


/* 'empty translation unit' warning preventor */
int p11_tint_dummy = 'x';


#if defined(PKCS11_TEST)


/* test helper macros */
#include "p11_test.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <errno.h>
#include <sys/stat.h>


static void p11_test_rmtmp(void);


/* Generate a temporary file name, singleton. */
static const char* p11_test_gettmp(void)
{
	static char* file = NULL;
	int size;
	struct stat st;

	/* return singleton if established */
	if (file != NULL) {
		return (const char*)file;
	}

	/* get a system generated temp name */

	size = L_tmpnam;
	file = (char*)OPENSSL_malloc(size);
	if (file == NULL) {
		goto fallback;
	}
	memset(file, 0, size);

	if (tmpnam(file) == NULL) {
		OPENSSL_free(file);
		goto fallback;
	}

	/* assert that that file doesn't exitst */
	if (stat(file, &st) != -1 || errno != ENOENT) {
		OPENSSL_free(file);
		goto fallback;
	}

	/* register tempfile removal */
	atexit(p11_test_rmtmp);

	return (const char*)file;

fallback :

	file = "p11_tint.out";
	return (const char*)file;
}


/* Remove the temporary file. */
static void p11_test_rmtmp(void)
{
	unlink(p11_test_gettmp());
}


/* Open singleton temporary file for reading or writing (truncated).
** Keep track of the FILE* to close it if necessary.
*/
static FILE* p11_test_temp_file(const char* mode)
{
	static const char* tmpfile = NULL;
	static FILE* file = NULL;

	if (tmpfile == NULL) {
		tmpfile = p11_test_gettmp();
		if (tmpfile == NULL) {
			/* this is really bad, can't recover */
			abort();
			/*NOTREACHED*/
		}
	}

	if (file != NULL) {
		fclose(file);
		file = NULL;
	}

	file = fopen(tmpfile, mode);
	if (file == NULL) {
		/* this is really bad, can't recover */
		perror(tmpfile);
		abort();
		/*NOTREACHED*/
	}

	return file;
}


/* Open singleton temporary file for writing, truncated. */
static FILE* p11_test_tempwriter_file(void)
{
	FILE* f;
	f = p11_test_temp_file("w");
	if (f == NULL) {
		abort();
		/*NOTREACHED*/
	}
	return f;
}


/* Open singleton temporary file for reading, as string. */
static const char* p11_test_tempreader_string(void)
{
	static int size = 1024;
	static char* buf = NULL;
	FILE* f;
	struct stat st;
	int newsize, fsize, n, i;

	f = p11_test_temp_file("r");
	if (f == NULL) {
		abort();
		/*NOTREACHED*/
	}

	if (fstat(fileno(f), &st) == -1) {
		perror("fstat");
		abort();
		/*NOTREACHED*/
	}

	newsize = size;
	fsize = st.st_size;
	while (newsize < fsize + 1) {
		newsize *= 4;
	}

	if (newsize != size || buf == NULL) {
		if (buf != NULL) {
			OPENSSL_free(buf);
		}
		size = newsize;
		buf = (char*)OPENSSL_malloc(size);
		if (buf == NULL) {
			abort();
			/*NOTREACHED*/
		}
	}

	memset(buf, 0, size);

	n = 0;
	while ((i = fread(&buf[n], 1, fsize - n, f)) != 0) {
		n += i;
	}
	buf[n] = '\0';

	if (ferror(f)) {
		perror("fread");
		abort();
		/*NOTREACHED*/
	}

	return buf;
}


/* Test internal interfaces of the OpenSSL PKCS#11 code.
** Returns the number of flaws; 0 is OK.
** Prints error diagnostics to 'out'.
*/
int p11_test_internal(FILE* out)
{
	/* required p11-test preamble */
	P11_TEST_VARS(out);


	/* ---- p11_lib.c */
	{
		/* p11_stringSize */
		P11_TEST_ASSERT(p11_stringSize((const CK_UTF8CHAR*)"ok  ", 4) == 2);
		P11_TEST_ASSERT(p11_stringSize((const CK_UTF8CHAR*)"ok\0 ", 4) == 2);
		P11_TEST_ASSERT(p11_stringSize((const CK_UTF8CHAR*)"ok\0o", 4) == 2);

		/* p11_stringEqual */
		P11_TEST_ASSERT(p11_stringEqual(
			(const CK_UTF8CHAR*)"ok  ", 4,
			(const CK_UTF8CHAR*)"ok      ", 8));
		P11_TEST_ASSERT(!p11_stringEqual(
			(const CK_UTF8CHAR*)"ok  ", 4,
			(const CK_UTF8CHAR*)"OK  ", 4));
		P11_TEST_ASSERT(p11_stringEqual(
			(const CK_UTF8CHAR*)"ok  ", 4,
			(const CK_UTF8CHAR*)"ok", -1));
		P11_TEST_ASSERT(!p11_stringEqual(
			(const CK_UTF8CHAR*)"ok  ", 4,
			(const CK_UTF8CHAR*)"ok      ", -1));

		/*
		** CK_ULONG p11_data2ulong(const void* value, int size)
		** Note: we can't (easily) test the failure case
		** since that would crash the program.
		*/
	}


	/* ---- p11_obj.c */


	/* ---- p11_dump.c */
	{
		CK_VERSION v;

		/* Note: we're not testing the higher level dump
		** functions such as p11_dumpLibrary, since that
		** requires a known (all-time-working) cryptoki
		** library.  We leave that one to the external
		** interface tests.
		*/

		/* p11_dumpString */
		P11_TEST_ASSERT(
			(p11_dumpString(
				(const CK_UTF8CHAR*)" a  test    ",
				12,
				p11_test_tempwriter_file()),
			!strcmp(" a  test", p11_test_tempreader_string())));

		/* p11_dumpVersion */
		v.major = v.minor = 2;
		P11_TEST_ASSERT(
			(p11_dumpVersion(&v, p11_test_tempwriter_file()),
			!strcmp("2.2", p11_test_tempreader_string())));
		v.major = v.minor = 0;
		P11_TEST_ASSERT(
			(p11_dumpVersion(&v, p11_test_tempwriter_file()),
			!strcmp("0.0", p11_test_tempreader_string())));

		/* p11_dumpNumber */
		P11_TEST_ASSERT(
			(p11_dumpNumber((CK_ULONG)2, p11_test_tempwriter_file()),
			!strcmp("2", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpNumber((CK_ULONG)0, p11_test_tempwriter_file()),
			!strcmp("0", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpNumber((CK_ULONG)-1, p11_test_tempwriter_file()),
			!strcmp("4294967295", p11_test_tempreader_string())));

		/* Note: p11_dumpNumberU and p11_dumpNumberI tested as part of p11_dumpNumberUI. */

		/* p11_dumpNumberUI */
		P11_TEST_ASSERT(
			(p11_dumpNumberUI((CK_ULONG)2, p11_test_tempwriter_file()),
			!strcmp("2", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpNumberUI(
				(CK_ULONG)CK_UNAVAILABLE_INFORMATION,
				p11_test_tempwriter_file()),
			!strcmp("<information unavailable>", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpNumberUI(
				(CK_ULONG)CK_EFFECTIVELY_INFINITE,
				p11_test_tempwriter_file()),
			!strcmp("<infinite>", p11_test_tempreader_string())));

		/* p11_dumpEmpty */
		P11_TEST_ASSERT(
			(p11_dumpEmpty(p11_test_tempwriter_file()),
			!strcmp("-", p11_test_tempreader_string())));

		/* p11_dumpHex */
		P11_TEST_ASSERT(
			(p11_dumpHex("", 0, ":", 0, p11_test_tempwriter_file()),
			!strcmp("", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpHex("\x01", 1, ":", 0, p11_test_tempwriter_file()),
			!strcmp("01", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpHex("\x01\xff", 2, ":", 0, p11_test_tempwriter_file()),
			!strcmp("01:ff", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpHex(
				"\xab\xcd\xef\x00\x20\x20\x20",
				7,
				"-",
				0,
				p11_test_tempwriter_file()),
			!strcmp("ab-cd-ef-00-20-20-20", p11_test_tempreader_string())));

		/* Note: p11_dumpHexS and p11_dumpHexP not separately tested. */

		/* p11_dumpBool */
		P11_TEST_ASSERT(
			(p11_dumpBool("\x00", 1, p11_test_tempwriter_file()),
			!strcmp("false", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpBool("\x01", 1, p11_test_tempwriter_file()),
			!strcmp("true", p11_test_tempreader_string())));
		/* [denormalized values] */
		P11_TEST_ASSERT(
			(p11_dumpBool("\x02", 1, p11_test_tempwriter_file()),
			!strcmp("true", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpBool("\xff", 1, p11_test_tempwriter_file()),
			!strcmp("true", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpBool("\x00\x00\x00\x00", 4, p11_test_tempwriter_file()),
			!strcmp("false", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpBool("\x00\x00\x00\x01", 4, p11_test_tempwriter_file()),
			!strcmp("true", p11_test_tempreader_string())));
		P11_TEST_ASSERT(
			(p11_dumpBool("", 0, p11_test_tempwriter_file()),
			!strcmp("false", p11_test_tempreader_string())));

		/* constant to name mapping not tested */
	}


	/* ---- p11_find.c */


	/* ---- p11_rsa.c */


	/* ---- p11_util.c */
	{
		unsigned short i, j;
		unsigned long k, l;

		/* p11_ntohs */
		i = 0x1234;
		j = p11_ntohs(i);
		P11_TEST_ASSERT(j == 0x1234 || j == 0x3412);

		/* p11_htons */
		j = p11_htons(j);
		P11_TEST_ASSERT(j == i);

		/* p11_ntohl */
		k = 0x12345678l;
		l = p11_ntohl(k);
		P11_TEST_ASSERT(
			l == 0x12345678l ||
			l == 0x78563412l ||
			l == 0x56781234l ||
			l == 0x34127856l);

		/* p11_htonl */
		l = p11_htonl(l);
		P11_TEST_ASSERT(l == k);

		/* p11_isupper */
		P11_TEST_ASSERT(p11_isupper('X'));
		P11_TEST_ASSERT(!p11_isupper('p'));
		P11_TEST_ASSERT(!p11_isupper('#'));

		/* p11_islower */
		P11_TEST_ASSERT(p11_islower('r'));
		P11_TEST_ASSERT(!p11_islower('A'));
		P11_TEST_ASSERT(!p11_islower('3'));
		P11_TEST_ASSERT(!p11_islower('\n'));
		P11_TEST_ASSERT(!p11_islower('\0'));

		/* p11_isalpha */
		P11_TEST_ASSERT(p11_isalpha('f'));
		P11_TEST_ASSERT(p11_isalpha('Z'));
		P11_TEST_ASSERT(!p11_isalpha('0'));
		P11_TEST_ASSERT(!p11_isalpha('_'));
		P11_TEST_ASSERT(!p11_isalpha('\xfc'));

		/* p11_isdigit */
		P11_TEST_ASSERT(p11_isdigit('3'));
		P11_TEST_ASSERT(!p11_isdigit('a'));
		P11_TEST_ASSERT(!p11_isdigit('-'));

		/* p11_isxdigit */
		P11_TEST_ASSERT(p11_isxdigit('9'));
		P11_TEST_ASSERT(p11_isxdigit('A'));
		P11_TEST_ASSERT(p11_isxdigit('f'));
		P11_TEST_ASSERT(!p11_isxdigit('g'));
		P11_TEST_ASSERT(!p11_isxdigit('-'));

		/* p11_isalnum */
		P11_TEST_ASSERT(p11_isalnum('g'));
		P11_TEST_ASSERT(p11_isalnum('6'));
		P11_TEST_ASSERT(!p11_isalnum('&'));

		/* p11_decCharValue */
		P11_TEST_ASSERT(p11_decCharValue('0') == 0);
		P11_TEST_ASSERT(p11_decCharValue('5') == 5);
		/* [error handling cases] */
		P11_TEST_ASSERT(p11_decCharValue('b') == 0);
		P11_TEST_ASSERT(p11_decCharValue('\xae') == 0);

		/* p11_hexCharValue */
		P11_TEST_ASSERT(p11_hexCharValue('9') == 9);
		P11_TEST_ASSERT(p11_hexCharValue('A') == 10);
		/* [error handling cases] */
		P11_TEST_ASSERT(p11_hexCharValue('%') == 0);

		/* p11_booleanString */
		P11_TEST_ASSERT(!p11_booleanString("false"));
		P11_TEST_ASSERT(p11_booleanString("true"));
		/* [denormalized values] */
		P11_TEST_ASSERT(!p11_booleanString("f"));
		P11_TEST_ASSERT(!p11_booleanString("no"));
		P11_TEST_ASSERT(!p11_booleanString("nil"));
		P11_TEST_ASSERT(!p11_booleanString("n"));
		P11_TEST_ASSERT(!p11_booleanString("0"));
		P11_TEST_ASSERT(p11_booleanString("t"));
		P11_TEST_ASSERT(p11_booleanString("yes"));
		P11_TEST_ASSERT(p11_booleanString("y"));
		P11_TEST_ASSERT(p11_booleanString("1"));
		P11_TEST_ASSERT(!p11_booleanString(NULL));
		P11_TEST_ASSERT(!p11_booleanString(""));
	}


	/* required p11-test epilogue */
	return P11_TEST_FLAWS();
}


/* TODO: call apps_startup()? */

/* Note: no trailing ;. */
P11_TEST_MAIN1(p11_test_internal)


#endif

