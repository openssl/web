/* p11_lib.c -- OpenSSL pkcs11 code -- general PKCS#11 stuff. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* [have this first to assert it is self-contained.] */
#include "p11_int.h"


#include <openssl/crypto.h>
#include <openssl/err.h>

#include <string.h>


/* Load the cryptoki library. */
int p11_load(PKCS11* pkcs11, const char* library)
{
	/* (assign stuff only after all error checks) */
	char* libcp = NULL;
	DSO* dso = NULL;
	CK_C_GetFunctionList getFunctionList = NULL;

	/* [guard(s)] */
	if (pkcs11 == NULL || library == NULL) {
		PKCS11err(PKCS11_F_P11_LOAD, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	/* get a copy. */
	libcp = OPENSSL_malloc(strlen(library) + 1);
	if (libcp == NULL) {
		PKCS11err(PKCS11_F_P11_LOAD, PKCS11_R_OUT_OF_MEMORY);
		goto err;
	}
	strcpy(libcp, library);

	/* Note: this is currently the only location here that calls
	** DSO_load() and DSO_bind_func().
	*/

	/* Note that DSO_load() typically will map "cryptoki" to "libcryptoki.so"
	** if not a path.  Use "./libcryptoki.so" notation to prevent this.
	*/
	dso = DSO_load(NULL, libcp, NULL, 0);
	if (dso == NULL) {
		/* Note: cryptoki library name is not considered security-sensitive. */
		P11_TRC1("DSO_load failed, library=%s", libcp);
		PKCS11err(PKCS11_F_P11_LOAD, PKCS11_R_CANNOT_LOAD_CRYPTOKI_LIBRARY);
		/* Give the user a hint also.  (I know, it's a Unix specific message.) */
		PKCS11err(PKCS11_F_P11_LOAD, PKCS11_R_HINT_LD_LIBRARY_PATH_POSSIBLY_NOT_OK);
		goto err;
	}

	/* Get the pkcs#11 cryptoki library C_GetFunctionList entry point.
	** This is currently the only one we require (the other is optional).
	** However, the standard says a call to C_Initialize is required first,
	** i.e. _before_ a C_GetFunctionList call.  So we try to retrieve that
	** entry point as well.
	*/

	/* [This function binds to a function inside a shared library.] */
	getFunctionList = (CK_C_GetFunctionList)DSO_bind_func(dso, "C_GetFunctionList");

	/* Catch 'symbol missing'. */
	if (getFunctionList == NULL) {
		P11_TRC1("DSO_bind_func failed, func=%s", "C_GetFunctionList");
		PKCS11err(PKCS11_F_P11_LOAD, PKCS11_R_CRYPTOKI_LIBRARY_ENTRY_POINT_NOT_FOUND);
		/* Give the user a hint also. */
		PKCS11err(PKCS11_F_P11_LOAD, PKCS11_R_HINT_POSSIBLY_NOT_A_CRYPTOKI_LIBRARY);
		goto err;
	}

	/*assert(pkcs11->library==NULL);*/
	pkcs11->library = libcp;
	pkcs11->dso = dso;
	pkcs11->getFunctionList = getFunctionList;

	/* Get the C_Initialize cryptoki library entry point also.
	** However it's not required by our interface,
	** so we don't indicate an error if not found.
	*/
	pkcs11->initialize = (CK_C_Initialize)DSO_bind_func(dso, "C_Initialize");

	/* OK. */
	return 1;

err :

	if (dso != NULL) {
		DSO_free(dso);
	}

	if (libcp != NULL) {
		OPENSSL_free(libcp);
	}

	return 0;
}


/* Unload the cryptoki library. */
int p11_unload(PKCS11* pkcs11)
{
	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_UNLOAD, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	if (pkcs11->dso != NULL) {
		DSO_free(pkcs11->dso);
		pkcs11->dso = NULL;
	}

	if (pkcs11->library != NULL) {
		OPENSSL_free(pkcs11->library);
		pkcs11->library = NULL;
	}

	/* OK. */
	return 1;
}


/* Call C_Initialize. */
static int p11_c_init(
	PKCS11* pkcs11,
	CK_C_Initialize initialize,
	int reinitialize)
{
	CK_RV rv;

	/* [unused(s)] */
	(void)pkcs11;
	(void)reinitialize;

	/* Skip in NULL. */
	if (initialize == NULL) {
		/* OK. */
		return 1;
	}

	/* Note: we're not (yet) providing mutex/locking information
	** to cryptoki here.
	*/
	/* TODO: do so */

	rv = (*initialize)(NULL);

	/* Ignore CKR_CRYPTOKI_ALREADY_INITIALIZED.
	** [In that case PKCS#11 says to finalize and reinitialize.]
	*/
	if (rv == CKR_CRYPTOKI_ALREADY_INITIALIZED) {
		/* EMPTY */
		P11_TRC0("[cryptoki already initialized]");

		/* Ignore anything else?  Probably not. */

	} else if (rv != CKR_OK) {
		P11_TRC1("cryptoki initialization returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		/* [don't use an own name in the static function] */
		PKCS11err(PKCS11_F_P11_C_INIT, PKCS11_R_PKCS11_INITIALIZE_FAILED);
		return 0;
	}

	/* OK. */
	return 1;
}


/* Initialize the cryptoki library. */
int p11_init(PKCS11* pkcs11)
{
	int initialized = 0;
	CK_RV rv;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_INIT, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (pkcs11->getFunctionList == NULL) {
		PKCS11err(PKCS11_F_P11_INIT, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* Init the cryptoki library as required by the specification.
	** However, allow C_GetFunctionList to be the only exported symbol,
	** in which case we initialize later.
	*/
	if (pkcs11->initialize != NULL) {
		initialized++;
		if (!p11_c_init(pkcs11, pkcs11->initialize, 0)) {
			return 0;
		}
	}

	/* Get the library function list.
	** Note that the specification states "C_GetFunctionList is the only
	** Cryptoki function which an application may call before calling C_Initialize.".
	*/
	pkcs11->functionList = NULL;
	rv = (*pkcs11->getFunctionList)(&pkcs11->functionList);
	if (rv != CKR_OK) {
		P11_TRC1("get cryptoki function list returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_INIT, PKCS11_R_PKCS11_GETFUNCTIONLIST_FAILED);
		return 0;
	}

	/* Init if not yet done. */
	if (
		!initialized &&
		pkcs11->functionList != NULL &&
		pkcs11->functionList->C_Initialize != NULL
	) {
		if (!p11_c_init(pkcs11, pkcs11->functionList->C_Initialize, 0)) {
			return 0;
		}
	}

	/* OK. */
	return 1;
}


/* Re-Initialize the cryptoki library. */
int p11_reinit(PKCS11* pkcs11)
{
	CK_C_Initialize initialize;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_REINIT, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	initialize = pkcs11->initialize;

	if (initialize == NULL) {
		if (pkcs11->functionList != NULL) {
			initialize = pkcs11->functionList->C_Initialize;
		}
	}

	/* OK if we can't call anything,
	** we assume it's not required then.
	*/
	if (initialize == NULL) {
		/* OK. */
		return 1;
	}

	return p11_c_init(pkcs11, initialize, 1);
}


/* De-initialize the cryptoki library. */
int p11_deinit(PKCS11* pkcs11)
{
	CK_RV rv;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_DEINIT, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	/* De-init PKCS#11 API. */
	if (pkcs11->functionList != NULL && pkcs11->functionList->C_Finalize != NULL) {
		rv = (*pkcs11->functionList->C_Finalize)(NULL);
		if (rv != CKR_OK) {
			P11_TRC1("C_Finalize returned %s", p11_errorName(rv));
			p11_push_CK_RV(rv);
			PKCS11err(PKCS11_F_P11_DEINIT, PKCS11_R_PKCS11_FINALIZE_FAILED);
			return 0;
		}
	}

	/* Reset the library function list. */
	pkcs11->functionList = NULL;

	/* OK. */
	return 1;
}


/* Enumerate all slots. */
int p11_enumerateSlots(
	PKCS11* pkcs11,
	int (*cb)(PKCS11*, CK_SLOT_ID, void*),
	void* cbdata)
{
	CK_RV rv;
	CK_ULONG slotcount = 0, i;
	CK_SLOT_ID* slotlist = NULL;

	/* Skip if some of it is NULL. */
	if (pkcs11 == NULL || cb == NULL) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetSlotList == NULL
	) {
		PKCS11err(PKCS11_F_P11_ENUMERATESLOTS, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		goto err;
	}

	slotcount = 0;
	rv = (*pkcs11->functionList->C_GetSlotList)(0, NULL, &slotcount);
	if (rv != CKR_OK) {
		P11_TRC1("C_GetSlotList returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_ENUMERATESLOTS, PKCS11_R_CANNOT_GET_SLOTINFO);
		goto err;
	}

	/* catch zero slots */
	if (slotcount == 0) {
		P11_TRC0("[no slots]");

		/* OK. */
		return 1;
	}

	slotlist = (CK_SLOT_ID*)OPENSSL_malloc(slotcount * sizeof(*slotlist));
	if (slotlist == NULL && slotcount != 0) {
		PKCS11err(PKCS11_F_P11_ENUMERATESLOTS, PKCS11_R_OUT_OF_MEMORY);
		goto err;
	}
	memset(slotlist, 0, slotcount * sizeof(*slotlist));

	rv = (*pkcs11->functionList->C_GetSlotList)(0, slotlist, &slotcount);
	if (rv != CKR_OK) {
		P11_TRC1("C_GetSlotList returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_ENUMERATESLOTS, PKCS11_R_CANNOT_GET_SLOTINFO);
		goto err;
	}

	/* loop over the slots */

	/* ['no slots' tracing done above] */

	for (i = 0; i < slotcount; i++) {
		/* Note that there may be slots without tokens, etc. */
		if (!(*cb)(pkcs11, slotlist[i], cbdata)) {
			/* Note: this is treated as 'friendly' 'cancel',
			** not as an error condition.
			*/
			break;
		}
	}

	OPENSSL_free(slotlist);
	slotlist = NULL;

	/* OK. */
	return 1;

err :

	if (slotlist != NULL) {
		OPENSSL_free(slotlist);
	}

	return 0;
}


/* Push PKCS#11 API error code to OpenSSL error stack. */
int p11_push_CK_RV(CK_RV rv)
{
	int reason;

	/* Check if it's OK, skip then. */
	if (rv == CKR_OK) {
		/* OK. */
		return 1;
	}

	/* Map error. */
	reason = p11_errorReason(rv);

	PKCS11err(PKCS11_F_P11_PUSH_CK_RV, reason);

	/* Push hint(s) (if any). */
	p11_push_hints(rv);

	(void)reason;

	/* Not OK (we're in an error condition). */
	return 0;
}


/* Push hint(s) (if any) on PKCS#11 API error code to OpenSSL error stack. */
void p11_push_hints(CK_RV rv)
{
	int hints[8];
	int i, n;

	/* get hints */
	n = p11_errorHints(rv, hints, sizeof(hints) / sizeof(*hints));

	/* Push _all_ matches. */

	for (i = 0; i < n; i++) {
		PKCS11err(PKCS11_F_P11_PUSH_HINTS, hints[i]);
	}
}


/* Discard OpenSSL errors (pop from error stack). */
void p11_discard_errors(void)
{
	ERR_clear_error();
}


/* PKCS#11 format string length. */
int p11_stringSize(const CK_UTF8CHAR* str, int size)
{
	/* The specification requires the strings to be padded with blanks. */
	/* However it states that the strings _should_ (not: must!) not be nul terminated. */

	int i;

	/* [guard(s)] */
	if (str == NULL || size <= 0) {
		return 0;
	}

	/* let us first locate a possible nul */
	for (i = 0; i < size; i++) {
		if (str[i] == '\0') {
			break;
		}
	}

	/* and adjust 'size' */
	if (i < size) {
		size = i;
	}

	/* now locate trailling blanks */
	for (i = size - 1; i >= 0; i--) {
		if (str[i] != ' ') {
			break;
		}
	}

	size = i + 1;

	/* Note: not trailling tabs ('\t', '\x09') or 'alternative' blanks ('\xa0'). */

	return size;
}


/* Check PKCS#11 format strings for equalness.
** Sizes of -1 specify non-PKCS#11 format strings.
*/
int p11_stringEqual(
	const CK_UTF8CHAR* a_str,
	int a_size,
	const CK_UTF8CHAR* b_str,
	int b_size)
{
	/* [guard(s)] */
	if (a_str == NULL && b_str == NULL) {
		return 1;
	}
	if (a_str == NULL || b_str == NULL) {
		return 0;
	}

	/* Normalize sizes. */
	if (a_size != -1) {
		a_size = p11_stringSize(a_str, a_size);
	} else {
		a_size = strlen((const char*)a_str);
	}
	if (b_size != -1) {
		b_size = p11_stringSize(b_str, b_size);
	} else {
		b_size = strlen((const char*)b_str);
	}

	/* Must match in length. */
	if (a_size != b_size) {
		return 0;
	}

	return !memcmp(a_str, b_str, a_size);
}


/* Copy PKCS#11 format string to C format.  Copy as much as possible. */
void p11_stringCopy(
	char* dst,
	int dst_size,
	const CK_UTF8CHAR* src,
	int src_size)
{
	int len;

	/* [guard(s)] */
	if (dst == NULL || dst_size <= 0) {
		return;
	}

	dst[0] = '\0';

	/* more guards */
	if (src == NULL || src_size < 0) {
		return;
	}

	len = p11_stringSize(src, src_size);

	if (len > dst_size - 1) {
		/* [does not fit] */
		len = dst_size - 1;
	}

	memcpy(dst, src, len);
	dst[len] = '\0';
}


/* Convert PKCS#11 token object data to CK_ULONG. */
CK_ULONG p11_data2ulong(const void* value, int size)
{
	CK_ULONG target;

	/* [guard(s)] */
	if (size != sizeof(target)) {
		return 0;
	}

	/* Copy the (potentially unaligned) input to get it properly aligned.
	** Note: Unaligned input is not a problem on cisc machines, but may
	** be one on risc machines.
	** Note: We don't want to rely on the PKCS#11 library returnin
	** properly aligned data for ulong types.
	*/
	memcpy(&target, value, sizeof(target));

	/* No endianess-conversion [target = p11_ntohl(target);] at this point.
	** The caller has to handle that itself (and of course has to know
	** whether endianess-conversion is required in that particular case.
	*/

	return target;
}

