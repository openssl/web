/* p11_util.c -- OpenSSL pkcs11 code -- general, non-PKCS#11 stuff. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* [have this first to assert it is self-contained.] */
#include "p11_int.h"


#include <string.h>


/* ---- Host data representation / endianess. */


/* Swap two bytes; location given by two indices. */
static void p11_swap(void* p, int i, int j) {
	unsigned char* q = (unsigned char*)p;
	unsigned char t = q[i];
	q[i] = q[j];
	q[j] = t;
}


/* Convert network-byte-order (big-endian) to host-byte-order, 2-byte values. */
unsigned short p11_ntohs(unsigned short n) {
	unsigned short test = 0x0102;
	switch ((int)*(unsigned char*)&test) {
	case 0x01 : /* big endian, network byte order */
		/* nothing to be done */
		break;
	case 0x02 : /* little endian */
		p11_swap((void*)&n, 0, 1);
		break;
	default : /* don't know and can't be! */
		break;
	};
	return n;
}


/* Convert host-byte-order to network-byte-order (big-endian), 2-byte values. */
unsigned short p11_htons(unsigned short n) {
	return p11_ntohs(n);
}


/* Convert network-byte-order (big-endian) to host-byte-order, 4-byte values. */
unsigned long p11_ntohl(unsigned long n) {
	unsigned long test = 0x01020304l;
	switch ((int)*(unsigned char*)&test) {
	case 0x01 : /* big endian, network byte order */
		/* nothing to be done */
		break;
	case 0x04 : /* little endian */
		p11_swap((void*)&n, 0, 3);
		p11_swap((void*)&n, 1, 2);
		break;
	case 0x03 : /* some mixture */
		p11_swap((void*)&n, 0, 2);
		p11_swap((void*)&n, 1, 3);
		break;
	case 0x02 : /* some other mixture */
		p11_swap((void*)&n, 0, 1);
		p11_swap((void*)&n, 2, 3);
		break;
	default : /* don't know and can't be! */
		break;
	};
	return n;
}


/* Convert host-byte-order to network-byte-order (big-endian), 4-byte values. */
unsigned long p11_htonl(unsigned long n) {
	return p11_ntohl(n);
}


/* ---- Character byte classification.
** Note: The following functions 1) do not rely on ASCII and
** 2) handle signed stuff in a robust manner (see signed chars!).
*/


/* alphabets */
static const char p11_uppers[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
static const char p11_lowers[] = "abcdefghijklmnopqrstuvwxyz";
static const char p11_digits[] = "0123456789";
static const char p11_xupper[] = "ABCDEF";
static const char p11_xlower[] = "abcdef";


/* Is upper case character. */
int p11_isupper(char c) {
	return c != '\0' && strchr(p11_uppers, c) != NULL;
}


/* Is lower case character. */
int p11_islower(char c) {
	return c != '\0' && strchr(p11_lowers, c) != NULL;
}


/* Is alphabetic (upper or lower case) character. */
int p11_isalpha(char c) {
	return p11_isupper(c) || p11_islower(c);
}


/* Is a digit. */
int p11_isdigit(char c) {
	return c != '\0' && strchr(p11_digits, c) != NULL;
}


/* Is a hexadecimal digit. */
int p11_isxdigit(char c) {
	return c != '\0' && (p11_isdigit(c) ||
		strchr(p11_xupper, c) != NULL || strchr(p11_xlower, c) != NULL);
}


/* Is alphabetic character or a digit. */
int p11_isalnum(char c) {
	return p11_isalpha(c) || p11_isdigit(c);
}


/* Decimal character value. */
int p11_decCharValue(char c) {
	const char* p;
	p = strchr(p11_digits, c);
	if (p != NULL) {
		return p - p11_digits;
	}
	return 0;
}


/* Hexadecimal character value. */
int p11_hexCharValue(char c) {
	const char* p;
	if (p11_isdigit(c)) {
		return p11_decCharValue(c);
	}
	p = strchr(p11_xupper, c);
	if (p != NULL) {
		return (p - p11_xupper) + 10;
	}
	p = strchr(p11_xlower, c);
	if (p != NULL) {
		return (p - p11_xlower) + 10;
	}
	return 0;
}


/* ---- Name/value pair list. */


static const char p11_nvDelimiter = '&', p11_nvDesignator = '=';


/* Slice a string into an array of name/value pairs. */
char** p11_sliceNVPairs(const char* nvList)
{
	/* Sorry for the suboptimally speaking variable names,
	** the code is kind of low level here...
	*/
	int n, i;
	char const *p, *q, *r, *s;
	char** a = NULL;
	int m = 0;

	/* [guard(s)] */
	if (nvList == NULL) {
		PKCS11err(PKCS11_F_P11_SLICENVPAIRS, PKCS11_R_NULL_POINTER_PROVIDED);
		return NULL;
	}

	/* Count the number of n/v pairs.
	** Count all (including the ones skipped while parsing
	** (ok to over-allocate a little).
	*/
	n = 0;
	p = nvList;
	while (p != NULL && p[0] != '\0') {
		n++;
		p = strchr(&p[1], p11_nvDelimiter);
	}
	/* Add a last and a null holder. */
	n += 2;

	a = (char**)OPENSSL_malloc(n * sizeof(*a));

	if (a == NULL) {

memerr :

		PKCS11err(PKCS11_F_P11_SLICENVPAIRS, PKCS11_R_OUT_OF_MEMORY);
		goto err;
	}
	/* [be deterministic...] */
	memset(a, 0, n * sizeof(*a));

	/* Parse. */
	m = 0;
	p = nvList;
	while (p != NULL && p[0] != '\0') {

		q = p;
		r = strchr(q, p11_nvDelimiter);

		/* point to next */
		if (r != NULL) {
			p = &r[1];
		} else {
			r = &q[strlen(q)];
			p = NULL;
		}

		/* skip empty slots */
		/* [allow at least leading (and trailing) separators] */
		if (r == q) {
			continue;
		}

		s = strchr(q, p11_nvDesignator);
		if (s == NULL || s > r) {
			/* skip illegal slots */
			/* continue; */

			/* reject illegal slots */
			PKCS11err(PKCS11_F_P11_SLICENVPAIRS, PKCS11_R_OUT_OF_MEMORY);
			goto err;
		}

		/* slice, copy */

		a[m] = (char*)OPENSSL_malloc((r - q) + 1);
		if (a == NULL) {
			goto memerr;
		}

		memcpy(a[m], q, r - q);
		a[m][r - q] = '\0';

		m++;
	}

	a[m] = NULL;

	return a;

err :

	if (a != NULL) {
		for (i = 0; i < m; i++) {
			if (a[i] != NULL) {
				OPENSSL_free(a[i]);
			}
		}
		OPENSSL_free(a);
	}

	return NULL;
}


/* Free an array of name/value pairs. */
void p11_freeNVPairs(char** nvList)
{
	int i;

	/* NULL is, as always, ok */
	if (nvList == NULL) {
		return;
	}

	for (i = 0; nvList[i] != NULL; i++) {
		OPENSSL_free(nvList[i]);
		/* [be deterministic...] */
		nvList[i] = NULL;
	}

	OPENSSL_free(nvList);
}


/* Find a name/value pair in an array of such.
** Return a pointer on the value.
*/
const char* p11_findNVPair(const char* const* nvList, const char* name)
{
	int i;

	/* [guard(s)] */
	if (nvList == NULL) {
		return NULL;
	}
	if (name == NULL || *name == '\0') {
		return NULL;
	}

	/* [return the first occurence] */
	for (i = 0; nvList[i] != NULL; i++) {
		if (
			!strncmp(nvList[i], name, strlen(name)) &&
			nvList[i][strlen(name)] == p11_nvDesignator
		) {
			/* Note: may be an empty string. */
			return &nvList[i][strlen(name) + 1];
		}
	}

	return NULL;
}


/* TODO: maybe a better suited name? */
/* Convert a string representing 'true' or 'false'. */
int p11_booleanString(const char* s)
{
	/* first cases, guard(s), (empty defaults to 'false') */
	if (s == NULL) {
		return 0;
	}
	if (s[0] == '\0') {
		return 0;
	}

	/* Have the two normalized cases 'false' and 'true' explicitly. */
	if (!strcmp(s, "false")) {
		return 0;
	}
	if (!strcmp(s, "true")) {
		return 1;
	}

	/* Note: it may be easier to define all the 'false' cases than the 'true' cases. */

	/* Do the rest just looking at the initial. */
	switch (s[0]) {

	/* false no nil n 0 "" ('empty' however handled above) */
	case 'f' :
	case 'n' :
	case '0' :
	case '\0' :
		return 0;

	/* true t yes y 1 */
	case 't' :
	case 'y' :
	case '1' :
		return 1;
	}

	/* defaults to 'false' */
	return 0;
}


/* ---- Name/value hash table. */


typedef struct {
	char* key; /* name, key.  a copy. */
	const void* data; /* data, any pointer. */
} p11_NV;


typedef struct {
	void (*func)(const char* key, const void* data);
	void (*funcx)(const char* key, const void* data, const void* arg);
	const void* arg;
} p11_NV_DOALL;


/* N/V-hash hash function, string hash on the key. */
static unsigned long p11_nvlh_hash(const void* a_void) {

	/* [guard] */
	if (a_void == NULL) {
		return 0;
	}

	/* catch null keys. */
	if (((p11_NV const*)a_void)->key == NULL) {
		return 0;
	}

	/* the usual string hash. */
	return lh_strhash(((p11_NV const*)a_void)->key);
}


/* N/V-hash key compare function. */
static int p11_nvlh_cmp(const void* a_void, const void* b_void) {

	/* [guards] */
	if (a_void == NULL || b_void == NULL) {
		return 0;
	}

	/* catch null keys. */
	if (((p11_NV const*)a_void)->key == NULL && ((p11_NV const*)b_void)->key == NULL) {
		return 0;
	}
	if (((p11_NV const*)a_void)->key == NULL) {
		return -1;
	}
	if (((p11_NV const*)b_void)->key == NULL) {
		return 1;
	}

	/* case-sensitive string compare. */
	return strcmp(((p11_NV const*)a_void)->key, ((p11_NV const*)b_void)->key);
}


/* Get a new N/V-hash. */
LHASH* p11_nvlh_new(void) {
	return lh_new(p11_nvlh_hash, p11_nvlh_cmp);
}


/* N/V-hash pre-delete. */
static void p11_nvlh_pre_delete(p11_NV* nv) {
	/* [guard] */
	if (nv == NULL) {
		return;
	}

	if (nv->key != NULL) {
		OPENSSL_free(nv->key);
		nv->key = NULL;
	}

	OPENSSL_free(nv);
}


/* N/V-hash pre-delete wrapper. */
static void p11_nvlh_pre_delete_func(const void* data) {
	/* [guard] */
	if (data == NULL) {
		return;
	}

	p11_nvlh_pre_delete((p11_NV*)data);
}


/* Free a N/V-hash. */
void p11_nvlh_free(LHASH* nvlh) {
	if (nvlh == NULL) {
		return;
	}

	/* clean up.  this requires that no more calls are
	** done on the nv data while in lh_free!
	*/
	lh_doall(nvlh, p11_nvlh_pre_delete_func);

	lh_free(nvlh);
}


/* Insert a N/V-hash value. */
void p11_nvlh_insert(LHASH* nvlh, const char* key, const void *data) {
	p11_NV* nv;

	/* [guard] */
	if (nvlh == NULL) {
		return;
	}

	/* clear possible contents first. */
	p11_nvlh_delete(nvlh, key);

	nv = (p11_NV*)OPENSSL_malloc(sizeof(*nv));
	if (nv == NULL) {
		/* TODO: propagate error. */
		return;
	}

	if (key != NULL) {
		/* copy the name/key. */
		nv->key = (char*)OPENSSL_malloc(strlen(key) + 1);
		if (nv->key == NULL) {
			OPENSSL_free(nv);
			/* TODO: propagate error. */
			return;
		}
		strcpy(nv->key, key);
	} else {
		nv->key = NULL;
	}

	nv->data = data;

	/* NOTE: lh_insert does not return any malloc errors,
	** so we can't really avoid leaking in such cases.
	** Neither can we return an error status.
	*/
	lh_insert(nvlh, nv);
}


/* N/V-hash pre-retrieve. */
static p11_NV* p11_nvlh_pre_retrieve(LHASH* nvlh, const char* key) {
	p11_NV nv;

	/* [guard] */
	if (nvlh == NULL) {
		return NULL;
	}

	nv.key = (char*)key;
	nv.data = NULL;

	return (p11_NV*)lh_retrieve(nvlh, &nv);
}


/* Delete a N/V-hash value. */
void p11_nvlh_delete(LHASH* nvlh, const char* key) {
	p11_NV* nv;

	/* [guard] */
	if (nvlh == NULL) {
		return;
	}

	nv = p11_nvlh_pre_retrieve(nvlh, key);
	if (nv == NULL) {
		/* TODO: propagate status? */
		return;
	}

	lh_delete(nvlh, nv);

	/* must be done after lh_delete since that one still acts on nv. */
	p11_nvlh_pre_delete(nv);
}


/* Retrieve a N/V-hash value. */
const void* p11_nvlh_retrieve(LHASH* nvlh, const char* key) {
	p11_NV* nv;

	/* [guard] */
	if (nvlh == NULL) {
		return NULL;
	}

	nv = p11_nvlh_pre_retrieve(nvlh, key);
	if (nv == NULL) {
		return NULL;
	}

	return nv->data;
}


/* N/V-hash do-all wrapper. */
static void p11_nvlh_doall_func(const void* data, const void* arg) {
	/* [guards] */
	if (data == NULL || arg == NULL) {
		return;
	}

	/* (call zero, one or two functions) */
	if (((p11_NV_DOALL*)arg)->func != NULL) {
		(*((p11_NV_DOALL*)arg)->func)(
			((p11_NV*)data)->key,
			((p11_NV*)data)->data);
	}
	if (((p11_NV_DOALL*)arg)->funcx != NULL) {
		(*((p11_NV_DOALL*)arg)->funcx)(
			((p11_NV*)data)->key,
			((p11_NV*)data)->data,
			((p11_NV_DOALL*)arg)->arg);
	}
}


/* N/V-hash value pairs enumeration. */
void p11_nvlh_doall(
	LHASH* nvlh,
	void (*func)(const char* key, const void* data)
) {
	p11_NV_DOALL d;

	/* [guards] */
	if (nvlh == NULL || func == NULL) {
		return;
	}

	d.func = func;
	d.funcx = NULL;
	d.arg = NULL;

	lh_doall_arg(
		nvlh,
		(void (*)(const void*, void*))p11_nvlh_doall_func,
		&d);
}


/* N/V-hash value pairs enumeration. */
void p11_nvlh_doall_arg(
	LHASH* nvlh,
	void (*func)(const char* key, const void* data, const void* arg),
	const void* arg
) {
	p11_NV_DOALL d;

	/* [guards] */
	if (nvlh == NULL || func == NULL) {
		return;
	}

	d.func = NULL;
	d.funcx = func;
	d.arg = arg;

	lh_doall_arg(
		nvlh,
		(void (*)(const void*, void*))p11_nvlh_doall_func,
		&d);
}

