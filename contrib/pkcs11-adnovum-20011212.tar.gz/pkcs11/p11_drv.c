/* p11_drv.c -- OpenSSL pkcs11 code -- driver part. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* This source file implements the public API to the OpenSSL pkcs11 code,
 * which is declared in pkcs11.h.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* [in p11_drv.c] */
/* [have this first to assert it is self-contained.] */
#include "pkcs11.h"


/* -- Notes concerning tracing:
**
** Keep the external functions well traced on entry and exit.
** Don't trace calls to internal openssl pkcs11 functions.
**
** In internal openssl pkcs11 functions, trace results obtained
** from cryptoki, however, don't need to trace too detailed.
** Don't trace expected stuff (e.g. CKR_ATTRIBUTE_TYPE_INVALID),
** trace the unexpected (e.g. 'no slots').
** Don't trace pointer guards and internal inconsistencies in
** internal openssl pkcs11 functions, these ought to be trapped
** in testing.
**
** Don't trace memory exhaustion, keep the tracing to the
** PKCS#11 specifics.
*/


#include "p11_int.h"

#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>

#include <string.h>


/* Init the PKCS11 data struct. */
static void p11_pkcs11_init(PKCS11* pkcs11)
{
	/* Keep sync'ed with the data type definition! */

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		return;
	}

	pkcs11->library = (char*)NULL;
	pkcs11->dso = (DSO*)NULL;
	pkcs11->getFunctionList = (CK_C_GetFunctionList)NULL;
	pkcs11->initialize = (CK_C_Initialize)NULL;
	pkcs11->functionList = (CK_FUNCTION_LIST_PTR)NULL;
	pkcs11->pinCallback = (int (*)(char*, int, const char*, const char*, const char*, void*))NULL;
	pkcs11->pinCallbackData = (void*)NULL;
	pkcs11->doLogin = (int)0;
}


/* Establish a PKCS#11 driver for a specified cryptoki library.
** Returns NULL on failure (use ERR_print_errors or similar in that case).
** Note: You can't use the pkcs11 handle returned by PKCS11_new after
** a fork; in that case you have to get another one.
*/
PKCS11* PKCS11_new(const char* library)
{
	PKCS11* pkcs11 = NULL;

	/* Note: cryptoki library name is not considered security-sensitive. */
	P11_TRC1("PKCS11_new(library=%s)", (library != NULL ? library : "<null>"));

	/* default */
	if (library == NULL) {
		/* This gets by DSO_load and gets expanded
		** (e.g. "cryptoki" --> "libcryptoki.so").
		*/
		library = "cryptoki";
	}

	/* [guard(s)] */
	/* Note: library==NULL now means 'default' (typically libcryptoki.so). */
	/* if (library == NULL) {
	** 	PKCS11err(PKCS11_F_PKCS11_NEW, PKCS11_R_NULL_POINTER_PROVIDED);
	** 	goto err;
	** }
	*/

	pkcs11 = (PKCS11*)OPENSSL_malloc(sizeof(*pkcs11));
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_PKCS11_NEW, PKCS11_R_OUT_OF_MEMORY);
		goto err;
	}

	/* init, be deterministic */
	memset(pkcs11, 0, sizeof(*pkcs11));

	/* init, the proper way */
	p11_pkcs11_init(pkcs11);

	/* Load the library and resolve the directly needed symbols. */
	if (!p11_load(pkcs11, library)) {
		goto err;
	}

	/* Init the library. */
	if (!p11_init(pkcs11)) {
		goto err;
	}

	P11_TRC1("[PKCS11_new returns %p]", (const void*)pkcs11);
	return pkcs11;

err :

	if (pkcs11 != NULL) {
		OPENSSL_free(pkcs11);
	}

	P11_TRC0("[PKCS11_new returns <null>]");
	return NULL;
}


/* De-initialize and free the cryptoki library handle. */
int PKCS11_free(PKCS11* pkcs11)
{
	P11_TRC1("PKCS11_free(pkcs11=%p)", (const void*)pkcs11);

	/* NULL argument is, as always, ok. */
	if (pkcs11 == NULL) {
		/* OK. */
		P11_TRC0("[PKCS11_free returns OK]");
		return 1;
	}

	/* De-init the library. */
	/* Ignore possible error, don't stop. */
	p11_deinit(pkcs11);
	p11_discard_errors();

	/* Unload the library. */
	/* Ignore possible error, don't stop. */
	p11_unload(pkcs11);
	p11_discard_errors();

	/* init again, be deterministic */
	memset(pkcs11, 0, sizeof(*pkcs11));

	OPENSSL_free(pkcs11);

	/* OK. */
	P11_TRC0("[PKCS11_free returns OK]");
	return 1;
}


/* Re-initialize the cryptoki library. */
int PKCS11_reinit(PKCS11* pkcs11)
{
	P11_TRC1("PKCS11_reinit(pkcs11=%p)", (const void*)pkcs11);

	if (!p11_reinit(pkcs11)) {
		P11_TRC0("[PKCS11_reinit returns NOT OK]");
		return 0;
	}

	/* OK. */
	P11_TRC0("[PKCS11_reinit returns OK]");
	return 1;
}


/* Set login behavior. */
int PKCS11_setDoLogin(PKCS11* pkcs11, int dologin)
{
	P11_TRC2("PKCS11_setDoLogin(pkcs11=%p, dologin=%d)", (const void*)pkcs11, dologin);

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_PKCS11_SETDOLOGIN, PKCS11_R_NULL_POINTER_PROVIDED);
		P11_TRC0("[PKCS11_setDoLogin returns NOT OK]");
		return 0;
	}

	pkcs11->doLogin = !!dologin;

	/* OK. */
	P11_TRC0("[PKCS11_setDoLogin returns OK]");
	return 1;
}


/* Set PIN callback. */
int PKCS11_setPinCallback(
	PKCS11* pkcs11,
	int (*pincallback)(
		char* pin,
		int pinsize,
		const char* usertypename,
		const char* slotname,
		const char* tokenname,
		void* data),
	void* pincallbackdata)
{
	P11_TRC3("PKCS11_setPinCallback(pkcs11=%p, pincallback=%p, pincallbackdata=%p)",
		(const void*)pkcs11, (const void*)pincallback, (const void*)pincallbackdata);

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_PKCS11_SETPINCALLBACK, PKCS11_R_NULL_POINTER_PROVIDED);
		P11_TRC0("[PKCS11_setPinCallback returns NOT OK]");
		return 0;
	}

	pkcs11->pinCallback = pincallback;
	pkcs11->pinCallbackData = pincallbackdata;

	/* OK. */
	P11_TRC0("[PKCS11_setPinCallback returns OK]");
	return 1;
}


/* Dump information about PKCS#11 library, slots, tokens and token objects. */
int PKCS11_dumpInfo(PKCS11* pkcs11, FILE* out)
{
	P11_TRC2("PKCS11_dumpInfo(pkcs11=%p, out=%p)", (const void*)pkcs11, (const void*)out);

	/* Skip this if some of it is NULL. */
	if (pkcs11 == NULL || out == NULL) {
		/* OK. */
		P11_TRC0("[PKCS11_dumpInfo returns OK]");
		return 1;
	}

	if (!p11_dumpLibrary(pkcs11, out)) {
		/* [no (additional) own error code] */
		P11_TRC0("[PKCS11_dumpInfo returns NOT OK]");
		return 0;
	}

	if (!p11_dumpSlots(pkcs11, 1, out)) {
		P11_TRC0("[PKCS11_dumpInfo returns NOT OK]");
		return 0;
	}

	/* OK. */
	P11_TRC0("[PKCS11_dumpInfo returns OK]");
	return 1;
}


/* Translate pin callbacks. */
static int p11_pincallback_translator(
	char* pin,
	int pinsize,
	const char* usertypename,
	const char* slotname,
	const char* tokenname,
	void* data)
{
	/* [Note: MSVC may complain about converting
	** function pointers to data pointers and back.]
	*/
	int (*pin_cb)(char* buf, int size, int rwflag, void* userdata) =
		(int (*)(char*, int, int, void*))((void**)data)[0];
	void* userdata = ((void**)data)[1];

	/* [unused(s)] */
	(void)usertypename;
	(void)slotname;
	(void)tokenname;

	return (*pin_cb)(pin, pinsize, 0, userdata);
}


/* Get a PKCS#11 X509 RSA certificate. */
/* [Function name: OpenSSL format.] */
X509* PKCS11_get_cert(
	const char* specification,
	pem_password_cb* pincallback,
	void* pincallbackdata)
{
	p11_RSAOBJECTSPECIFICATION* ros;
	char* cert;
	int certsize;
	unsigned char* tasn1;
	X509* x509;
	void* cbdata[2];

	/* Note: 'specification' is considered security-sensitive.
	** It may contain password information.
	** So we don't trace it.
	*/
	P11_TRC3("PKCS11_get_cert(specification=%s, pincallback=%p, pincallbackdata=%p)",
		/* (specification != NULL ? specification : "<null>"), */
		"<suppressed>",
		(const void*)pincallback,
		(const void*)pincallbackdata);

	/* [guard(s)] */
	if (specification == NULL) {
		PKCS11err(PKCS11_F_PKCS11_GET_CERT, PKCS11_R_NULL_POINTER_PROVIDED);
		P11_TRC0("[PKCS11_get_cert returns <null>]");
		return NULL;
	}

	ros = p11_RSAOBJECTSPECIFICATION_new(specification);
	if (ros == NULL) {
		P11_TRC0("[PKCS11_get_cert returns <null>]");
		return NULL;
	}

	if (pincallback != NULL) {
		/* [Note: MSVC may complain about converting
		** function pointers to data pointers and back.]
		*/
		cbdata[0] = (void*)pincallback;
		cbdata[1] = pincallbackdata;

		p11_RSAOBJECTSPECIFICATION_setPinCallback(
			ros,
			p11_pincallback_translator,
			cbdata);
	}

	certsize = 0;
	cert = p11_findRSACertificateContents(ros, &certsize);

	/* Note: must reset the (temporary) callback translation data. */
	if (pincallback != NULL) {
		p11_RSAOBJECTSPECIFICATION_setPinCallback(ros, NULL, NULL);
	}

	if (cert == NULL) {
		P11_TRC0("[PKCS11_get_cert returns <null>]");
		return NULL;
	}

	/* convert to X509* data type */

	tasn1 = (unsigned char*)cert;
	x509 = d2i_X509(NULL, &tasn1, certsize);
	if (x509 == NULL) {
		PKCS11err(PKCS11_F_PKCS11_GET_CERT, PKCS11_R_BAD_CERTIFICATE);
		(void)OPENSSL_free(cert);
		P11_TRC0("[PKCS11_get_cert returns <null>]");
		return NULL;
	}

	/* [release memory] */
	(void)OPENSSL_free(cert);

	P11_TRC1("[PKCS11_get_cert returns %p]", (const void*)x509);
	return x509;
}


/* Get a PKCS#11 RSA private key. */
/* [Function name: OpenSSL format.] */
EVP_PKEY* PKCS11_get_private_key(
	const char* specification,
	pem_password_cb* pincallback,
	void* pincallbackdata)
{
	p11_RSAOBJECTSPECIFICATION* ros;
	void* cbdata[2];
	EVP_PKEY* key;

	/* Note: 'specification' is considered security-sensitive.
	** It may contain password information.
	** So we don't trace it.
	*/
	P11_TRC3("PKCS11_get_private_key(specification=%s, pincallback=%p, pincallbackdata=%p)",
		/* (specification != NULL ? specification : "<null>"), */
		"<suppressed>",
		(const void*)pincallback,
		(const void*)pincallbackdata);

	/* [guard(s)] */
	if (specification == NULL) {
		PKCS11err(PKCS11_F_PKCS11_GET_PRIVATE_KEY, PKCS11_R_NULL_POINTER_PROVIDED);
		P11_TRC0("[PKCS11_get_private_key returns <null>]");
		return NULL;
	}

	ros = p11_RSAOBJECTSPECIFICATION_new(specification);
	if (ros == NULL) {
		P11_TRC0("[PKCS11_get_private_key returns <null>]");
		return NULL;
	}

	if (pincallback != NULL) {
		/* [Note: MSVC may complain about converting
		** function pointers to data pointers and back.]
		*/
		cbdata[0] = (void*)pincallback;
		cbdata[1] = pincallbackdata;

		p11_RSAOBJECTSPECIFICATION_setPinCallback(
			ros,
			p11_pincallback_translator,
			cbdata);
	}

	key = p11_findRSAPrivateKeyEvp(ros);

	/* Note: must reset the (temporary) callback translation data. */
	if (pincallback != NULL) {
		p11_RSAOBJECTSPECIFICATION_setPinCallback(ros, NULL, NULL);
	}

	P11_TRC1("[PKCS11_get_private_key returns %p]", (const void*)key);
	return key;
}

