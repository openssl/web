/* p11_obj.c -- OpenSSL pkcs11 code -- PKCS#11 token object and session handling. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


#include "p11_int.h"


#include <openssl/evp.h>

#include <string.h>


/* Open a new session for a specified slot/token. */
CK_SESSION_HANDLE p11_session_new(PKCS11* pkcs11, CK_SLOT_ID id)
{
	CK_RV rv;
	CK_FLAGS flags = 0;
	CK_SESSION_HANDLE session = CK_INVALID_HANDLE;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_SESSION_NEW, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_OpenSession == NULL
	) {
		PKCS11err(PKCS11_F_P11_SESSION_NEW, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* The specification states "For legacy reasons, the CKF_SERIAL_SESSION
	** bit must always be set; if a call to C_OpenSession does not have
	** this bit set, the call should return unsuccessfully with the error
	** code CKR_PARALLEL_NOT_SUPPORTED."
	*/
	flags |= CKF_SERIAL_SESSION;

	/* TODO: do we need, at some point, a CKF_RW_SESSION? */

	session = CK_INVALID_HANDLE;
	rv = (*pkcs11->functionList->C_OpenSession)(id, flags, NULL, NULL, &session);
	if (rv != CKR_OK) {
		P11_TRC1("C_OpenSession returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_SESSION_NEW, PKCS11_R_NULL_CANNOT_OPEN_SESSION);
		return CK_INVALID_HANDLE;
	}

	/* TODO: handle token-info login-required-flag */

	return session;
}


/* Close a session. */
int p11_session_free(PKCS11* pkcs11, CK_SESSION_HANDLE session)
{
	CK_RV rv;

	/* accept, as always, NULL */
	if (session == CK_INVALID_HANDLE) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_SESSION_FREE, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_CloseSession == NULL
	) {
		PKCS11err(PKCS11_F_P11_SESSION_FREE, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	rv = (*pkcs11->functionList->C_CloseSession)(session);
	if (rv != CKR_OK) {
		P11_TRC1("C_CloseSession returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_SESSION_FREE, PKCS11_R_NULL_CLOSE_SESSION_FAILED);
		return 0;
	}

	/* OK. */
	return 1;
}


/* Get a PIN (personal identification number). */
static int p11_getPin(
	char* pin,
	int pinsize,
	const char* usertypename,
	const char* slotname,
	const char* tokenname,
	void* data)
{
	/* Note: Avoiding 'prompt' buffer overflows at any time. */
	char prompt[1024];

	/* [unused(s)] */
	(void)data;

	/* [guard(s)] */
	if (pin == NULL || pinsize <= 0) {
		return 0;
	}

	memset(pin, 0, pinsize);

	/* Assemble a reasonable prompt, like:
	** "PKCS#11 User PIN for Slot 2 (AdminToken): "
	*/

	memset(prompt, 0, sizeof(prompt));

	sprintf(prompt, "PKCS#11");
	if (usertypename != NULL && usertypename[0] != '\0') {
		sprintf(&prompt[strlen(prompt)], " %.*s", 256, usertypename);
	}
	sprintf(&prompt[strlen(prompt)], " PIN");

	if (
		(slotname != NULL && slotname[0] != '\0') ||
		(tokenname != NULL && tokenname[0] != '\0')
	) {
		sprintf(&prompt[strlen(prompt)], " for Slot");

		if (slotname != NULL && slotname[0] != '\0') {
			/* slot number */
			sprintf(&prompt[strlen(prompt)], " %.*s", 256, slotname);
		}

		if (tokenname != NULL && tokenname[0] != '\0') {
			/* token label */
			sprintf(&prompt[strlen(prompt)], " (%.*s)", 256, tokenname);
		}
	}

	sprintf(&prompt[strlen(prompt)], ": ");

	if (EVP_read_pw_string(pin, pinsize, prompt, 0) < 0) {
		return 0;
	}

	/* OK. */
	return 1;
}


/* Log in into a token. */
int p11_login(PKCS11* pkcs11, CK_SESSION_HANDLE session)
{
	CK_RV rv;
	CK_SESSION_INFO sessioninfo;
	CK_TOKEN_INFO tokeninfo;
	CK_USER_TYPE usertype = CKU_USER;
	char pin[1024];
	char* pintouse;
	int pintousesize;

	/* Note: Have copies on everything, being robust against the callback. */
	char slotname[1024];
	char tokenname[1024];
	char usertypename[1024];

	int (*pincallback)(char*, int, const char*, const char*, const char*, void*);
	void* pincallbackdata;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_LOGIN, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetSessionInfo == NULL ||
		pkcs11->functionList->C_GetTokenInfo == NULL ||
		pkcs11->functionList->C_Login == NULL
	) {
		PKCS11err(PKCS11_F_P11_LOGIN, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* get the slot id and the token name (used for the prompt) */

	memset(&sessioninfo, 0, sizeof(sessioninfo));
	rv = (*pkcs11->functionList->C_GetSessionInfo)(session, &sessioninfo);
	if (rv != CKR_OK) {
		P11_TRC1("C_GetSessionInfo returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_LOGIN, PKCS11_R_CANNOT_GET_SESSIONINFO);
		return 0;
	}

	memset(&tokeninfo, 0, sizeof(tokeninfo));
	rv = (*pkcs11->functionList->C_GetTokenInfo)(sessioninfo.slotID, &tokeninfo);
	if (rv != CKR_OK) {
		P11_TRC1("C_GetTokenInfo returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_LOGIN, PKCS11_R_CANNOT_GET_TOKENINFO);
		return 0;
	}

	sprintf(slotname, "%u", (unsigned)sessioninfo.slotID);

	tokenname[0] = '\0';
	p11_stringCopy(tokenname, sizeof(tokenname), tokeninfo.label, sizeof(tokeninfo.label));

	/* user / security officer type */
	/* Note: Having a copy of this, being robust against the callback. */
	memset(usertypename, 0, sizeof(usertypename));
	if (usertype == CKU_SO) {
		strcpy(usertypename, "SO");
	} else if (usertype == CKU_USER) {
		strcpy(usertypename, "User");
	}

	/* TODO: check CK_STATE (if already logged in, etc.)? */

	memset(pin, 0, sizeof(pin));

	pintouse = NULL;
	pintousesize = 0;

	/* Consider the situation of CK_TOKEN_INFO having
	** CKF_PROTECTED_AUTHENTICATION_PATH set.
	** In that case, NULL should be given as PIN; the
	** authentication is done on the device itself (e.g.
	** by a pad).
	*/

	if (!(tokeninfo.flags & CKF_PROTECTED_AUTHENTICATION_PATH)) {

		/* Check for possible PIN callback, */
		pincallback = pkcs11->pinCallback;
		pincallbackdata = pkcs11->pinCallbackData;

		if (pincallback == NULL) {
			pincallback = p11_getPin;
			pincallbackdata = NULL;
		}

		/* get pin */
		if (!(*pincallback)(
			pin,
			sizeof(pin),
			usertypename,
			slotname,
			tokenname,
			pincallbackdata)
		) {
			P11_TRC0("pincallback failed");
			PKCS11err(PKCS11_F_P11_LOGIN, PKCS11_R_PIN_CALLBACK_FAILED);
			return 0;
		}

		/* NOTE: we suppress the login if PIN is empty.
		** This enables 1) a cryptoki device to have the require-login
		** flag set on all slots and not produce errors on uninitialized
		** tokens and 2) setting the force-login flag and have tokens
		** without pins.
		*/
		if (*pin == '\0') {
			P11_TRC0("[not logging in]");

			/* OK. */
			return 1;
		}

		pintouse = pin;
		pintousesize = strlen(pin);
	}

	rv = (*pkcs11->functionList->C_Login)(
		session,
		usertype,
		(CK_CHAR*)pintouse,
		pintousesize);

	/* Reset PIN info ASAP, for security. */
	memset(pin, 0, sizeof(pin));

	/* TODO: shall we handle login failures, such as
	** CKR_PIN_INCORRECT, CKR_PIN_INVALID, CKR_PIN_LEN_RANGE,
	** CKR_PIN_EXPIRED, CKR_PIN_LOCKED?
	** Give a feedback?  Loop some more?
	*/

	/* ignore some */
	if (rv == CKR_USER_ALREADY_LOGGED_IN) {
		/*EMPTY*/
		P11_TRC0("[user already logged in]");

	} else if (rv != CKR_OK) {
		P11_TRC1("C_Login returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_LOGIN, PKCS11_R_CANNOT_LOGIN);
		return 0;
	}

	/* OK. */
	return 1;
}


/* Log out from a token. */
int p11_logout(PKCS11* pkcs11, CK_SESSION_HANDLE session)
{
	CK_RV rv;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_LOGOUT, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_Logout == NULL
	) {
		PKCS11err(PKCS11_F_P11_LOGOUT, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* TODO: check CK_STATE (if already logged out, etc.)? */

	rv = (*pkcs11->functionList->C_Logout)(session);
	if (rv != CKR_OK) {
		P11_TRC1("C_Logout returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_LOGOUT, PKCS11_R_CANNOT_LOGOUT);
		return 0;
	}

	/* OK. */
	return 1;
}


/* Enumerate all objects. */
int p11_enumerateObjects(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	int (*cb)(PKCS11*, CK_SESSION_HANDLE, CK_OBJECT_HANDLE, void*),
	void* cbdata)
{
	CK_RV rv;
	CK_OBJECT_HANDLE object;
	CK_ULONG count, totalcount;

	/* Skip if some of it is NULL. */
	if (cb == NULL || session == CK_INVALID_HANDLE) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_ENUMERATEOBJECTS, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_FindObjectsInit == NULL ||
		pkcs11->functionList->C_FindObjects == NULL ||
		pkcs11->functionList->C_FindObjectsFinal == NULL
	) {
		PKCS11err(PKCS11_F_P11_ENUMERATEOBJECTS, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* Enumerate all objects (no 'attribute template' used). */
	rv = (*pkcs11->functionList->C_FindObjectsInit)(session, NULL, 0);
	if (rv != CKR_OK) {
		P11_TRC1("C_FindObjectsInit returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_ENUMERATEOBJECTS, PKCS11_R_CANNOT_INIT_OBJECTFINDER);
		return 0;
	}

	/* Note the specification states: "The object search operation will
	** only find objects that the session can view.  For example, an
	** object search in an R/W Public Session will not find any private
	** objects (even 	** if one of the attributes in the search
	** template specifies that the search is for private objects)."
	** This requires us to use appropriate heuristics when to log in.
	*/

	totalcount = 0;

	for (;;) {

		/* Get the objects one by one. */
		object = CK_INVALID_HANDLE;
		count = 0;
		rv = (*pkcs11->functionList->C_FindObjects)(session, &object, 1, &count);
		if (rv != CKR_OK) {
			P11_TRC1("C_FindObjects returned %s", p11_errorName(rv));
			p11_push_CK_RV(rv);
			PKCS11err(PKCS11_F_P11_ENUMERATEOBJECTS, PKCS11_R_FIND_OBJECTS_FAILED);
			goto err;
		}

		if (count == 0) {
			break;
		}

		/*assert(count==1)*/

		totalcount++;

		if (!(*cb)(pkcs11, session, object, cbdata)) {
			/* Note: this is treated as 'friendly' 'cancel',
			** not as an error condition.
			*/
			break;
		}
	}

	if (totalcount == 0) {
		/*EMPTY*/
		P11_TRC0("[no objects]");
	}

	rv = (*pkcs11->functionList->C_FindObjectsFinal)(session);
	if (rv != CKR_OK) {
		P11_TRC1("C_FindObjectsFinal returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_ENUMERATEOBJECTS, PKCS11_R_CANNOT_FINALIZE_OBJECTFINDER);
		return 0;
	}

	/* OK. */
	return 1;

err :

	/* ignore errors here */
	/* but don't clear the error stack */
	(*pkcs11->functionList->C_FindObjectsFinal)(session);

	return 0;
}


/* Enumerate PKCS#11 object attributes. */
int p11_enumerateAttributes(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	const CK_ATTRIBUTE_TYPE* attributes,
	int attributesSize,
	int (*cb)(
		PKCS11*,
		CK_SESSION_HANDLE,
		CK_OBJECT_HANDLE,
		CK_ATTRIBUTE_TYPE,
		CK_RV,
		const char*,
		int,
		void*),
	void* cbdata,
	int enumerateSensitives,
	int enumerateAll)
{
	CK_RV rv;
	int bufsize = 1, size;
	char* buf = NULL;
	int i;
	CK_ATTRIBUTE_TYPE attr;
	CK_ATTRIBUTE tmpl;

	/* Skip if some of it is NULL. */
	if (
		object == CK_INVALID_HANDLE ||
		attributes == NULL ||
		attributesSize <= 0 ||
		cb == NULL
	) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_ENUMERATEATTRIBUTES, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetAttributeValue == NULL
	) {
		PKCS11err(PKCS11_F_P11_ENUMERATEATTRIBUTES, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* Go thru the table.  Get one by one. */

	for (i = 0; i < attributesSize; i++) {
		attr = attributes[i];

		/* get attribute size first */

		memset(&tmpl, 0, sizeof(tmpl));
		tmpl.type = attr;
		tmpl.pValue = NULL;
		tmpl.ulValueLen = 0;

		rv = (*pkcs11->functionList->C_GetAttributeValue)(session, object, &tmpl, 1);
		if (rv != CKR_OK) {
			/* tracing done below */

			if (rv == CKR_ATTRIBUTE_TYPE_INVALID) {
				/* no such attribute */

				if (enumerateAll) {
					if (!(*cb)(
						pkcs11,
						session,
						object,
						attr,
						rv,
						NULL,
						0,
						cbdata)
					) {
						/* Note: this is treated as 'friendly' 'cancel',
						** not as an error condition.
						*/
						break;
					}
				}

				continue;
			}

			if (rv == CKR_ATTRIBUTE_SENSITIVE) {
				/* sensitive, unextractable */

				if (enumerateSensitives) {
					if (!(*cb)(
						pkcs11,
						session,
						object,
						attr,
						rv,
						NULL,
						0,
						cbdata)
					) {
						/* Note: this is treated as 'friendly' 'cancel',
						** not as an error condition.
						*/
						break;
					}
				}

				continue;
			}

			/* Note: not doing anything of importance with !=CKR_OK anyway. */

			P11_TRC1("C_GetAttributeValue returned %s", p11_errorName(rv));

			if (enumerateAll) {
				if (!(*cb)(pkcs11, session, object, attr, rv, NULL, 0, cbdata)) {
					/* Note: this is treated as 'friendly' 'cancel',
					** not as an error condition.
					*/
					break;
				}
			}

			continue;
		}

		/* Note: this case should already be handled at
		** CKR_ATTRIBUTE_TYPE_INVALID and CKR_ATTRIBUTE_SENSITIVE
		*/
		if ((CK_LONG)tmpl.ulValueLen == -1) {
			/* sensitive, unextractable, no such attribute */
			continue;
		}

		size = tmpl.ulValueLen;

		/* adjust buffer size (if necessary) */
		if (bufsize < size || buf == NULL) {

			if (buf != NULL) {
				OPENSSL_free(buf);
			}

			while (bufsize < size) {
				/* [four is handy] */
				bufsize *= 4;
			}

			buf = (char*)OPENSSL_malloc(bufsize);
			if (buf == NULL) {
				PKCS11err(PKCS11_F_P11_ENUMERATEATTRIBUTES, PKCS11_R_OUT_OF_MEMORY);
				return 0;
			}
		}

		/* Now get the attribute data. */

		memset(buf, 0, bufsize);

		/* re-setting all of the values */
		memset(&tmpl, 0, sizeof(tmpl));
		tmpl.type = attr;
		tmpl.pValue = buf;
		/* using the returned size, not the buffer size */
		tmpl.ulValueLen = size;

		rv = (*pkcs11->functionList->C_GetAttributeValue)(session, object, &tmpl, 1);

		/* Note: not expecting anything but CKR_OK. */
		if (rv != CKR_OK) {
			P11_TRC1("C_GetAttributeValue returned %s", p11_errorName(rv));
			if (enumerateAll) {
				if (!(*cb)(pkcs11, session, object, attr, rv, NULL, 0, cbdata)) {
					/* Note: this is treated as 'friendly' 'cancel',
					** not as an error condition.
					*/
					break;
				}
			}

			continue;
		}

		if ((CK_LONG)tmpl.ulValueLen == -1) {
			/* TODO: ? */
			continue;
		}

		if ((CK_LONG)tmpl.ulValueLen != size) {
			/* TODO: ? */
			continue;
		}

		if (!(*cb)(pkcs11, session, object, attr, CKR_OK, buf, size, cbdata)) {
			/* Note: this is treated as 'friendly' 'cancel',
			** not as an error condition.
			*/
			break;
		}
	}

	if (buf != NULL) {
		OPENSSL_free(buf);
	}

	/* OK. */
	return 1;
}


/* Get a token object attribute contents. */
void* p11_getObjectAttribute(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	CK_ATTRIBUTE_TYPE attribute,
	int* size)
{
	CK_RV rv;
	CK_ATTRIBUTE at;
	int valuesize;
	void* value = NULL;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_GETOBJECTATTRIBUTE, PKCS11_R_NULL_POINTER_PROVIDED);
		return NULL;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetAttributeValue == NULL
	) {
		PKCS11err(PKCS11_F_P11_GETOBJECTATTRIBUTE, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return NULL;
	}

	memset(&at, 0, sizeof(at));
	at.type = attribute;
	at.pValue = NULL;
	at.ulValueLen = 0;

	rv = (*pkcs11->functionList->C_GetAttributeValue)(session, object, &at, 1);

	if (rv != CKR_OK) {
		P11_TRC1("C_GetAttributeValue returned %s", p11_errorName(rv));
		PKCS11err(PKCS11_F_P11_GETOBJECTATTRIBUTE,
			PKCS11_R_CANNOT_GET_TOKEN_OBJECT_ATTRIBUTE_VALUE);
		goto err;
	}

	valuesize = at.ulValueLen;

	if (valuesize < 0) {
		P11_TRC0("[C_GetAttributeValue returned negative size]");
		PKCS11err(PKCS11_F_P11_GETOBJECTATTRIBUTE,
			PKCS11_R_CANNOT_GET_TOKEN_OBJECT_ATTRIBUTE_VALUE);
		goto err;
	}

	/*assert(valuesize!=0);?*/

	value = OPENSSL_malloc(valuesize);
	if (value == NULL) {
		PKCS11err(PKCS11_F_P11_GETOBJECTATTRIBUTE, PKCS11_R_OUT_OF_MEMORY);
		goto err;
	}
	memset(value, 0, valuesize);

	memset(&at, 0, sizeof(at));
	at.type = attribute;
	at.pValue = (void*)value;
	at.ulValueLen = valuesize;

	rv = (*pkcs11->functionList->C_GetAttributeValue)(session, object, &at, 1);
	if (rv != CKR_OK) {
		P11_TRC1("C_GetAttributeValue returned %s", p11_errorName(rv));
		PKCS11err(PKCS11_F_P11_GETOBJECTATTRIBUTE,
			PKCS11_R_CANNOT_GET_TOKEN_OBJECT_ATTRIBUTE_VALUE);
		goto err;
	}

	*size = valuesize;
	return value;

err :

	if (value != NULL) {
		(void)OPENSSL_free(value);
	}

	return NULL;
}


/* Get a token object's 'value atribute' contents. */
void* p11_getObjectValue(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	int* size)
{
	return p11_getObjectAttribute(
		pkcs11,
		session,
		object,
		CKA_VALUE,
		size);
}


/* Get a token object's id. */
void* p11_getObjectId(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	int* size)
{
	return p11_getObjectAttribute(
		pkcs11,
		session,
		object,
		CKA_ID,
		size);
}


/* Convert a string representing a token object id. */
char* p11_idString(const char* s, int* idsize)
{
	int size;
	char* p = NULL;
	int n, i;

	/* [guard(s)] */
	if (s == NULL) {
		/* null in, null out... */
		return NULL;
	}
	if (idsize == NULL) {
		PKCS11err(PKCS11_F_P11_IDSTRING, PKCS11_R_NULL_POINTER_PROVIDED);
		return NULL;
	}

	/* We need half of the string size or less,
	** however, round up.
	** Add one too for a allocation size greater zero
	** in the empty id case.
	*/
	size = (strlen(s) + 1) / 2 + 1;

	/* TODO: still lessen the allocation size?  Probably not. */

	p = (char*)OPENSSL_malloc(size);
	if (p == NULL) {
		PKCS11err(PKCS11_F_P11_IDSTRING, PKCS11_R_OUT_OF_MEMORY);
		return NULL;
	}
	memset(p, 0, size);

	/* reset output size */
	*idsize = 0;

	/* Now we're expecting something like
	** "01:8b:22:6b:af:8c:a3:5a:aa:bd:4f:6a:e2:f5:82:1f:50:17:0a:3d".
	** However, accept leading and trailing separators.
	** Separator is not mandatory ':'.
	*/

	n = i =	0;

	/* skip leading separators */
	while (s[i] != '\0' && !p11_isalnum(s[i])) {
		i++;
	}
	if (s[i] == '\0') {
		return p;
	}

	/* skip possible "0x" prefix */
	if (s[i] == '0' && (s[i + 1] == 'x' || s[i + 1] == 'X')) {
		i += 2;
	}

	while (s[i] != '\0' && s[i + 1] != '\0') {
		if (!p11_isxdigit(s[i]) || !p11_isxdigit(s[i + 1])) {
			goto err;
		}

		p[n] = (char)((p11_hexCharValue(s[i]) << 4) |
			p11_hexCharValue(s[i + 1]));
		n++;
		i += 2;

		/* skip _one_ separator (this one may be a trailing one) */
		if (s[i] != '\0' && !p11_isalnum(s[i])) {
			i++;
		}
	}

	*idsize = n;
	return p;

err :

	PKCS11err(PKCS11_F_P11_IDSTRING, PKCS11_R_INCONVENIENT_ID_FORMAT);

	if (p != NULL) {
		OPENSSL_free(p);
	}

	return NULL;
}

