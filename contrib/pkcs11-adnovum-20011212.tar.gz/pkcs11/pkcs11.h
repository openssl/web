/* pkcs11.h -- interface to the OpenSSL pkcs11 code. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* This OpenSSL pkcs11 code implements an interface to crypto devices
 * using the application programmers interface defined in the document
 * "PKCS #11 v2.10: Cryptographic Token Interface Standard, RSA
 * Laboratories, December 1999".
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* NOTE that this header file does not include the PKCS#11 API
** specification (pkcs11s.h, as we call it) and its sub-headerfiles
** (pkcs11t.h, pkcs11f.h), nor our macro-defining wrapper (pkcs11n.h).
** Neither is the internal OpenSSL pkcs11 code interface (p11_int.h)
** included.
*/


/* [include guard] */
#ifndef PKCS11_H
#define PKCS11_H


#ifdef __cplusplus
extern "C" {
#endif


/* needed for FILE* */
#include <stdio.h>
/* needed for X509* */
#include <openssl/x509.h>
/* needed for pem_password_cb* */
#include <openssl/pem.h>


/* forward type declarations. */
/* type details are not needed here. */
/* not knowning type details encapsultes them, as desired. */

typedef struct PKCS11_struct PKCS11;


/* Establish a PKCS#11 driver for a specified cryptoki library.
** Returns NULL on failure (use ERR_print_errors or similar in that case).
** Note: You can't use the pkcs11 handle returned by PKCS11_new after
** a fork; in that case you have to get another one.
*/
PKCS11* PKCS11_new(const char* library);

/* De-initialize and free the cryptoki library handle. */
int PKCS11_free(PKCS11* pkcs11);

/* Re-initialize the cryptoki library. */
int PKCS11_reinit(PKCS11* pkcs11);

/* Set login behavior. */
int PKCS11_setDoLogin(PKCS11* pkcs11, int dologin);

/* Set PIN callback. */
int PKCS11_setPinCallback(
	PKCS11* pkcs11,
	int (*pincallback)(
		char* pin,
		int pinsize,
		const char* usertypename,
		const char* slotname,
		const char* tokenname,
		void* data),
	void* pincallbackdata);

/* Dump information about PKCS#11 library, slots, tokens and token objects. */
int PKCS11_dumpInfo(PKCS11* pkcs11, FILE* out);

/* Get a PKCS#11 X509 RSA certificate. */
X509* PKCS11_get_cert(
	const char* specification,
	pem_password_cb* pincallback,
	void* pincallbackdata);

/* Get a PKCS#11 RSA private key. */
EVP_PKEY* PKCS11_get_private_key(
	const char* specification,
	pem_password_cb* pincallback,
	void* pincallbackdata);


#ifdef __cplusplus
}
#endif


#endif

