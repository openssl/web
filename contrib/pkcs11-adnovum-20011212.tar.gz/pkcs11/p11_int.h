/* p11_int.h -- internal OpenSSL pkcs11 code interface. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* NOTE: things defined in this interface is for pkcs11 code internal
** use only.  Include pkcs11.h for the public interface.
*/


/* [include guard] */
#ifndef P11_INT_H
#define P11_INT_H


/* ---- included headers */

/* [externally visible types] */
#include "pkcs11.h"

/* [tracing] */
#include "p11_trc.h"

/* NOTE: unlike in C++ we can't introduce data-struct names only
** that flexibly, to capsulate things.  So unfortunately we have
** to include some of the headers here already...
*/

#include <openssl/dso.h>

/* Note that PKCS#11 API's definition of TRUE ((!FALSE)) may lead to
** lint warnings (constant operand to op: "!").
*/
/* supress them */
#if defined(lint)
#if !defined(TRUE)
#define TRUE (1)
#endif
#endif

/* PKCS#11 API specification. */
#include "pkcs11n.h"


#if defined(P11_NO_ERRORS)
#undef PKCS11err
#define PKCS11err(function, reason) ((void)(0))
#endif


/* ---- data type names */

typedef struct p11_RSAOBJECTSPECIFICATION_struct p11_RSAOBJECTSPECIFICATION;


/* ---- data types */

/* done @ pkcs11.h:
** typedef struct PKCS11_struct PKCS11;
*/

struct PKCS11_struct
{
	/* Cryptoki PKCS#11 library name.  A copy.
	** 'library' is handled by DSO_load and can typically be
	** either a (relative or absolute) file name or a name
	** that gets expanded by DSO_load (e.g. "cryptoki" -->
	** "libcryptoki.so").
	*/
	char* library;

	/* Dynamic library (DSO) struct to the cryptoki library. */
	DSO* dso;

	/* PKCS#11 GetFunctionList function pointer. */
	CK_C_GetFunctionList getFunctionList;

	/* PKCS#11 Initialize function pointer. */
	CK_C_Initialize initialize;

	/* Function list, returned and owned by PKCS#11 library. */
	CK_FUNCTION_LIST_PTR functionList;

	/* Optional PIN getter callback and its data. */
	int (*pinCallback)(
		char* pin,
		int pinsize,
		const char* usertypename,
		const char* slotname,
		const char* tokenname,
		void* data);
	void* pinCallbackData;

	/* Flag(s). */
	int doLogin;
};


/* ---- p11_drv.c -- external API -- declared in pkcs11.h */

/* ---- p11_lib.c -- general PKCS#11 stuff */

/* Load the cryptoki library. */
int p11_load(PKCS11* pkcs11, const char* library);

/* Unload the cryptoki library. */
int p11_unload(PKCS11* pkcs11);

/* Initialize the cryptoki library. */
int p11_init(PKCS11* pkcs11);

/* Re-Initialize the cryptoki library. */
int p11_reinit(PKCS11* pkcs11);

/* De-initialize the cryptoki library. */
int p11_deinit(PKCS11* pkcs11);

/* Enumerate all slots. */
int p11_enumerateSlots(
	PKCS11* pkcs11,
	int (*cb)(PKCS11*, CK_SLOT_ID, void*),
	void* cbdata);

/* Push PKCS#11 API error code to OpenSSL error stack. */
int p11_push_CK_RV(CK_RV rv);

/* Push hint(s) (if any) on PKCS#11 API error code to OpenSSL error stack. */
void p11_push_hints(CK_RV rv);

/* Discard OpenSSL errors (pop from error stack). */
void p11_discard_errors(void);

/* PKCS#11 format string length. */
int p11_stringSize(const CK_UTF8CHAR* str, int size);

/* Check PKCS#11 format strings for equalness.
** Sizes of -1 specify non-PKCS#11 format strings.
*/
int p11_stringEqual(
	const CK_UTF8CHAR* a_str,
	int a_size,
	const CK_UTF8CHAR* b_str,
	int b_size);

/* Copy PKCS#11 format string to C format.  Copy as much as possible. */
void p11_stringCopy(
	char* dst,
	int dst_size,
	const CK_UTF8CHAR* src,
	int src_size);

/* Convert PKCS#11 token object data to CK_ULONG. */
CK_ULONG p11_data2ulong(const void* value, int size);

/* ---- p11_obj.c -- PKCS#11 token object handling */

/* Open a new session for a specified slot/token. */
CK_SESSION_HANDLE p11_session_new(PKCS11* pkcs11, CK_SLOT_ID id);

/* Close a session. */
int p11_session_free(PKCS11* pkcs11, CK_SESSION_HANDLE session);

/* Log in into a token. */
int p11_login(PKCS11* pkcs11, CK_SESSION_HANDLE session);

/* Log out from a token. */
int p11_logout(PKCS11* pkcs11, CK_SESSION_HANDLE session);

/* Enumerate all objects. */
int p11_enumerateObjects(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	int (*cb)(PKCS11*, CK_SESSION_HANDLE, CK_OBJECT_HANDLE, void*),
	void* cbdata);

/* Enumerate PKCS#11 object attributes. */
int p11_enumerateAttributes(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	const CK_ATTRIBUTE_TYPE* attributes,
	int attributesSize,
	int (*cb)(
		PKCS11*,
		CK_SESSION_HANDLE,
		CK_OBJECT_HANDLE,
		CK_ATTRIBUTE_TYPE,
		CK_RV,
		const char*,
		int,
		void*),
	void* cbdata,
	int enumerateSensitives,
	int enumerateAll);

/* Get a token object attribute contents. */
void* p11_getObjectAttribute(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	CK_ATTRIBUTE_TYPE attribute,
	int* size);

/* Get a token object's 'value atribute' contents. */
void* p11_getObjectValue(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	int* size);

/* Get a token object's id. */
void* p11_getObjectId(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	int* size);

/* Convert a string representing a token object id. */
char* p11_idString(const char* s, int* idsize);

/* ---- p11_dump.c -- PKCS#11 information dumping */

/* Dump information about the PKCS#11 library. */
int p11_dumpLibrary(PKCS11* pkcs11, FILE* out);

/* Dump information about slots. */
int p11_dumpSlots(PKCS11* pkcs11, int dumpObjects, FILE* out);

/* Dump information about a slot and its token. */
int p11_dumpSlot(
	PKCS11* pkcs11,
	CK_SLOT_ID id,
	int dumpObjects,
	FILE* out);

/* Dump information about a slot only. */
int p11_dumpSlotOnly(PKCS11* pkcs11, CK_SLOT_ID id, FILE* out);

/* Dump information about a token only. */
int p11_dumpTokenOnly(PKCS11* pkcs11, CK_SLOT_ID id, FILE* out);

/* Dump information token mechanisms. */
int p11_dumpMechanisms(PKCS11* pkcs11, CK_SLOT_ID id, FILE* out);

/* Dump information about token objects. */
int p11_dumpObjects(PKCS11* pkcs11, CK_SLOT_ID id, FILE* out);

/* Dump information about a token object. */
int p11_dumpObject(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	FILE* out);

/* Dump information about token object attributes. */
int p11_dumpAttributes(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	FILE* out);

/* Dump information about a token object attribute. */
int p11_dumpAttribute(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	CK_ATTRIBUTE_TYPE attribute,
	CK_RV status,
	const char* value,
	int size,
	FILE* out);

/* Token mechanism name. */
const char* p11_mechanismName(CK_MECHANISM_TYPE mechanism);

/* Token mechanism name. */
const char* p11_mechanismNameB(
	CK_MECHANISM_TYPE mechanism,
	char* buf,
	int size);

/* Token object attribute name. */
const char* p11_attributeName(CK_ATTRIBUTE_TYPE attribute);

/* Token object attribute name. */
const char* p11_attributeNameB(
	CK_ATTRIBUTE_TYPE attribute,
	char* buf,
	int size);

/* Dump a token object attribute value. */
int p11_dumpAttributeValue(
	CK_ATTRIBUTE_TYPE attribute,
	const char* value,
	int size,
	FILE* out);

/* Dump a PKCS#11 format string. */
void p11_dumpString(const CK_UTF8CHAR* str, int size, FILE* out);

/* Dump a PKCS#11 format string or a representation for 'empty'. */
void p11_dumpStringE(const CK_UTF8CHAR* str, int size, FILE* out);

/* Dump PKCS#11 format version info. */
void p11_dumpVersion(const CK_VERSION* v, FILE* out);

/* Note on PKCS#11 numbers: See specification on which dump function
** to use.  PKCS#11 'infinite' may, since unfortunately defined as 0,
** depending on the context, either signify zero or infinite.
*/

/* Dump a PKCS#11 number. */
void p11_dumpNumber(CK_ULONG n, FILE* out);

/* Dump a PKCS#11 number, consider 'unavailable'. */
void p11_dumpNumberU(CK_ULONG n, FILE* out);

/* Dump a PKCS#11 number, consider 'infinite'. */
void p11_dumpNumberI(CK_ULONG n, FILE* out);

/* Dump a PKCS#11 number, consider 'unavailable' and 'infinite'. */
void p11_dumpNumberUI(CK_ULONG n, FILE* out);

/* Empty value representation. */
void p11_dumpEmpty(FILE* out);

/* Dump info as hexadecimal data. */
void p11_dumpHex(
	const void* value,
	int size,
	const char* delimiter,
	int wrapsize,
	FILE* out);

/* Dump info as hexadecimal data, standard format, using colon delimiter. */
void p11_dumpHexS(const void* value, int size, FILE* out);

/* Dump info as hexadecimal data, plain format, using no delimiter. */
void p11_dumpHexP(const void* value, int size, FILE* out);

/* Dump info as boolean data. */
void p11_dumpBool(const void* value, int size, FILE* out);

/* Dump info as object-class. */
void p11_dumpObjectClass(const void* value, int size, FILE* out);

/* Dump info as harware-feature-type. */
void p11_dumpHWFeatureType(const void* value, int size, FILE* out);

/* Dump info as key-type. */
void p11_dumpKeyType(const void* value, int size, FILE* out);

/* Dump info as certificate-type. */
void p11_dumpCertificateType(const void* value, int size, FILE* out);

/* Dump PKCS#11 flags. */
void p11_dumpFlagsPlain(CK_FLAGS f, FILE* out);

/* Dump PKCS#11 library flags. */
void p11_dumpLibraryFlags(CK_FLAGS f, FILE* out);

/* Dump PKCS#11 slot flags. */
void p11_dumpSlotFlags(CK_FLAGS f, FILE* out);

/* Dump PKCS#11 token flags. */
void p11_dumpTokenFlags(CK_FLAGS f, FILE* out);

/* Dump PKCS#11 session flags. */
void p11_dumpSessionFlags(CK_FLAGS f, FILE* out);

/* Dump PKCS#11 mechanism flags. */
void p11_dumpMechanismFlags(CK_FLAGS f, FILE* out);

/* PKCS#11 API error name. */
const char* p11_errorName(CK_RV rv);

/* PKCS#11 API error name. */
const char* p11_errorNameB(CK_RV rv, char* buf, int size);

/* Map PKCS#11 API error reason to OpenSSL error reason. */
int p11_errorReason(CK_RV rv);

/* Map PKCS#11 API error reason to OpenSSL error hints. */
int p11_errorHints(CK_RV rv, int* hints, int size);

/* ---- p11_find.c -- token object finder */

/* Establish a p11_RSAOBJECTSPECIFICATION. */
p11_RSAOBJECTSPECIFICATION* p11_RSAOBJECTSPECIFICATION_new(
	const char* objectspecification);

/* Free a p11_RSAOBJECTSPECIFICATION. */
void p11_RSAOBJECTSPECIFICATION_free(p11_RSAOBJECTSPECIFICATION* ros);

/* Set PIN callback. */
int p11_RSAOBJECTSPECIFICATION_setPinCallback(
	p11_RSAOBJECTSPECIFICATION* ros,
	int (*pincallback)(
		char* pin,
		int pinsize,
		const char* usertypename,
		const char* slotname,
		const char* tokenname,
		void* data),
	void* pincallbackdata);

/* Get the keep-resources flag. */
int p11_RSAOBJECTSPECIFICATION_getKeep(p11_RSAOBJECTSPECIFICATION* ros);

/* Get the PKCS11 resource. */
PKCS11* p11_RSAOBJECTSPECIFICATION_getPKCS11(p11_RSAOBJECTSPECIFICATION* ros);

/* Get the session resource. */
CK_SESSION_HANDLE p11_RSAOBJECTSPECIFICATION_getSession(
	p11_RSAOBJECTSPECIFICATION* ros);

/* Set up the resources we need (driver, session, login, ...). */
int  p11_RSAOBJECTSPECIFICATION_setup(p11_RSAOBJECTSPECIFICATION* ros);

/* Tear down the resources we don't need anymore
** (..., login, session, driver).
*/
int  p11_RSAOBJECTSPECIFICATION_teardown(p11_RSAOBJECTSPECIFICATION* ros);

/* Find an RSA token object. */
CK_OBJECT_HANDLE p11_findRSAObject(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_CLASS rsaobjectclass,
	const char* objectlabel,
	const void* objectid,
	int objectidsize);

/* Find a certificate and its contents in a rsa object specification. */
char* p11_findRSACertificateContents(
	p11_RSAOBJECTSPECIFICATION* ros,
	int* certsize);

/* Find a private key in a rsa object specification. */
EVP_PKEY* p11_findRSAPrivateKeyEvp(p11_RSAOBJECTSPECIFICATION* ros);

/* Find a Token. */
CK_SLOT_ID p11_findToken(PKCS11* pkcs11, const char* name);

/* Find one single Token. */
CK_SLOT_ID p11_findOneToken(PKCS11* pkcs11);

/* ---- p11_rsa.c -- RSA operations */

/* Instanciate an RSA method, get a private key handle on it. */
EVP_PKEY* p11_RSAPrivateKeyEvp(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	p11_RSAOBJECTSPECIFICATION* ros);

/* ---- p11_util.c -- general, non-PKCS#11 stuff */

/* Convert network-byte-order (big-endian) to host-byte-order, 2-byte values. */
unsigned short p11_ntohs(unsigned short n);

/* Convert host-byte-order to network-byte-order (big-endian), 2-byte values. */
unsigned short p11_htons(unsigned short n);

/* Convert network-byte-order (big-endian) to host-byte-order, 4-byte values. */
unsigned long p11_ntohl(unsigned long n);

/* Convert host-byte-order to network-byte-order (big-endian), 4-byte values. */
unsigned long p11_htonl(unsigned long n);

/* Is upper case character. */
int p11_isupper(char c);

/* Is lower case character. */
int p11_islower(char c);

/* Is alphabetic (upper or lower case) character. */
int p11_isalpha(char c);

/* Is a digit. */
int p11_isdigit(char c);

/* Is a hexadecimal digit. */
int p11_isxdigit(char c);

/* Is alphabetic character or a digit. */
int p11_isalnum(char c);

/* Decimal character value. */
int p11_decCharValue(char c);

/* Hexadecimal character value. */
int p11_hexCharValue(char c);

/* Slice a string into an array of name/value pairs. */
char** p11_sliceNVPairs(const char* nvList);

/* Free an array of name/value pairs. */
void p11_freeNVPairs(char** nvList);

/* Find a name/value pair in an array of such.
** Return a pointer on the value.
*/
const char* p11_findNVPair(const char* const* nvList, const char* name);

/* Convert a string representing 'true' or 'false'. */
int p11_booleanString(const char* s);

/* Get a new N/V-hash. */
LHASH* p11_nvlh_new(void);

/* Free a N/V-hash. */
void p11_nvlh_free(LHASH* nvlh);

/* Insert a N/V-hash value. */
void p11_nvlh_insert(LHASH* nvlh, const char* key, const void *data);

/* Delete a N/V-hash value. */
void p11_nvlh_delete(LHASH* nvlh, const char* key);

/* Retrieve a N/V-hash value. */
const void* p11_nvlh_retrieve(LHASH* nvlh, const char* key);

/* N/V-hash value pairs enumeration. */
void p11_nvlh_doall(
	LHASH* nvlh,
	void (*func)(const char* key, const void* data));

/* N/V-hash value pairs enumeration. */
void p11_nvlh_doall_arg(
	LHASH* nvlh,
	void (*func)(const char* key, const void* data, const void* arg),
	const void* arg);

/* ---- p11_ver.c -- code version information -- declared in p11_ver.h */

/* ---- p11_trc.c -- tracing -- declared in p11_trc.h */


#endif

