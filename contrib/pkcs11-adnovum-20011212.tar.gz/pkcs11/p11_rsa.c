/* p11_rsa.c -- OpenSSL pkcs11 code -- PKCS#11 RSA operation interface. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


#include "p11_int.h"


#include <openssl/engine.h>
/* Note: we're not an engine but we need some engine-internal mechanisms. */
#include <../crypto/engine/eng_int.h>

#include <string.h>


/* RSA method functions */


/* Encrypt (sign) with the private key. */
static int p11_rsa_priv_enc(
	int flen,
	const unsigned char* from,
	unsigned char* to,
	RSA* rsa,
	int padding)
{
	p11_RSAOBJECTSPECIFICATION* ros = NULL;
	CK_OBJECT_HANDLE object = CK_INVALID_HANDLE;
	CK_MECHANISM mech;
	PKCS11* pkcs11;
	CK_SESSION_HANDLE session;
	CK_RV rv;
	CK_ULONG tlen;

	/* [guard(s)] */
	if (rsa == NULL || from == NULL || to == NULL) {
		PKCS11err(PKCS11_F_P11_RSA_PRIV_ENC, PKCS11_R_NULL_POINTER_PROVIDED);
		return -1;
	}

	ros = (p11_RSAOBJECTSPECIFICATION*)RSA_get_ex_data(rsa, 0);
	object = (CK_OBJECT_HANDLE)RSA_get_ex_data(rsa, 1);

	if (ros == NULL) {
		PKCS11err(PKCS11_F_P11_RSA_PRIV_ENC, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		goto err;
	}

	/* check padding */
	switch (padding) {
	case RSA_PKCS1_PADDING :
		break;
	case RSA_NO_PADDING :
	case RSA_SSLV23_PADDING :
	default :
		PKCS11err(PKCS11_F_P11_RSA_PRIV_ENC, PKCS11_R_UNSUPPORTED_PADDING_TYPE);
		goto err;
	}

	/* crypto mechanism */
	memset(&mech, 0, sizeof(mech));
	mech.mechanism = CKM_RSA_PKCS;
	mech.pParameter = NULL;
	mech.ulParameterLen = 0;

	/* set up resources */
	if (!p11_RSAOBJECTSPECIFICATION_setup(ros)) {
		goto err;
	}

	pkcs11 = p11_RSAOBJECTSPECIFICATION_getPKCS11(ros);
	session = p11_RSAOBJECTSPECIFICATION_getSession(ros);

	/* [guard(s)] */
	if (
		pkcs11 == NULL ||
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_SignInit == NULL ||
		pkcs11->functionList->C_Sign == NULL
	) {
		PKCS11err(PKCS11_F_P11_RSA_PRIV_ENC, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		goto err;
	}

	rv = (*pkcs11->functionList->C_SignInit)(session, &mech, object);
	if (rv != CKR_OK) {
		P11_TRC1("C_SignInit returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_RSA_PRIV_ENC, PKCS11_R_SIGN_INITIALIZATION_FAILED);
		goto err;
	}

	tlen = (CK_ULONG)RSA_size(rsa);
	/* [cast: API specification doesn't const...] */
	rv = (*pkcs11->functionList->C_Sign)(session, (CK_BYTE*)from, flen, to, &tlen);
	if (rv != CKR_OK) {
		P11_TRC1("C_Sign returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_RSA_PRIV_ENC, PKCS11_R_SIGN_FAILED);
		goto err;
	}

	return (int)tlen;

err :

	/* release no-longer needed resources */
	if (ros != NULL && !p11_RSAOBJECTSPECIFICATION_getKeep(ros)) {
		p11_RSAOBJECTSPECIFICATION_teardown(ros);
	}

	return -1;
}


/* Decrypt with the private key. */
static int p11_rsa_priv_dec(
	int flen,
	const unsigned char* from,
	unsigned char* to,
	RSA* rsa,
	int padding)
{
	p11_RSAOBJECTSPECIFICATION* ros = NULL;
	CK_OBJECT_HANDLE object = CK_INVALID_HANDLE;
	CK_MECHANISM mech;
	PKCS11* pkcs11;
	CK_SESSION_HANDLE session;
	CK_RV rv;
	CK_ULONG tlen;

	/* [guard(s)] */
	if (rsa == NULL || from == NULL || to == NULL) {
		PKCS11err(PKCS11_F_P11_RSA_PRIV_DEC, PKCS11_R_NULL_POINTER_PROVIDED);
		return -1;
	}

	ros = (p11_RSAOBJECTSPECIFICATION*)RSA_get_ex_data(rsa, 0);
	object = (CK_OBJECT_HANDLE)RSA_get_ex_data(rsa, 1);

	if (ros == NULL) {
		PKCS11err(PKCS11_F_P11_RSA_PRIV_DEC, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		goto err;
	}

	/* check padding */
	switch (padding) {
	case RSA_PKCS1_PADDING :
		break;
	case RSA_NO_PADDING :
	case RSA_SSLV23_PADDING :
	default :
		PKCS11err(PKCS11_F_P11_RSA_PRIV_DEC, PKCS11_R_UNSUPPORTED_PADDING_TYPE);
		goto err;
	}

	/* crypto mechanism */
	memset(&mech, 0, sizeof(mech));
	mech.mechanism = CKM_RSA_PKCS;
	mech.pParameter = NULL;
	mech.ulParameterLen = 0;

	/* set up resources */
	if (!p11_RSAOBJECTSPECIFICATION_setup(ros)) {
		goto err;
	}

	pkcs11 = p11_RSAOBJECTSPECIFICATION_getPKCS11(ros);
	session = p11_RSAOBJECTSPECIFICATION_getSession(ros);

	/* [guard(s)] */
	if (
		pkcs11 == NULL ||
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_DecryptInit == NULL ||
		pkcs11->functionList->C_Decrypt == NULL
	) {
		PKCS11err(PKCS11_F_P11_RSA_PRIV_DEC, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		goto err;
	}

	rv = (*pkcs11->functionList->C_DecryptInit)(session, &mech, object);
	if (rv != CKR_OK) {
		P11_TRC1("C_DecryptInit returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_RSA_PRIV_DEC, PKCS11_R_SIGN_INITIALIZATION_FAILED);
		goto err;
	}

	tlen = (CK_ULONG)RSA_size(rsa);
	/* [cast: API specification doesn't const...] */
	rv = (*pkcs11->functionList->C_Decrypt)(session, (CK_BYTE*)from, flen, to, &tlen);
	if (rv != CKR_OK) {
		P11_TRC1("C_Decrypt returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_RSA_PRIV_DEC, PKCS11_R_SIGN_FAILED);
		goto err;
	}

	return (int)tlen;

err :

	/* release no-longer needed resources */
	if (ros != NULL && !p11_RSAOBJECTSPECIFICATION_getKeep(ros)) {
		p11_RSAOBJECTSPECIFICATION_teardown(ros);
	}

	return -1;
}


/* Init hook. */
static int p11_rsa_init(RSA* rsa)
{
	/* [guard(s)] */
	if (rsa == NULL) {
		PKCS11err(PKCS11_F_P11_RSA_INIT, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	rsa->flags |= RSA_FLAG_CACHE_PUBLIC | RSA_FLAG_CACHE_PRIVATE;

	/* OK. */
	return 1;
}


/* Finish hook. */
static int p11_rsa_finish(RSA* rsa)
{
	/* [NULL is, as always, fine.] */
	if (rsa == NULL) {
		/* OK. */
		return 1;
	}

	if (rsa->_method_mod_n != NULL) {
		BN_MONT_CTX_free(rsa->_method_mod_n);
	}
	if (rsa->_method_mod_p != NULL) {
		BN_MONT_CTX_free(rsa->_method_mod_p);
	}
	if (rsa->_method_mod_q != NULL) {
		BN_MONT_CTX_free(rsa->_method_mod_q);
	}

	/* OK. */
	return 1;
}


/* RSA method data */
static /* const */ RSA_METHOD p11_rsa_meth =
{
	"PKCS#11 RSA method", /* name */
	NULL, /* rsa_pub_enc */
	NULL, /* rsa_pub_dec */
	p11_rsa_priv_enc, /* rsa_priv_enc */
	p11_rsa_priv_dec, /* rsa_priv_dec */
	NULL, /* rsa_mod_exp */
	BN_mod_exp_mont, /* bn_mod_exp */
	p11_rsa_init, /* init */
	p11_rsa_finish, /* finish */
	RSA_METHOD_FLAG_NO_CHECK, /* flags */
	NULL, /* app_data */
	NULL, /* rsa_sign */
	NULL, /* rsa_verify */
};


/* engine data */
static /* const */ ENGINE p11_engine_PKCS11 =
{
	"PKCS#11", /* id */
	"PKCS#11", /* name */

	&p11_rsa_meth, /* rsa_meth */
	NULL, /* dsa_meth */
	NULL, /* dh_meth */
	NULL, /* rand_meth */

	NULL, /* bn_mod_exp */
	NULL, /* bn_mod_exp_crt */

	NULL, /* destroy */
	NULL, /* init */
	NULL, /* finish */
	NULL, /* ctrl */

	NULL, /* load_privkey */
	NULL, /* load_pubkey */

	NULL, /* ciphers */

	NULL, /* cmd_defns */
	0, /* flags */

	/* Note: must have the following reference counts
	** on non-zero to prevent freeing this non-heap data.
	*/
	1, /* struct_ref */
	1, /* funct_ref */

	{NULL, 0}, /* ex_data */

	NULL, /* prev */
	NULL, /* next */
};


/* Instanciate an RSA method, get a private key handle on it. */
/* TODO: better name? */
EVP_PKEY* p11_RSAPrivateKeyEvp(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	p11_RSAOBJECTSPECIFICATION* ros)
{
	RSA* rsa = NULL;
	void *modulus = NULL, *publicexponent = NULL;
	int modulussize, publicexponentsize;

	int idsize;
	void* id = NULL;
	CK_OBJECT_HANDLE proxyobject;

	EVP_PKEY* key = NULL;

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_RSAPRIVATEKEYEVP, PKCS11_R_NULL_POINTER_PROVIDED);
		return NULL;
	}

	/* instanciate an RSA method */
	rsa = RSA_new_method(&p11_engine_PKCS11);
	if (rsa == NULL) {
		PKCS11err(PKCS11_F_P11_RSAPRIVATEKEYEVP, PKCS11_R_CANNOT_GET_RSA_METHOD);
		goto err;
	}

	/*assert(rsa->n==NULL&&rsa->e==NULL);*/
	rsa->n = NULL;
	rsa->e = NULL;

	/* get modulus and public exponent */

	modulus = p11_getObjectAttribute(
		pkcs11,
		session,
		object,
		CKA_MODULUS,
		&modulussize);

	publicexponent = p11_getObjectAttribute(
		pkcs11,
		session,
		object,
		CKA_PUBLIC_EXPONENT,
		&publicexponentsize);

	/* Try to get the values from the corresponding
	** public key, if it failed.
	*/
	if (modulus == NULL || publicexponent == NULL) {

		if (modulus != NULL) {
			OPENSSL_free(modulus);
			modulus = NULL;
		}
		if (publicexponent != NULL) {
			OPENSSL_free(publicexponent);
			publicexponent = NULL;
		}

		/* get id */
		idsize = 0;
		id = p11_getObjectId(
			pkcs11,
			session,
			object,
			&idsize);
		if (id == NULL) {
			goto err;
		}

		/* find corresponding public key */
		proxyobject = p11_findRSAObject(
			pkcs11,
			session,
			CKO_PUBLIC_KEY,
			NULL,
			id,
			idsize);
		OPENSSL_free(id);
		id = NULL;
		if (proxyobject == CK_INVALID_HANDLE) {
			goto err;
		}

		/* get modulus and public exponent from public key */
		modulus = p11_getObjectAttribute(
			pkcs11,
			session,
			proxyobject,
			CKA_MODULUS,
			&modulussize);
		publicexponent = p11_getObjectAttribute(
			pkcs11,
			session,
			proxyobject,
			CKA_PUBLIC_EXPONENT,
			&publicexponentsize);
	}

	/* TODO: shall we try to get the values from the
	** corresponding certificate if this fails?
	*/

	if (modulus == NULL || publicexponent == NULL) {
		goto err;
	}

	/*assert(rsa->n==NULL&&rsa->e==NULL);*/

	rsa->n = BN_bin2bn(modulus, modulussize, NULL);
	if (rsa->n == NULL) {
		PKCS11err(PKCS11_F_P11_RSAPRIVATEKEYEVP, PKCS11_R_BAD_MODULUS);
		goto err;
	}

	rsa->e = BN_bin2bn(publicexponent, publicexponentsize, NULL);
	if (rsa->e == NULL) {
		PKCS11err(PKCS11_F_P11_RSAPRIVATEKEYEVP, PKCS11_R_BAD_PUBLIC_EXPONENT);
		goto err;
	}

	OPENSSL_free(modulus);
	modulus = NULL;
	OPENSSL_free(publicexponent);
	publicexponent = NULL;

	key = EVP_PKEY_new();
	if (key == NULL) {
		PKCS11err(PKCS11_F_P11_RSAPRIVATEKEYEVP, PKCS11_R_PKEY_NEW_FAILED);
		goto err;
	}

	/* Q: are #0 and #1 anyhow suboptimal? */

	RSA_set_ex_data(rsa, 0, (void*)ros);
	RSA_set_ex_data(rsa, 1, (void*)object);

	EVP_PKEY_assign(key, EVP_PKEY_RSA, (char*)rsa);

	return key;

err :

	if (rsa != NULL && rsa->n != NULL) {
		/* TODO */
	}
	if (rsa != NULL && rsa->e != NULL) {
		/* TODO */
	}

	if (publicexponent != NULL) {
		OPENSSL_free(publicexponent);
	}
	if (modulus != NULL) {
		OPENSSL_free(modulus);
	}

	if (id != NULL) {
		OPENSSL_free(id);
	}

	return NULL;
}

