/* p11_test.c -- OpenSSL pkcs11 code -- unit testing, external interface. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* interface to be tested */
#include "pkcs11.h"


/* 'empty translation unit' warning preventor */
int p11_test_dummy = 'x';


#if defined(PKCS11_TEST)


/* test helper macros */
#include "p11_test.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#if defined(P11_TEST_FORK) && defined(unix)
#include <unistd.h>
#include <sys/wait.h>
#endif


/* Cryptoki library to test.
** Note that this is only used in part of the tests;
** some of them require much more context (object ids, etc.).
*/
#define CRYPTOKI_LIBRARY "cryptoki"
/* "/opt/Eracom/lib/libcryptoki.so" */


/* PIN (password) callback. */
static int p11_test_pin_cb(char* buf, int size, int rwflag, void* userdata)
{
	const char* pw = (const char*)userdata;

	/* [unused(s)] */
	(void)rwflag;

	/* [guard(s)] */
	if (buf == NULL || size < 0) {
		return 0;
	}
	if (size < (int)strlen(pw) + 1) {
		return 0;
	}
	if (userdata == NULL) {
		return 0;
	}

	strcpy(buf, pw);

	/* OK. */
	return 1;
}


/* Test external interfaces of the OpenSSL PKCS#11 code.
** Returns the number of flaws; 0 is OK.
** Prints error diagnostics to 'out'.
*/
int p11_test_external(FILE* out)
{
	/* required p11-test preamble */
	P11_TEST_VARS(out);


	/* own variables */

	const char* cryptoki_library = NULL;
	int login = 0;

	PKCS11* pkcs11;
	struct stat st;

#if defined(P11_TEST_FORK) && defined(unix)
	pid_t pid;
#endif


	/* set up */
	cryptoki_library = CRYPTOKI_LIBRARY;

	fprintf(stdout, "Testing '%s'.\n", cryptoki_library);
	fflush(stdout);


	/* test PKCS11_new() */

	/* TODO: check OpenSSL error code, too */

	/* assert some initial error handling */
	/* Note: PKCS11_new(NULL) now tries to load a 'default' library
	** and may return NULL or not NULL.
	*/
	/* P11_TEST_ASSERT(PKCS11_new(NULL) == NULL); */

	/* assert the cryptoki library to be tested is there
	** (only if it's for sure a filename; see DSL_load)
	*/
	if (
		strchr(cryptoki_library, '/') != NULL ||
		strchr(cryptoki_library, '\\') != NULL
	) {
		P11_TEST_ASSERT(stat(cryptoki_library, &st) != -1);
	}

	/* [init must succeed] */
	pkcs11 = PKCS11_new(cryptoki_library);
	P11_TEST_ASSERT(pkcs11 != NULL);


	/* test PKCS11_setDoLogin() */
	if (login) {
		P11_TEST_ASSERT(PKCS11_setDoLogin(pkcs11, 1));
	}


	/* test PKCS11_dumpInfo() */

	/* assert some NULL pointer handling */
	P11_TEST_ASSERT(PKCS11_dumpInfo(NULL, NULL));
	P11_TEST_ASSERT(PKCS11_dumpInfo(NULL, stdout));
	P11_TEST_ASSERT(PKCS11_dumpInfo(pkcs11, NULL));

	fprintf(stdout, "Dump output...\n");
	fflush(stdout);

	/* Note: we're not testing the PKCS11_dumpInfo output,
	** that should be done by a human.
	** Note: this will produce quite some output to stdout.
	*/
	P11_TEST_ASSERT(PKCS11_dumpInfo(pkcs11, stdout));
	/* P11_TEST_ASSERT(PKCS11_dumpInfo(pkcs11, fopen("pkcs11.dmp", "wb"))); */


	/* test PKCS11_free() */

	/* assert NULL pointer handling */
	/* [must be ok] */
	P11_TEST_ASSERT(PKCS11_free(NULL));

	/* [free must succeed] */
	P11_TEST_ASSERT(PKCS11_free(pkcs11));


	/* ---- Note: the following tests use quite specific
	** token names and token object labels/ids.
	** You probably have to rename these for your own tests.
	*/

	/* test PKCS11_get_cert() */

	/* test old specification format */
	P11_TEST_ASSERT(PKCS11_get_cert("PKCS11|!|eric||two", NULL, NULL) != NULL);

	/* test current specification format, object label */
	P11_TEST_ASSERT(PKCS11_get_cert(
		"pkcs11:library=cryptoki&tokenlabel=eric&objectlabel=two&dologin=true",
		NULL,
		NULL) != NULL);

	/* test object id */
	P11_TEST_ASSERT(PKCS11_get_cert(
		"pkcs11:"
			"library=cryptoki"
			"&tokenlabel=eric"
			"&objectid=01:8b:22:6b:af:8c:a3:5a:aa:bd:4f:6a:e2:f5:82:1f:50:17:0a:3d"
			"&dologin=true",
		NULL,
		NULL) != NULL);

	/* missing object label and object id can fail  */
	P11_TEST_ASSERT(PKCS11_get_cert(
		"pkcs11:library=cryptoki&tokenlabel=eric&dologin=true",
		NULL,
		NULL) == NULL || 1);

	/* slot number */
	P11_TEST_ASSERT(PKCS11_get_cert(
		"pkcs11:library=cryptoki&slotnumber=1&objectlabel=two&dologin=true",
		NULL,
		NULL) != NULL);

	/* missing token label can fail  */
	P11_TEST_ASSERT(PKCS11_get_cert(
		"pkcs11:library=cryptoki&objectlabel=two&dologin=true",
		NULL,
		NULL) == NULL || 1);

	/* test PKCS11_get_private_key() */

	P11_TEST_ASSERT(PKCS11_get_private_key(
		"pkcs11:library=cryptoki&tokenlabel=eric&objectlabel=two&dologin=true",
		NULL,
		NULL) != NULL);

	/* test with pin callback */
	P11_TEST_ASSERT(PKCS11_get_private_key(
		"pkcs11:library=cryptoki&tokenlabel=eric&objectlabel=two&dologin=true",
		p11_test_pin_cb,
		(void*)"jada") != NULL);

#if defined(P11_TEST_FORK) && defined(unix)

	/* fork test */
	/* [forked pkcs11 handle should(!) be invalid] */

	/* init cryptoki */
	pkcs11 = PKCS11_new(cryptoki_library);
	P11_TEST_ASSERT(pkcs11 != NULL);

	/* flush io */
	fflush(out);
	fflush(stdout);

	/* fork */
	pid = fork();
	P11_TEST_ASSERT(pid != -1);

	/* child */
	if (pid == 0) {

		/* [forked pkcs11 handle should(!) be invalid] */
		P11_TEST_ASSERT(!PKCS11_dumpInfo(pkcs11, stdout));

		/* re-initialize */
		P11_TEST_ASSERT(PKCS11_reinit(pkcs11));

		/* [forked pkcs11 handle must be valid after re-initializing] */
		P11_TEST_ASSERT(PKCS11_dumpInfo(pkcs11, stdout));

		/* re-initialize some more [must be ok] */
		P11_TEST_ASSERT(PKCS11_reinit(pkcs11));

		/* flush io */
		fflush(out);
		fflush(stdout);

		/* Note: not returning P11_TEST_FLAWS() or similar here... */
		_exit(0);
	}

	/* Note: not asserting _exit is called in child, etc. */
	wait(0);

	P11_TEST_ASSERT(PKCS11_free(pkcs11));

#endif


done :

	/* required p11-test epilogue */
	return P11_TEST_FLAWS();
}


/* TODO: call apps_startup()? */

/* Note: no trailing ;. */
P11_TEST_MAIN1(p11_test_external)


#endif

