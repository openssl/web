/* p11_test.h -- OpenSSL pkcs11 code -- unit testing helper macros. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* [include guard] */
#ifndef P11_TEST_H
#define P11_TEST_H


/* Needed for FILE*.
** Note: since we define only macros here, this inclusion could be
** postponed until their usage, but this prevents nasty problems.
*/
#include <stdio.h>


/* Define and initialize the test variables.
** Note: using the __FILE__ macro is typically redundant and
** disturbing, so we don't.
*/
#define P11_TEST_VARS(out) \
	static const char p11_test_msg[] = \
		"Testcase #%d failed at line %d: %s.\n"; \
	int p11_test_count = 0, p11_test_flaws = 0; \
	FILE* p11_test_out = (out)

/* Number of flaws. */
#define P11_TEST_FLAWS() \
	p11_test_flaws

/* Assert a test expression.
** Prints error diagnostics and counts up flaws.
** Flushes I/O, to make the test program more inert against crashes
** (which we seek to legally provoke...).
*/
#define P11_TEST_ASSERT(expression) \
	do { \
		p11_test_count++; \
		if (!(expression)) { \
			p11_test_flaws++; \
			if (p11_test_out != NULL) { \
				fprintf( \
					p11_test_out, \
					p11_test_msg, \
					p11_test_count, \
					__LINE__, \
					#expression); \
				fflush(p11_test_out); \
			} \
		} \
	} while (0)


/* sample of a test wrapping main() */
/* Note: error messages go to stderr, rest goes to stdout,
** which makes it easy to filter.
*/
#define P11_TEST_MAIN1(test1) \
	int main(void) \
	{ \
		int flaws = 0; \
		flaws += (test1)(stderr); \
		if (flaws != 0) { \
			fprintf(stderr, "%d flaw(s)\n", flaws); \
			fprintf(stderr, "Test failed.\n"); \
			return flaws; \
		} \
		fprintf(stdout, "Test was successful.\n"); \
		return 0; \
	}


/* Note: use the macros above like
** int test1(FILE* out)
** {
** 	P11_TEST_VARS(out);
**
** 	own variables...
**
** 	assertions like...
** 	P11_TEST_ASSERT(...);
**
** 	return P11_TEST_FLAWS();
** }
**
** no trailing ;...
** P11_TEST_MAIN1(test1)
*/


#endif

