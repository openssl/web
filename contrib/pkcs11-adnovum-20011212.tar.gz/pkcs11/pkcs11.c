/* pkcs11.c -- openssl pkcs11 command line tool frontend. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */

#include "pkcs11.h"

#include "apps.h"
#include <openssl/err.h>

#include <string.h>
#include <errno.h>

/*#include <stdio.h>*/
/*#include <stdlib.h>*/
/*#include <openssl/bio.h>*/
/*#include <openssl/dso.h>*/

#define PROG pkcs11_main


/* print usage. */
static void printUsage(void)
{
	BIO_printf(bio_err, "usage: openssl pkcs11 [options]\n");
	BIO_printf(bio_err, "dump PKCS#11 device contents\n");

	BIO_printf(bio_err, "options are:\n");

	BIO_printf(bio_err, "    -forcelogin|-f: force login into token(s)\n");
	BIO_printf(bio_err, "    -library|-l <library>: specify dynamic shared cyptoki library\n");
	BIO_printf(bio_err, "    -out|-o <file>: specify info output file\n");

	BIO_printf(bio_err, "\n");
	ERR_print_errors(bio_err);
}

/* entry point. */
int MAIN(int argc, char** argv)
{
	/* PKCS#11 library accessor. */
	PKCS11* pkcs11 = NULL;

	/* output destination. */
	const char* outFile = NULL;
	FILE* out = stdout;

	/* cryptoki (PKCS#11) library */
	char* lib = NULL;

	int forcelogin = 0;

	if (bio_err == NULL) {
		bio_err = BIO_new(BIO_s_file());
		if (bio_err != NULL) {
			BIO_set_fp(bio_err, stderr, BIO_NOCLOSE | BIO_FP_TEXT);
		}
	}

	/* No options means: 'print options'. */
	if (argc == 1) {
		printUsage();
		EXIT(0);
	}

	/* options parsing loop */
	for (argv++, argc--; argc > 0; argv++, argc--) {
		if (
			strcmp(*argv, "-forcelogin") == 0 ||
			strcmp(*argv, "-f") == 0
		){
			forcelogin++;
		} else if (
			strcmp(*argv, "-library") == 0 ||
			strcmp(*argv, "-l") == 0
		) {
			if (--argc < 1) {
				printUsage();
				return 1;
			}
			lib = *++argv;
		} else if (
			strcmp(*argv, "-out") == 0 ||
			strcmp(*argv, "-o") == 0
		) {
			if (--argc < 1) {
				printUsage();
				return 1;
			}
			outFile = *++argv;
		} else {
			BIO_printf(bio_err, "unknown option '%s'\n", *argv);
			printUsage();
			return 1;
		}
	}

	/* Load cryptoki library. */
	pkcs11 = PKCS11_new(lib);
	if (pkcs11 == NULL) {
		BIO_printf(bio_err, "loading failed\n");
		BIO_printf(bio_err, "\n");
		ERR_print_errors(bio_err);
		EXIT(0);
	}

	PKCS11_setDoLogin(pkcs11, forcelogin);

	/* Open output, if requested, (for append). */
	if (outFile != NULL) {
		out = fopen(outFile, "a");
		if (out == NULL) {
			BIO_printf(
				bio_err,
				"could not open '%s' for writing: %s\n",
				outFile,
				strerror(errno));
			(void)PKCS11_free(pkcs11);
			EXIT(0);
		}
	}

	PKCS11_dumpInfo(pkcs11, out);

	fflush(out);
	if (outFile != NULL) {
		fclose(out);
		out = NULL;
	}

	(void)PKCS11_free(pkcs11);

	ERR_print_errors(bio_err);
	EXIT(0);
}

