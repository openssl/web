/* p11_dump.c -- OpenSSL pkcs11 code -- PKCS#11 information dumping. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* NOTE: The tables enumerating the CK... constants were generated
** semi-automatically by XEmacs from the constants defined in the
** PKCS#11 specification pkcs11t.h [feel free to write your own few
** lines of Perl].
** NOTE: They are located in constant, read-only memory.
*/


#include "p11_int.h"

#include <string.h>


typedef struct p11_f2n_struct p11_f2n;

/* Flag to readable name matching. */
struct p11_f2n_struct {
	CK_FLAGS key;
	const char* value;
};

/* Note: this works as long as CK_HW_FEATURE_TYPE, CK_KEY_TYPE
** and CK_CERTIFICATE_TYPE are (typedef'd) aliases of CK_OBJECT_CLASS.
** Else you'll have to add redundant code, for each distinct type.
*/
typedef CK_OBJECT_CLASS p11_TYPE;

typedef struct p11_t2n_struct p11_t2n;

/* Type to readable name matching. */
struct p11_t2n_struct {
	p11_TYPE key;
	const char* value;
};


/* Dump information about the PKCS#11 library. */
int p11_dumpLibrary(PKCS11* pkcs11, FILE* out)
{
	CK_INFO libraryinfo;
	CK_RV rv;

	/* Skip if some of it is NULL. */
	if (pkcs11 == NULL || out == NULL) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetInfo == NULL
	) {
		PKCS11err(PKCS11_F_P11_DUMPLIBRARY, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* Note: 'title' (below) printed _after_ the first PKCS#11 call (C_GetInfo),
	** so we won't do any output if that first call fails.
	*/

	memset(&libraryinfo, 0, sizeof(libraryinfo));
	rv = (*pkcs11->functionList->C_GetInfo)(&libraryinfo);
	if (rv != CKR_OK) {
		P11_TRC1("C_GetInfo returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_DUMPLIBRARY, PKCS11_R_CANNOT_GET_LIBRARYINFO);
		return 0;
	}

	/* title [postponed, see comment above] */
	fprintf(out, "-- Cryptoki library --\n\n");

	/* data */

	fprintf(out, "cryptoki version: ");
	p11_dumpVersion(&libraryinfo.cryptokiVersion, out);
	fprintf(out, "\n");

	fprintf(out, "manufacturer id: ");
	p11_dumpStringE(libraryinfo.manufacturerID, sizeof(libraryinfo.manufacturerID), out);
	fprintf(out, "\n");

	fprintf(out, "flags: ");
	p11_dumpLibraryFlags(libraryinfo.flags, out);
	fprintf(out, "\n");

	fprintf(out, "library description: ");
	p11_dumpStringE(
		libraryinfo.libraryDescription,
		sizeof(libraryinfo.libraryDescription),
		out);
	fprintf(out, "\n");

	fprintf(out, "library version: ");
	p11_dumpVersion(&libraryinfo.libraryVersion, out);
	fprintf(out, "\n");

	fprintf(out, "\n");

	/* function list version */

	fprintf(out, "function list version: ");
	p11_dumpVersion(&pkcs11->functionList->version, out);
	fprintf(out, "\n");

	fprintf(out, "\n");
	fflush(out);

	/* OK. */
	return 1;
}


/* Dump information about a slot and its token -- callback. */
static int p11_dumpSlot_cb(PKCS11* pkcs11, CK_SLOT_ID id, void* cbdata)
{
	/* Ignore errors and go on.  There may be slots without tokens, etc. */
	p11_dumpSlot(
		pkcs11,
		id,
		*(int*)((void**)cbdata)[0],
		*(FILE**)((void**)cbdata)[1]);
	p11_discard_errors();

	/* OK. */
	return 1;
}


/* Dump information about slots. */
int p11_dumpSlots(PKCS11* pkcs11, int dumpObjects, FILE* out)
{
	void* cbdata[2];

	/* Skip if some of it is NULL. */
	if (pkcs11 == NULL || out == NULL) {
		/* OK. */
		return 1;
	}

	/* Note: it would be valuable if 'title' (below) be printed
	** _after_ the first PKCS#11 call, so we wouldn't do any output
	** if that first call fails.
	*/
	/* title */
	fprintf(out, "-- Slots --\n\n");

	/* [ugly but true; callback data holder;
	** (don't cast int to pointer, just cast pointers.);
	** use reference on every member (on references too), for consistence.]
	*/
	cbdata[0] = (void*)&dumpObjects;
	cbdata[1] = (void*)&out;

	/* (In dumping) Get a list of all slots, i.e. the ones that have a token,
	** and the empty slots.
	*/

	/* Note: it would be valuable if we could catch 'zero' slots
	** and write diagnostics about it, e.g. fprintf(out, "No slots\n\n");
	**/

	/* [Ignore errors and go on.  There may be slots without tokens, etc.] */

	p11_enumerateSlots(pkcs11, p11_dumpSlot_cb, (void*)cbdata);
	p11_discard_errors();

	fprintf(out, "\n");
	fflush(out);

	/* OK. */
	return 1;
}


/* Dump information about a slot and its token. */
int p11_dumpSlot(
	PKCS11* pkcs11,
	CK_SLOT_ID id,
	int dumpObjects,
	FILE* out)
{
	/* Skip if some of it is NULL. */
	if (out == NULL) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_DUMPSLOT, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	/* title */
	fprintf(out, "-- Slot %lu --\n\n", id);

	/* slot info */
	if (!p11_dumpSlotOnly(pkcs11, id, out)) {
		/* [give up if we can't get info on the slot] */
		return 0;
	}

	/* token info */
	if (!p11_dumpTokenOnly(pkcs11, id, out)) {
		/* [give up, there'll be no objects if there's no token] */
		return 0;
	}

	/* mechanism info */
	/* Note: in PKCS#11 hardware with logical tokens,
	** the mechanisms tend to be the same over all tokens.
	** We'll print them however.
	*/
	p11_dumpMechanisms(pkcs11, id, out);

	/* token objects info */
	if (dumpObjects) {
		if (!p11_dumpObjects(pkcs11, id, out)) {
			return 0;
		}
	}

	/* OK. */
	return 1;
}


/* Dump information about a slot only. */
int p11_dumpSlotOnly(PKCS11* pkcs11, CK_SLOT_ID id, FILE* out)
{
	CK_RV rv;
	CK_SLOT_INFO slotinfo;

	/* Skip if some of it is NULL. */
	if (out == NULL) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_DUMPSLOTONLY, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetSlotInfo == NULL
	) {
		PKCS11err(PKCS11_F_P11_DUMPSLOTONLY, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* Note: (most probably in any case) we don't need to log in
	** to get _all_ available slot information.
	*/

	memset(&slotinfo, 0, sizeof(slotinfo));
	rv = (*pkcs11->functionList->C_GetSlotInfo)(id, &slotinfo);
	if (rv != CKR_OK) {
		P11_TRC1("C_GetSlotInfo returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_DUMPSLOTONLY, PKCS11_R_CANNOT_GET_SLOTINFO);
		return 0;
	}

	fprintf(out, "Slot info\n\n");

	fprintf(out, "description: ");
	p11_dumpStringE(slotinfo.slotDescription, sizeof(slotinfo.slotDescription), out);
	fprintf(out, "\n");

	fprintf(out, "manufacturer: ");
	p11_dumpStringE(slotinfo.manufacturerID, sizeof(slotinfo.manufacturerID), out);
	fprintf(out, "\n");

	fprintf(out, "flags: ");
	p11_dumpSlotFlags(slotinfo.flags, out);
	fprintf(out, "\n");

	fprintf(out, "hardware version: ");
	p11_dumpVersion(&slotinfo.hardwareVersion, out);
	fprintf(out, "\n");

	fprintf(out, "firmware version: ");
	p11_dumpVersion(&slotinfo.firmwareVersion, out);
	fprintf(out, "\n");

	fprintf(out, "\n");
	fflush(out);

	/* OK. */
	return 1;
}


/* Dump information about a token only. */
int p11_dumpTokenOnly(PKCS11* pkcs11, CK_SLOT_ID id, FILE* out)
{
	CK_RV rv;
	CK_TOKEN_INFO tokeninfo;

	/* Skip if some of it is NULL. */
	if (out == NULL) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_DUMPTOKENONLY, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetTokenInfo == NULL
	) {
		PKCS11err(PKCS11_F_P11_DUMPTOKENONLY, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* Note: (most probably in any case) we don't need to log in
	** to get _all_ available token information, do we?
	*/

	memset(&tokeninfo, 0, sizeof(tokeninfo));
	rv = (*pkcs11->functionList->C_GetTokenInfo)(id, &tokeninfo);

	if (rv == CKR_TOKEN_NOT_PRESENT) {
		P11_TRC0("[no token present]");
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_DUMPTOKENONLY, PKCS11_R_NO_TOKEN_PRESENT);
		return 0;
	}

	if (rv != CKR_OK) {
		P11_TRC1("C_GetTokenInfo returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_DUMPTOKENONLY, PKCS11_R_CANNOT_GET_TOKENINFO);
		return 0;
	}

	fprintf(out, "Token info\n\n");

	/* [from the PKCS#11 specification:]
	** "Note: The fields ulMaxSessionCount, ulSessionCount,
	** ulMaxRwSessionCount, ulRwSessionCount, ulTotalPublicMemory,
	** ulFreePublicMemory, ulTotalPrivateMemory, and ulFreePrivateMemory
	** can have the special value CK_UNAVAILABLE_INFORMATION, which
	** means that the token and/or library is unable or unwilling to
	** provide that information.  In addition, the fields
	** ulMaxSessionCount and ulMaxRwSessionCount can have the special
	** value CK_EFFECTIVELY_INFINITE, which means that there is no
	** practical limit on the number of sessions (resp. R/W sessions) an
	** application can have open with the token."
	*/

	fprintf(out, "label: ");
	p11_dumpStringE(tokeninfo.label, sizeof(tokeninfo.label), out);
	fprintf(out, "\n");

	fprintf(out, "manufacturer id: ");
	p11_dumpStringE(tokeninfo.manufacturerID, sizeof(tokeninfo.manufacturerID), out);
	fprintf(out, "\n");

	fprintf(out, "model: ");
	p11_dumpStringE(tokeninfo.model, sizeof(tokeninfo.model), out);
	fprintf(out, "\n");

	fprintf(out, "serial number: ");
	p11_dumpStringE(tokeninfo.serialNumber, sizeof(tokeninfo.serialNumber), out);
	fprintf(out, "\n");

	fprintf(out, "flags: ");
	p11_dumpTokenFlags(tokeninfo.flags, out);
	fprintf(out, "\n");

	fprintf(out, "session counts: ");
	p11_dumpNumberU(tokeninfo.ulSessionCount, out);
	fprintf(out, " / ");
	p11_dumpNumberUI(tokeninfo.ulMaxSessionCount, out);
	fprintf(out, "\n");

	fprintf(out, "r/w session counts: ");
	p11_dumpNumberU(tokeninfo.ulRwSessionCount, out);
	fprintf(out, " / ");
	p11_dumpNumberUI(tokeninfo.ulMaxRwSessionCount, out);
	fprintf(out, "\n");

	fprintf(out, "pin lengths: ");
	p11_dumpNumber(tokeninfo.ulMinPinLen, out);
	fprintf(out, " / ");
	p11_dumpNumber(tokeninfo.ulMaxPinLen, out);
	fprintf(out, "\n");

	fprintf(out, "public memory: ");
	p11_dumpNumberU(tokeninfo.ulFreePublicMemory, out);
	fprintf(out, " / ");
	p11_dumpNumberU(tokeninfo.ulTotalPublicMemory, out);
	fprintf(out, "\n");

	fprintf(out, "private memory: ");
	p11_dumpNumberU(tokeninfo.ulFreePrivateMemory, out);
	fprintf(out, " / ");
	p11_dumpNumberU(tokeninfo.ulTotalPrivateMemory, out);
	fprintf(out, "\n");

	fprintf(out, "hardware version: ");
	p11_dumpVersion(&tokeninfo.hardwareVersion, out);
	fprintf(out, "\n");

	fprintf(out, "firmware version: ");
	p11_dumpVersion(&tokeninfo.firmwareVersion, out);
	fprintf(out, "\n");

	fprintf(out, "utc time: ");
	p11_dumpStringE(tokeninfo.utcTime, sizeof(tokeninfo.utcTime), out);
	fprintf(out, "\n");

	fprintf(out, "\n");
	fflush(out);

	/* OK. */
	return 1;
}


/* Dump information token mechanisms. */
int p11_dumpMechanisms(PKCS11* pkcs11, CK_SLOT_ID id, FILE* out)
{
	CK_RV rv;
	CK_ULONG n;
	CK_MECHANISM_TYPE* mechanisms = NULL;
	int i;
	CK_MECHANISM_INFO mechanisminfo;
	const char* name;
	char buf[64];

	/* Skip if some of it is NULL. */
	if (out == NULL) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_DUMPMECHANISMS, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetMechanismList == NULL ||
		pkcs11->functionList->C_GetMechanismInfo == NULL
	) {
		PKCS11err(PKCS11_F_P11_DUMPMECHANISMS, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	n = 0;
	rv = (*pkcs11->functionList->C_GetMechanismList)(id, NULL, &n);
	if (rv != CKR_OK) {
		P11_TRC1("C_GetMechanismList returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_DUMPMECHANISMS, PKCS11_R_CANNOT_GET_MECHANISMINFO);
		goto err;
	}

	if (n == 0) {
		P11_TRC0("[no mechanisms]");
		return 1;
	}

	mechanisms = (CK_MECHANISM_TYPE*)OPENSSL_malloc(n * sizeof(*mechanisms));
	if (mechanisms == NULL) {
		PKCS11err(PKCS11_F_P11_DUMPMECHANISMS, PKCS11_R_OUT_OF_MEMORY);
		goto err;
	}
	memset(mechanisms, 0, n * sizeof(*mechanisms));

	rv = (*pkcs11->functionList->C_GetMechanismList)(id, mechanisms, &n);
	if (rv != CKR_OK) {
		P11_TRC1("C_GetMechanismList returned %s", p11_errorName(rv));
		p11_push_CK_RV(rv);
		PKCS11err(PKCS11_F_P11_DUMPMECHANISMS, PKCS11_R_CANNOT_GET_MECHANISMINFO);
		goto err;
	}

	for (i = 0; i < n; i++) {
		memset(&mechanisminfo, 0, sizeof(mechanisminfo));

		rv = (*pkcs11->functionList->C_GetMechanismInfo)(id, mechanisms[i], &mechanisminfo);
		if (rv != CKR_OK) {
			P11_TRC1("C_GetMechanismInfo returned %s", p11_errorName(rv));
			p11_push_CK_RV(rv);
			PKCS11err(PKCS11_F_P11_DUMPMECHANISMS, PKCS11_R_CANNOT_GET_MECHANISMINFO);
			goto err;
		}

		name = p11_mechanismNameB(mechanisms[i], buf, sizeof(buf));
		fprintf(out, "mechanism %s: ", name);

		/* Note: we probably could suppress key sizes 0/0,
		** which mean 'not applicable'.
		*/
		fprintf(out, "key sizes: ");
		p11_dumpNumber(mechanisminfo.ulMinKeySize, out);
		fprintf(out, " / ");
		p11_dumpNumber(mechanisminfo.ulMaxKeySize, out);

		fprintf(out, ", ");
		fprintf(out, "flags: ");
		p11_dumpMechanismFlags(mechanisminfo.flags, out);

		fprintf(out, "\n");
	}

	OPENSSL_free(mechanisms);
	mechanisms = NULL;

	fprintf(out, "\n");
	fflush(out);

	/* OK. */
	return 1;

err :

	if (mechanisms != NULL) {
		OPENSSL_free(mechanisms);
	}

	return 0;
}

/* Dump information about a token object -- callback. */
static int p11_dumpObject_cb(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	void* cbdata)
{
	/* [only a wrapper...] */
	return p11_dumpObject(pkcs11, session, object, (FILE*)cbdata);
}


/* Dump information about token objects. */
int p11_dumpObjects(PKCS11* pkcs11, CK_SLOT_ID id, FILE* out)
{
	CK_SESSION_HANDLE session = CK_INVALID_HANDLE;

	/* Skip if some of it is NULL. */
	if (out == NULL) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_DUMPOBJECTS, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	/* Get a new session. */
	session = p11_session_new(pkcs11, id);
	if (session == CK_INVALID_HANDLE) {
		PKCS11err(PKCS11_F_P11_DUMPOBJECTS, PKCS11_R_CANNOT_GET_NEW_SESSION);
		return 0;
	}

	/* Log in, if desired. */
	/* TODO: check login-required flag too? */
	if (pkcs11->doLogin) {
		if (!p11_login(pkcs11, session)) {
			/*EMPTY*/
			/* ignore canceled or failed login in dumping */
			/* p11_discard_errors(); */
			/* goto err; */
		}
	}

	/* Enumerate the objects. */
	if (!p11_enumerateObjects(pkcs11, session, p11_dumpObject_cb, (void*)out)) {
		PKCS11err(PKCS11_F_P11_DUMPOBJECTS, PKCS11_R_ENUMERATION_CANCELED);
		goto err;
	}

	/* Note: We actually don't log out, we just free (close) the session. */

	if (!p11_session_free(pkcs11, session)) {
		return 0;
	}

	/* OK. */
	return 1;

err :

	if (session != CK_INVALID_HANDLE) {
		(void)p11_session_free(pkcs11, session);
	}

	return 0;
}


/* Dump information about a token object. */
int p11_dumpObject(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	FILE* out)
{
	CK_RV rv;
	int sizeknown;
	CK_ULONG size;

	/* Skip if some of it is NULL. */
	if (object == CK_INVALID_HANDLE || out == NULL) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_DUMPOBJECT, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}
	if (
		pkcs11->functionList == NULL ||
		pkcs11->functionList->C_GetObjectSize == NULL
	) {
		PKCS11err(PKCS11_F_P11_DUMPOBJECT, PKCS11_R_NULL_POINTER_IN_INTERNAL_DATA);
		return 0;
	}

	/* "Object (handle) %u :\n\n" */
	fprintf(out, "Object #%u\n\n", (unsigned int)object);

	/* Note: we're not insisting on getting to know the size. */
	sizeknown = 0;
	size = 0;
	rv = (*pkcs11->functionList->C_GetObjectSize)(session, object, &size);
	if (rv != CKR_OK) {
		/*EMPTY*/
		P11_TRC1("C_GetObjectSize returned %s", p11_errorName(rv));
	} else {
		sizeknown = 1;
	}
	fprintf(out, "size: ");
	if (sizeknown) {
		fprintf(out, "%lu bytes", (unsigned long int)size);
	} else {
		fprintf(out, "<information unavailable>");
	}
	fprintf(out, "\n");

	fprintf(out, "\n");

	p11_dumpAttributes(pkcs11, session, object, out);

	fprintf(out, "\n");

	/* OK. */
	return 1;
}


/* Dump information about a token object attribute -- callback. */
static int p11_dumpAttribute_cb(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	CK_ATTRIBUTE_TYPE attribute,
	CK_RV status,
	const char* value,
	int size,
	void* cbdata)
{
	/* [only a wrapper...] */
	return p11_dumpAttribute(
		pkcs11,
		session,
		object,
		attribute,
		status,
		value,
		size,
		(FILE*)cbdata);
}


/* Dump information about token object attributes. */
int p11_dumpAttributes(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	FILE* out)
{
	static CK_ATTRIBUTE_TYPE const attributes[] = {
		CKA_CLASS,
		CKA_TOKEN,
		CKA_PRIVATE,
		CKA_LABEL,
		CKA_APPLICATION,
		CKA_VALUE,
		CKA_OBJECT_ID,
		CKA_CERTIFICATE_TYPE,
		CKA_ISSUER,
		CKA_SERIAL_NUMBER,
		CKA_AC_ISSUER,
		CKA_OWNER,
		CKA_ATTR_TYPES,
		CKA_KEY_TYPE,
		CKA_SUBJECT,
		CKA_ID,
		CKA_SENSITIVE,
		CKA_ENCRYPT,
		CKA_DECRYPT,
		CKA_WRAP,
		CKA_UNWRAP,
		CKA_SIGN,
		CKA_SIGN_RECOVER,
		CKA_VERIFY,
		CKA_VERIFY_RECOVER,
		CKA_DERIVE,
		CKA_START_DATE,
		CKA_END_DATE,
		CKA_MODULUS,
		CKA_MODULUS_BITS,
		CKA_PUBLIC_EXPONENT,
		CKA_PRIVATE_EXPONENT,
		CKA_PRIME_1,
		CKA_PRIME_2,
		CKA_EXPONENT_1,
		CKA_EXPONENT_2,
		CKA_COEFFICIENT,
		CKA_PRIME,
		CKA_SUBPRIME,
		CKA_BASE,
		CKA_VALUE_BITS,
		CKA_VALUE_LEN,
		CKA_EXTRACTABLE,
		CKA_LOCAL,
		CKA_NEVER_EXTRACTABLE,
		CKA_ALWAYS_SENSITIVE,
		CKA_MODIFIABLE,
		CKA_ECDSA_PARAMS,
		CKA_EC_POINT,
		CKA_SECONDARY_AUTH,
		CKA_AUTH_PIN_FLAGS,
		CKA_HW_FEATURE_TYPE,
		CKA_RESET_ON_INIT,
		CKA_HAS_RESET,

		/* Note: CKA_VENDOR_DEFINED _and above_ are vendor defined,
		** but not treated here.
		*/
		/* Note: We could count up from CKA_VENDOR_DEFINED, but that's
		** probably not a good idea (where to stop?  there are (many?
		** large?) holes assumed).
		*/
	};

	/* Skip if some of it is NULL. */
	if (out == NULL || object == CK_INVALID_HANDLE) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_DUMPATTRIBUTES, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	/* Enumerate attributes. */
	if (!p11_enumerateAttributes(
		pkcs11,
		session,
		object,
		attributes,
		sizeof(attributes) / sizeof(*attributes),
		p11_dumpAttribute_cb,
		(void*)out,
		1,
		0)
	) {
		return 0;
	}

	/* OK. */
	return 1;
}


/* Dump information about a token object attribute. */
int p11_dumpAttribute(
	PKCS11* pkcs11,
	CK_SESSION_HANDLE session,
	CK_OBJECT_HANDLE object,
	CK_ATTRIBUTE_TYPE attribute,
	CK_RV status,
	const char* value,
	int size,
	FILE* out)
{
	const char* name;
	char buf[64];

	/* [unused(s)] */
	(void)session;
	(void)object;

	/* Skip if some of it is NULL. */
	if (out == NULL) {
		/* OK. */
		return 1;
	}

	/* [guard(s)] */
	if (pkcs11 == NULL) {
		PKCS11err(PKCS11_F_P11_DUMPATTRIBUTE, PKCS11_R_NULL_POINTER_PROVIDED);
		return 0;
	}

	name = p11_attributeNameB(attribute, buf, sizeof(buf));
	fprintf(out, "attribute %s", name);

	if (status == CKR_OK) {
		fprintf(out, " (size %d)", size);
	}

	fprintf(out, ": ");

	if (status == CKR_OK) {
		p11_dumpAttributeValue(attribute, value, size, out);
	} else if (status == CKR_ATTRIBUTE_TYPE_INVALID) {
		fprintf(out, "<not set>");
	} else if (status == CKR_ATTRIBUTE_SENSITIVE) {
		fprintf(out, "<sensitive>");
	} else {
		/* Note: not really expected, but give some feedback anyway... */
		fprintf(out, "<%s>", p11_errorName(status));
	}

	fprintf(out, "\n");

	/* OK. */
	return 1;
}


/* Token mechanism name. */
const char* p11_mechanismName(CK_MECHANISM_TYPE mechanism)
{
	return p11_mechanismNameB(mechanism, NULL, 0);
}


/* Token mechanism name. */
const char* p11_mechanismNameB(
	CK_MECHANISM_TYPE mechanism,
	char* buf,
	int size)
{
	static struct {
		CK_MECHANISM_TYPE key;
		const char* value;
	} const t[] = {
		{CKM_RSA_PKCS_KEY_PAIR_GEN, "RSA_PKCS_KEY_PAIR_GEN"},
		{CKM_RSA_PKCS, "RSA_PKCS"},
		{CKM_RSA_9796, "RSA_9796"},
		{CKM_RSA_X_509, "RSA_X_509"},
		{CKM_MD2_RSA_PKCS, "MD2_RSA_PKCS"},
		{CKM_MD5_RSA_PKCS, "MD5_RSA_PKCS"},
		{CKM_SHA1_RSA_PKCS, "SHA1_RSA_PKCS"},
		{CKM_RIPEMD128_RSA_PKCS, "RIPEMD128_RSA_PKCS"},
		{CKM_RIPEMD160_RSA_PKCS, "RIPEMD160_RSA_PKCS"},
		{CKM_RSA_PKCS_OAEP, "RSA_PKCS_OAEP"},
		{CKM_DSA_KEY_PAIR_GEN, "DSA_KEY_PAIR_GEN"},
		{CKM_DSA, "DSA"},
		{CKM_DSA_SHA1, "DSA_SHA1"},
		{CKM_DH_PKCS_KEY_PAIR_GEN, "DH_PKCS_KEY_PAIR_GEN"},
		{CKM_DH_PKCS_DERIVE, "DH_PKCS_DERIVE"},
		{CKM_RC2_KEY_GEN, "RC2_KEY_GEN"},
		{CKM_RC2_ECB, "RC2_ECB"},
		{CKM_RC2_CBC, "RC2_CBC"},
		{CKM_RC2_MAC, "RC2_MAC"},
		{CKM_RC2_MAC_GENERAL, "RC2_MAC_GENERAL"},
		{CKM_RC2_CBC_PAD, "RC2_CBC_PAD"},
		{CKM_RC4_KEY_GEN, "RC4_KEY_GEN"},
		{CKM_RC4, "RC4"},
		{CKM_DES_KEY_GEN, "DES_KEY_GEN"},
		{CKM_DES_ECB, "DES_ECB"},
		{CKM_DES_CBC, "DES_CBC"},
		{CKM_DES_MAC, "DES_MAC"},
		{CKM_DES_MAC_GENERAL, "DES_MAC_GENERAL"},
		{CKM_DES_CBC_PAD, "DES_CBC_PAD"},
		{CKM_DES2_KEY_GEN, "DES2_KEY_GEN"},
		{CKM_DES3_KEY_GEN, "DES3_KEY_GEN"},
		{CKM_DES3_ECB, "DES3_ECB"},
		{CKM_DES3_CBC, "DES3_CBC"},
		{CKM_DES3_MAC, "DES3_MAC"},
		{CKM_DES3_MAC_GENERAL, "DES3_MAC_GENERAL"},
		{CKM_DES3_CBC_PAD, "DES3_CBC_PAD"},
		{CKM_CDMF_KEY_GEN, "CDMF_KEY_GEN"},
		{CKM_CDMF_ECB, "CDMF_ECB"},
		{CKM_CDMF_CBC, "CDMF_CBC"},
		{CKM_CDMF_MAC, "CDMF_MAC"},
		{CKM_CDMF_MAC_GENERAL, "CDMF_MAC_GENERAL"},
		{CKM_CDMF_CBC_PAD, "CDMF_CBC_PAD"},
		{CKM_MD2, "MD2"},
		{CKM_MD2_HMAC, "MD2_HMAC"},
		{CKM_MD2_HMAC_GENERAL, "MD2_HMAC_GENERAL"},
		{CKM_MD5, "MD5"},
		{CKM_MD5_HMAC, "MD5_HMAC"},
		{CKM_MD5_HMAC_GENERAL, "MD5_HMAC_GENERAL"},
		{CKM_SHA_1, "SHA_1"},
		{CKM_SHA_1_HMAC, "SHA_1_HMAC"},
		{CKM_SHA_1_HMAC_GENERAL, "SHA_1_HMAC_GENERAL"},
		{CKM_RIPEMD128, "RIPEMD128"},
		{CKM_RIPEMD128_HMAC, "RIPEMD128_HMAC"},
		{CKM_RIPEMD128_HMAC_GENERAL, "RIPEMD128_HMAC_GENERAL"},
		{CKM_RIPEMD160, "RIPEMD160"},
		{CKM_RIPEMD160_HMAC, "RIPEMD160_HMAC"},
		{CKM_RIPEMD160_HMAC_GENERAL, "RIPEMD160_HMAC_GENERAL"},
		{CKM_CAST_KEY_GEN, "CAST_KEY_GEN"},
		{CKM_CAST_ECB, "CAST_ECB"},
		{CKM_CAST_CBC, "CAST_CBC"},
		{CKM_CAST_MAC, "CAST_MAC"},
		{CKM_CAST_MAC_GENERAL, "CAST_MAC_GENERAL"},
		{CKM_CAST_CBC_PAD, "CAST_CBC_PAD"},
		{CKM_CAST3_KEY_GEN, "CAST3_KEY_GEN"},
		{CKM_CAST3_ECB, "CAST3_ECB"},
		{CKM_CAST3_CBC, "CAST3_CBC"},
		{CKM_CAST3_MAC, "CAST3_MAC"},
		{CKM_CAST3_MAC_GENERAL, "CAST3_MAC_GENERAL"},
		{CKM_CAST3_CBC_PAD, "CAST3_CBC_PAD"},
		{CKM_CAST5_KEY_GEN, "CAST5_KEY_GEN"},
		{CKM_CAST128_KEY_GEN, "CAST128_KEY_GEN"},
		{CKM_CAST5_ECB, "CAST5_ECB"},
		{CKM_CAST128_ECB, "CAST128_ECB"},
		{CKM_CAST5_CBC, "CAST5_CBC"},
		{CKM_CAST128_CBC, "CAST128_CBC"},
		{CKM_CAST5_MAC, "CAST5_MAC"},
		{CKM_CAST128_MAC, "CAST128_MAC"},
		{CKM_CAST5_MAC_GENERAL, "CAST5_MAC_GENERAL"},
		{CKM_CAST128_MAC_GENERAL, "CAST128_MAC_GENERAL"},
		{CKM_CAST5_CBC_PAD, "CAST5_CBC_PAD"},
		{CKM_CAST128_CBC_PAD, "CAST128_CBC_PAD"},
		{CKM_RC5_KEY_GEN, "RC5_KEY_GEN"},
		{CKM_RC5_ECB, "RC5_ECB"},
		{CKM_RC5_CBC, "RC5_CBC"},
		{CKM_RC5_MAC, "RC5_MAC"},
		{CKM_RC5_MAC_GENERAL, "RC5_MAC_GENERAL"},
		{CKM_RC5_CBC_PAD, "RC5_CBC_PAD"},
		{CKM_IDEA_KEY_GEN, "IDEA_KEY_GEN"},
		{CKM_IDEA_ECB, "IDEA_ECB"},
		{CKM_IDEA_CBC, "IDEA_CBC"},
		{CKM_IDEA_MAC, "IDEA_MAC"},
		{CKM_IDEA_MAC_GENERAL, "IDEA_MAC_GENERAL"},
		{CKM_IDEA_CBC_PAD, "IDEA_CBC_PAD"},
		{CKM_GENERIC_SECRET_KEY_GEN, "GENERIC_SECRET_KEY_GEN"},
		{CKM_CONCATENATE_BASE_AND_KEY, "CONCATENATE_BASE_AND_KEY"},
		{CKM_CONCATENATE_BASE_AND_DATA, "CONCATENATE_BASE_AND_DATA"},
		{CKM_CONCATENATE_DATA_AND_BASE, "CONCATENATE_DATA_AND_BASE"},
		{CKM_XOR_BASE_AND_DATA, "XOR_BASE_AND_DATA"},
		{CKM_EXTRACT_KEY_FROM_KEY, "EXTRACT_KEY_FROM_KEY"},
		{CKM_SSL3_PRE_MASTER_KEY_GEN, "SSL3_PRE_MASTER_KEY_GEN"},
		{CKM_SSL3_MASTER_KEY_DERIVE, "SSL3_MASTER_KEY_DERIVE"},
		{CKM_SSL3_KEY_AND_MAC_DERIVE, "SSL3_KEY_AND_MAC_DERIVE"},
		{CKM_SSL3_MD5_MAC, "SSL3_MD5_MAC"},
		{CKM_SSL3_SHA1_MAC, "SSL3_SHA1_MAC"},
		{CKM_MD5_KEY_DERIVATION, "MD5_KEY_DERIVATION"},
		{CKM_MD2_KEY_DERIVATION, "MD2_KEY_DERIVATION"},
		{CKM_SHA1_KEY_DERIVATION, "SHA1_KEY_DERIVATION"},
		{CKM_PBE_MD2_DES_CBC, "PBE_MD2_DES_CBC"},
		{CKM_PBE_MD5_DES_CBC, "PBE_MD5_DES_CBC"},
		{CKM_PBE_MD5_CAST_CBC, "PBE_MD5_CAST_CBC"},
		{CKM_PBE_MD5_CAST3_CBC, "PBE_MD5_CAST3_CBC"},
		{CKM_PBE_MD5_CAST5_CBC, "PBE_MD5_CAST5_CBC"},
		{CKM_PBE_MD5_CAST128_CBC, "PBE_MD5_CAST128_CBC"},
		{CKM_PBE_SHA1_CAST5_CBC, "PBE_SHA1_CAST5_CBC"},
		{CKM_PBE_SHA1_CAST128_CBC, "PBE_SHA1_CAST128_CBC"},
		{CKM_PBE_SHA1_RC4_128, "PBE_SHA1_RC4_128"},
		{CKM_PBE_SHA1_RC4_40, "PBE_SHA1_RC4_40"},
		{CKM_PBE_SHA1_DES3_EDE_CBC, "PBE_SHA1_DES3_EDE_CBC"},
		{CKM_PBE_SHA1_DES2_EDE_CBC, "PBE_SHA1_DES2_EDE_CBC"},
		{CKM_PBE_SHA1_RC2_128_CBC, "PBE_SHA1_RC2_128_CBC"},
		{CKM_PBE_SHA1_RC2_40_CBC, "PBE_SHA1_RC2_40_CBC"},
		{CKM_PKCS5_PBKD2, "PKCS5_PBKD2"},
		{CKM_PBA_SHA1_WITH_SHA1_HMAC, "PBA_SHA1_WITH_SHA1_HMAC"},
		{CKM_KEY_WRAP_LYNKS, "KEY_WRAP_LYNKS"},
		{CKM_KEY_WRAP_SET_OAEP, "KEY_WRAP_SET_OAEP"},
		{CKM_SKIPJACK_KEY_GEN, "SKIPJACK_KEY_GEN"},
		{CKM_SKIPJACK_ECB64, "SKIPJACK_ECB64"},
		{CKM_SKIPJACK_CBC64, "SKIPJACK_CBC64"},
		{CKM_SKIPJACK_OFB64, "SKIPJACK_OFB64"},
		{CKM_SKIPJACK_CFB64, "SKIPJACK_CFB64"},
		{CKM_SKIPJACK_CFB32, "SKIPJACK_CFB32"},
		{CKM_SKIPJACK_CFB16, "SKIPJACK_CFB16"},
		{CKM_SKIPJACK_CFB8, "SKIPJACK_CFB8"},
		{CKM_SKIPJACK_WRAP, "SKIPJACK_WRAP"},
		{CKM_SKIPJACK_PRIVATE_WRAP, "SKIPJACK_PRIVATE_WRAP"},
		{CKM_SKIPJACK_RELAYX, "SKIPJACK_RELAYX"},
		{CKM_KEA_KEY_PAIR_GEN, "KEA_KEY_PAIR_GEN"},
		{CKM_KEA_KEY_DERIVE, "KEA_KEY_DERIVE"},
		{CKM_FORTEZZA_TIMESTAMP, "FORTEZZA_TIMESTAMP"},
		{CKM_BATON_KEY_GEN, "BATON_KEY_GEN"},
		{CKM_BATON_ECB128, "BATON_ECB128"},
		{CKM_BATON_ECB96, "BATON_ECB96"},
		{CKM_BATON_CBC128, "BATON_CBC128"},
		{CKM_BATON_COUNTER, "BATON_COUNTER"},
		{CKM_BATON_SHUFFLE, "BATON_SHUFFLE"},
		{CKM_BATON_WRAP, "BATON_WRAP"},
		{CKM_ECDSA_KEY_PAIR_GEN, "ECDSA_KEY_PAIR_GEN"},
		{CKM_ECDSA, "ECDSA"},
		{CKM_ECDSA_SHA1, "ECDSA_SHA1"},
		{CKM_JUNIPER_KEY_GEN, "JUNIPER_KEY_GEN"},
		{CKM_JUNIPER_ECB128, "JUNIPER_ECB128"},
		{CKM_JUNIPER_CBC128, "JUNIPER_CBC128"},
		{CKM_JUNIPER_COUNTER, "JUNIPER_COUNTER"},
		{CKM_JUNIPER_SHUFFLE, "JUNIPER_SHUFFLE"},
		{CKM_JUNIPER_WRAP, "JUNIPER_WRAP"},
		{CKM_FASTHASH, "FASTHASH"},

		/* Note: CKM_VENDOR_DEFINED _and above_ are vendor defined. */
	};

	int i;

	/* Search the mechanism. */
	/* Note: we're using a linear search; shouldn't be too slow. */

	for (i = 0; i < sizeof(t) / sizeof(*t); i++) {
		if (t[i].key == mechanism) {
			return t[i].value;
		}
	}

	if (buf == NULL || size < 64) {
		return "UNKNOWN_MECHANISM";
	}

	sprintf(buf, "%s_0x%08lx",
		(mechanism >= CKM_VENDOR_DEFINED ?
			"VENDOR_DEFINED_MECHANISM" :
			"MECHANISM"),
		mechanism);
	return (const char*)buf;
}


/* Token object attribute name. */
const char* p11_attributeName(CK_ATTRIBUTE_TYPE attribute)
{
	return p11_attributeNameB(attribute, NULL, 0);
}


/* Token object attribute name. */
const char* p11_attributeNameB(
	CK_ATTRIBUTE_TYPE attribute,
	char* buf,
	int size)
{
	static struct {
		CK_ATTRIBUTE_TYPE key;
		const char* value;
	} const t[] = {
		{CKA_CLASS, "CLASS"},
		{CKA_TOKEN, "TOKEN"},
		{CKA_PRIVATE, "PRIVATE"},
		{CKA_LABEL, "LABEL"},
		{CKA_APPLICATION, "APPLICATION"},
		{CKA_VALUE, "VALUE"},
		{CKA_OBJECT_ID, "OBJECT_ID"},
		{CKA_CERTIFICATE_TYPE, "CERTIFICATE_TYPE"},
		{CKA_ISSUER, "ISSUER"},
		{CKA_SERIAL_NUMBER, "SERIAL_NUMBER"},
		{CKA_AC_ISSUER, "AC_ISSUER"},
		{CKA_OWNER, "OWNER"},
		{CKA_ATTR_TYPES, "ATTR_TYPES"},
		{CKA_KEY_TYPE, "KEY_TYPE"},
		{CKA_SUBJECT, "SUBJECT"},
		{CKA_ID, "ID"},
		{CKA_SENSITIVE, "SENSITIVE"},
		{CKA_ENCRYPT, "ENCRYPT"},
		{CKA_DECRYPT, "DECRYPT"},
		{CKA_WRAP, "WRAP"},
		{CKA_UNWRAP, "UNWRAP"},
		{CKA_SIGN, "SIGN"},
		{CKA_SIGN_RECOVER, "SIGN_RECOVER"},
		{CKA_VERIFY, "VERIFY"},
		{CKA_VERIFY_RECOVER, "VERIFY_RECOVER"},
		{CKA_DERIVE, "DERIVE"},
		{CKA_START_DATE, "START_DATE"},
		{CKA_END_DATE, "END_DATE"},
		{CKA_MODULUS, "MODULUS"},
		{CKA_MODULUS_BITS, "MODULUS_BITS"},
		{CKA_PUBLIC_EXPONENT, "PUBLIC_EXPONENT"},
		{CKA_PRIVATE_EXPONENT, "PRIVATE_EXPONENT"},
		{CKA_PRIME_1, "PRIME_1"},
		{CKA_PRIME_2, "PRIME_2"},
		{CKA_EXPONENT_1, "EXPONENT_1"},
		{CKA_EXPONENT_2, "EXPONENT_2"},
		{CKA_COEFFICIENT, "COEFFICIENT"},
		{CKA_PRIME, "PRIME"},
		{CKA_SUBPRIME, "SUBPRIME"},
		{CKA_BASE, "BASE"},
		{CKA_VALUE_BITS, "VALUE_BITS"},
		{CKA_VALUE_LEN, "VALUE_LEN"},
		{CKA_EXTRACTABLE, "EXTRACTABLE"},
		{CKA_LOCAL, "LOCAL"},
		{CKA_NEVER_EXTRACTABLE, "NEVER_EXTRACTABLE"},
		{CKA_ALWAYS_SENSITIVE, "ALWAYS_SENSITIVE"},
		{CKA_MODIFIABLE, "MODIFIABLE"},
		{CKA_ECDSA_PARAMS, "ECDSA_PARAMS"},
		{CKA_EC_POINT, "EC_POINT"},
		{CKA_SECONDARY_AUTH, "SECONDARY_AUTH"},
		{CKA_AUTH_PIN_FLAGS, "AUTH_PIN_FLAGS"},
		{CKA_HW_FEATURE_TYPE, "HW_FEATURE_TYPE"},
		{CKA_RESET_ON_INIT, "RESET_ON_INIT"},
		{CKA_HAS_RESET, "HAS_RESET"},

		/* Note: CKA_VENDOR_DEFINED _and above_ are vendor defined. */
	};

	int i;

	/* Search the attribute. */
	/* Note: we're using a linear search; shouldn't be too slow. */

	for (i = 0; i < sizeof(t) / sizeof(*t); i++) {
		if (t[i].key == attribute) {
			return t[i].value;
		}
	}

	if (buf == NULL || size < 64) {
		return "UNKNOWN_ATTRIBUTE";
	}

	sprintf(buf, "%s_0x%08lx",
		(attribute >= CKA_VENDOR_DEFINED ?
			"VENDOR_DEFINED_ATTRIBUTE" :
			"ATTRIBUTE"),
		attribute);
	return (const char*)buf;
}


/* Dump a token object attribute value. */
int p11_dumpAttributeValue(
	CK_ATTRIBUTE_TYPE attribute,
	const char* value,
	int size,
	FILE* out)
{
	/* PKCS#11 token object attribute types. */

	/* These types are mutual exclusive. */

	/* Note: We assume the type is typically completely determined
	** by the attribute (and not by a combination of attribute
	** values), i.e. the attribute semantics are the same for
	** different object-classes, key-types, etc.
	** Attribute types that are not determined this way, e.g. CKA_VALUE,
	** will be tagged 'varying', and typically printed in raw form.
	*/

#define P11_ATTRIBYTE_TYPE_NONE 0 /* no (known) type */
#define P11_ATTRIBYTE_TYPE_VARYING 1 /* varying type */

#define P11_ATTRIBYTE_TYPE_BOOLEAN 2 /* boolean, "false" or "true" */
#define P11_ATTRIBYTE_TYPE_NUMBER 3 /* a (unsigned) 4-byte sized number */
#define P11_ATTRIBYTE_TYPE_BIGNUMBER 4 /* a (arbitrarily sized) big-number */
#define P11_ATTRIBYTE_TYPE_FLAGS 5 /* a (unsigned) 4-byte sized number */
#define P11_ATTRIBYTE_TYPE_STRING 6 /* a string */
#define P11_ATTRIBYTE_TYPE_BER 7 /* BER encoding */
#define P11_ATTRIBYTE_TYPE_DER 8 /* DER encoding */
#define P11_ATTRIBYTE_TYPE_DATE 9 /* CK_DATE */

#define P11_ATTRIBYTE_TYPE_OBJECTCLASS 10 /* an object class type, e.g. "PUBLIC_KEY" */
#define P11_ATTRIBYTE_TYPE_HWFEATURETYPE 11 /* a hardware featuretype type, e.g. "CLOCK" */
#define P11_ATTRIBYTE_TYPE_KEYTYPE 12 /* a key type, e.g. "RSA" */
#define P11_ATTRIBYTE_TYPE_CERTIFICATETYPE 13 /* a certificate type, e.g. "X_509" */

	/* [see specification] */

	static struct {
		CK_ATTRIBUTE_TYPE key;
		int value;
	} const t[] = {
		{CKA_CLASS, P11_ATTRIBYTE_TYPE_OBJECTCLASS},
		{CKA_TOKEN, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_PRIVATE, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_LABEL, P11_ATTRIBYTE_TYPE_STRING},
		{CKA_APPLICATION, P11_ATTRIBYTE_TYPE_STRING},
		{CKA_VALUE, P11_ATTRIBYTE_TYPE_VARYING},
		{CKA_OBJECT_ID, P11_ATTRIBYTE_TYPE_DER},
		{CKA_CERTIFICATE_TYPE, P11_ATTRIBYTE_TYPE_CERTIFICATETYPE},
		{CKA_ISSUER, P11_ATTRIBYTE_TYPE_DER},
		{CKA_SERIAL_NUMBER, P11_ATTRIBYTE_TYPE_DER},
		{CKA_AC_ISSUER, P11_ATTRIBYTE_TYPE_DER},
		{CKA_OWNER, P11_ATTRIBYTE_TYPE_DER},
		{CKA_ATTR_TYPES, P11_ATTRIBYTE_TYPE_BER},
		{CKA_KEY_TYPE, P11_ATTRIBYTE_TYPE_KEYTYPE},
		{CKA_SUBJECT, P11_ATTRIBYTE_TYPE_DER},
		{CKA_ID, P11_ATTRIBYTE_TYPE_NONE},
		{CKA_SENSITIVE, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_ENCRYPT, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_DECRYPT, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_WRAP, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_UNWRAP, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_SIGN, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_SIGN_RECOVER, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_VERIFY, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_VERIFY_RECOVER, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_DERIVE, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_START_DATE, P11_ATTRIBYTE_TYPE_DATE},
		{CKA_END_DATE, P11_ATTRIBYTE_TYPE_DATE},
		{CKA_MODULUS, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_MODULUS_BITS, P11_ATTRIBYTE_TYPE_NUMBER},
		{CKA_PUBLIC_EXPONENT, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_PRIVATE_EXPONENT, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_PRIME_1, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_PRIME_2, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_EXPONENT_1, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_EXPONENT_2, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_COEFFICIENT, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_PRIME, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_SUBPRIME, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_BASE, P11_ATTRIBYTE_TYPE_BIGNUMBER},
		{CKA_VALUE_BITS, P11_ATTRIBYTE_TYPE_NUMBER},
		{CKA_VALUE_LEN, P11_ATTRIBYTE_TYPE_NUMBER},
		{CKA_EXTRACTABLE, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_LOCAL, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_NEVER_EXTRACTABLE, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_ALWAYS_SENSITIVE, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_MODIFIABLE, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_ECDSA_PARAMS, P11_ATTRIBYTE_TYPE_DER},
		{CKA_EC_POINT, P11_ATTRIBYTE_TYPE_DER},
		{CKA_SECONDARY_AUTH, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_AUTH_PIN_FLAGS, P11_ATTRIBYTE_TYPE_FLAGS},
		{CKA_HW_FEATURE_TYPE, P11_ATTRIBYTE_TYPE_HWFEATURETYPE},
		{CKA_RESET_ON_INIT, P11_ATTRIBYTE_TYPE_BOOLEAN},
		{CKA_HAS_RESET, P11_ATTRIBYTE_TYPE_BOOLEAN},
	};

	int type;
	int done;
	int i;

	/* Skip if some of it is NULL. */
	if (out == NULL) {
		/* OK. */
		return 1;
	}

	/* check type, dispatch */

	/* Have the default to 'none'. */
	type = P11_ATTRIBYTE_TYPE_NONE;

	/* Search the attribute. */
	/* Note: we're using a linear search; shouldn't be too slow. */

	for (i = 0; i < sizeof(t) / sizeof(*t); i++) {
		if (t[i].key == attribute) {
			type = t[i].value;
			break;
		}
	}

	/* Make sure there is something written, make it "-" for empty values. */

	done = 1;

	switch (type) {

	case P11_ATTRIBYTE_TYPE_BOOLEAN: /* boolean, "false" or "true" */
		/* "false" or "true" */
		p11_dumpBool(value, size, out);
		break;

	case P11_ATTRIBYTE_TYPE_NUMBER: /* a (unsigned) 4-byte sized number */
		/* check size */
		if (size == sizeof(CK_ULONG)) {
			/* a (unsigned) number */
			/* no endianess-conversion [p11_ntohl()] */
			/* TODO: check whether endianess-conversion is required in some cases. */
			p11_dumpNumber(p11_data2ulong(value, size), out);
		} else {
			done = 0;
		}
		break;

	case P11_ATTRIBYTE_TYPE_FLAGS: /* a (unsigned) 4-byte sized number */
		/* check size */
		if (size == sizeof(CK_FLAGS)) {
			/* some flags */
			/* no endianess-conversion [p11_ntohl()] */
			/* TODO: check whether endianess-conversion is required in some cases. */
			p11_dumpFlagsPlain((CK_FLAGS)p11_data2ulong(value, size), out);
		} else {
			done = 0;
		}
		break;

	case P11_ATTRIBYTE_TYPE_STRING: /* a string */
		/* a string or a representation for 'empty' */
		p11_dumpStringE((const CK_UTF8CHAR*)value, size, out);
		break;

	case P11_ATTRIBYTE_TYPE_OBJECTCLASS: /* an object class type, e.g. "PUBLIC_KEY" */
		p11_dumpObjectClass(value, size, out);
		break;

	case P11_ATTRIBYTE_TYPE_HWFEATURETYPE: /* a hardware featuretype type, e.g. "CLOCK" */
		p11_dumpHWFeatureType(value, size, out);
		break;

	case P11_ATTRIBYTE_TYPE_KEYTYPE: /* a key type, e.g. "RSA" */
		p11_dumpKeyType(value, size, out);
		break;

	case P11_ATTRIBYTE_TYPE_CERTIFICATETYPE: /* a certificate type, e.g. "X_509" */
		p11_dumpCertificateType(value, size, out);
		break;

	/* types not quite handled and printed in raw */
	/* Note: We don't print big-numbers in decimal notation, who would care? */
	case P11_ATTRIBYTE_TYPE_BIGNUMBER: /* a (arbitrarily sized) big-number */
	/* Note: We don't do DER-decoding on DER values, neither BER. */
	case P11_ATTRIBYTE_TYPE_BER: /* BER encoding */
	case P11_ATTRIBYTE_TYPE_DER: /* DER encoding */
	case P11_ATTRIBYTE_TYPE_DATE: /* CK_DATE */

	/* types that are 'on the move, do them 'raw' */
	case P11_ATTRIBYTE_TYPE_VARYING: /* varying type */
	case P11_ATTRIBYTE_TYPE_NONE: /* no (known) type */

	/* the infamous else case... */
	default: /* still less known...  handle it somehow anyway. */

		done = 0;
		break;
	}

	if (!done) {

		/* print the raw form only */

		/* check size */
		if (size > 0) {
			/* a hexadecimal representation */
			p11_dumpHexS(value, size, out);
		} else {
			/* an empty value representation */
			p11_dumpEmpty(out);
		}

	} else {

		/* print the raw form, too */

		fprintf(out, " (");

		/* check size */
		if (size > 0) {
			/* a hexadecimal representation */
			p11_dumpHexS(value, size, out);
		} else {
			/* an empty value representation */
			p11_dumpEmpty(out);
		}

		fprintf(out, ")");

	}

	/* OK. */
	return 1;
}


/* Dump a PKCS#11 format string. */
void p11_dumpString(const CK_UTF8CHAR* str, int size, FILE* out)
{
	/* [guard(s)] */
	if (str == NULL || size <= 0 || out == NULL) {
		return;
	}

	size = p11_stringSize(str, size);

	if (size == 0) {
		return;
	}

	fprintf(out, "%.*s", size, str);
}


/* Dump a PKCS#11 format string or a representation for 'empty'. */
void p11_dumpStringE(const CK_UTF8CHAR* str, int size, FILE* out)
{
	/* [guard(s)] */
	if (str == NULL || size <= 0 || out == NULL) {
		return;
	}

	size = p11_stringSize(str, size);

	/* check size */
	if (size > 0) {
		/* a string */
		p11_dumpString(str, size, out);
	} else {
		/* an empty value representation */
		p11_dumpEmpty(out);
	}
}


/* Dump PKCS#11 format version info. */
void p11_dumpVersion(const CK_VERSION* v, FILE* out)
{
	/* [guard(s)] */
	if (v == NULL || out == NULL) {
		return;
	}

	/* Q: should we output something like "<version unavailable>"
	** for the "0.0" case?  The PKCS#11 specification doesn't tell.
	*/

	fprintf(
		out,
		"%u.%u",
		(unsigned)(unsigned char)v->major,
		(unsigned)(unsigned char)v->minor);

	/* Note: major=1 minor=10 may signify 1.1.0 instead of 1.10. */
}


/* Dump a PKCS#11 number. */
static void p11_dumpNumberPlain(CK_ULONG n, FILE* out)
{
	/* [guard(s)] */
	if (out == NULL) {
		return;
	}

	fprintf(out, "%lu", n);
}


/* Dump a PKCS#11 number. */
void p11_dumpNumber(CK_ULONG n, FILE* out)
{
	p11_dumpNumberPlain(n, out);
}


/* Dump a PKCS#11 number, consider 'unavailable'. */
void p11_dumpNumberU(CK_ULONG n, FILE* out)
{
	/* [guard(s)] */
	if (out == NULL) {
		return;
	}

	if (n == CK_UNAVAILABLE_INFORMATION) {
		fprintf(out, "<information unavailable>");
	} else {
		p11_dumpNumber(n, out);
	}
}


/* Dump a PKCS#11 number, consider 'infinite'. */
void p11_dumpNumberI(CK_ULONG n, FILE* out)
{
	/* [guard(s)] */
	if (out == NULL) {
		return;
	}

	if (n == CK_EFFECTIVELY_INFINITE) {
		fprintf(out, "<infinite>");
	} else {
		p11_dumpNumber(n, out);
	}
}


/* Dump a PKCS#11 number, consider 'unavailable' and 'infinite'. */
void p11_dumpNumberUI(CK_ULONG n, FILE* out)
{
	/* [guard(s)] */
	if (out == NULL) {
		return;
	}

	if (n == CK_UNAVAILABLE_INFORMATION) {
		p11_dumpNumberU(n, out);
	} else if (n == CK_EFFECTIVELY_INFINITE) {
		p11_dumpNumberI(n, out);
	} else {
		/* Note: we wouldn't really need this else-case,
		** but it's more readable.
		*/
		p11_dumpNumber(n, out);
	}
}


/* Empty value representation. */
void p11_dumpEmpty(FILE* out)
{
	/* Skip if some of it is NULL. */
	if (out == NULL) {
		return;
	}

	fprintf(out, "-");
}


/* Dump info as hexadecimal data. */
void p11_dumpHex(
	const void* value,
	int size,
	const char* delimiter,
	int wrapsize,
	FILE* out)
{
	int i;
	int wrap, delimit;

	/* Skip if some of it is NULL. */
	if (out == NULL || size <= 0) {
		return;
	}

	/* [guard(s)] */
	if (value == NULL) {
		fprintf(out, "<null>");
		return;
	}

	/* now wrap only if size > wrapsize */
	if (wrapsize != 0 && size <= wrapsize) {
		wrapsize = 0;
	}

	/* dump all bytes... */
	for (i = 0; i < size; i++) {
		/* ...check for wrap */
		wrap = wrapsize != 0 && i % wrapsize == 0;
		if (wrap) {
			fprintf(out, "\n");
			/* start new line indented */
			fprintf(out, "    ");
		}
		/* ...delimited */
		delimit = i != 0 && !wrap && *delimiter != '\0';
		if (delimit) {
			fprintf(out, "%s", delimiter);
		}
		fprintf(out, "%02x", (int)((const unsigned char*)value)[i]);
	}
}


/* Dump info as hexadecimal data, standard format, using colon delimiter. */
void p11_dumpHexS(const void* value, int size, FILE* out)
{
	p11_dumpHex(value, size, ":", 0, out);
}


/* Dump info as hexadecimal data, plain format, using no delimiter. */
void p11_dumpHexP(const void* value, int size, FILE* out)
{
	p11_dumpHex(value, size, "", 0, out);
}


/* Dump info as boolean data. */
void p11_dumpBool(const void* value, int size, FILE* out)
{
	int flag, i;

	/* Skip if some of it is NULL. */
	if (out == NULL) {
		return;
	}

	/* [guard(s)] */
	if (value == NULL) {
		fprintf(out, "<null>");
		return;
	}

	/* Now we typically expect one byte, which is either 0 or 1. */
	/* Note: However, we accept other forms too. */

	flag = 0;
	for (i = 0; i < size; i++) {
		if (((const unsigned char*)value)[i] != 0) {
			flag = 1;
			break;
		}
	}

	if (flag) {
		fprintf(out, "true");
	} else {
		fprintf(out, "false");
	}
}


/* Convert PKCS#11 token object data to p11_TYPE. */
static p11_TYPE p11_data2type(const void* value, int size)
{
	/* [guard(s)] */
	if (size != sizeof(p11_TYPE)) {
		return (p11_TYPE)0;
	}
	if (size != sizeof(CK_ULONG)) {
		return (p11_TYPE)0;
	}

	/* no endianess-conversion [p11_ntohl()] */
	/* TODO: check whether endianess-conversion is required in some cases. */
	return (p11_TYPE)p11_data2ulong(value, size);
}


/* Dump info as a specified type. */
static void p11_dumpType(
	const void* value,
	int size,
	const p11_t2n* t2n,
	int t2n_size,
	p11_TYPE vendor_defined,
	FILE* out)
{
	p11_TYPE type;
	int i;

	/* Skip if some of it is NULL. */
	if (out == NULL) {
		return;
	}

	/* [guard(s)] */
	if (value == NULL) {
		fprintf(out, "<null>");
		return;
	}

	if (size != sizeof(type)) {
		fprintf(out, "<bad data size>");
		return;
	}

	type = p11_data2type(value, size);

	/* Search. */
	/* Note: we're using a linear search; shouldn't be too slow. */

	for (i = 0; i < t2n_size; i++) {
		if (t2n[i].key == type) {
			fprintf(out, "%s", t2n[i].value);
			return;
		}
	}

	if (type >= vendor_defined) {
		fprintf(out, "VENDOR_DEFINED_0x%08lx", type);
	} else {
		fprintf(out, "0x%08lx", type);
	}
}


/* Dump info as object-class. */
void p11_dumpObjectClass(const void* value, int size, FILE* out)
{
	static struct {
		CK_OBJECT_CLASS key;
		const char* value;
	} const t[] = {
		{CKO_DATA, "DATA"},
		{CKO_CERTIFICATE, "CERTIFICATE"},
		{CKO_PUBLIC_KEY, "PUBLIC_KEY"},
		{CKO_PRIVATE_KEY, "PRIVATE_KEY"},
		{CKO_SECRET_KEY, "SECRET_KEY"},
		{CKO_HW_FEATURE, "HW_FEATURE"},

		/* considering CKO_VENDOR_DEFINED and above in the code below */
	};

	p11_dumpType(
		value,
		size,
		(const p11_t2n*)t,
		sizeof(t) / sizeof(*t),
		CKO_VENDOR_DEFINED,
		out);
}


/* Dump info as harware-feature-type. */
void p11_dumpHWFeatureType(const void* value, int size, FILE* out)
{
	static struct {
		CK_HW_FEATURE_TYPE key;
		const char* value;
	} const t[] = {
		{CKH_MONOTONIC_COUNTER, "MONOTONIC_COUNTER"},
		{CKH_CLOCK, "CLOCK"},

		/* considering CKH_VENDOR_DEFINED and above in the code below */
	};

	p11_dumpType(
		value,
		size,
		(const p11_t2n*)t,
		sizeof(t) / sizeof(*t),
		CKH_VENDOR_DEFINED,
		out);
}


/* Dump info as key-type. */
void p11_dumpKeyType(const void* value, int size, FILE* out)
{
	static struct {
		CK_KEY_TYPE key;
		const char* value;
	} const t[] = {
		{CKK_RSA, "RSA"},
		{CKK_DSA, "DSA"},
		{CKK_DH, "DH"},
		{CKK_ECDSA, "ECDSA"},
		{CKK_KEA, "KEA"},
		{CKK_GENERIC_SECRET, "GENERIC_SECRET"},
		{CKK_RC2, "RC2"},
		{CKK_RC4, "RC4"},
		{CKK_DES, "DES"},
		{CKK_DES2, "DES2"},
		{CKK_DES3, "DES3"},
		{CKK_CAST, "CAST"},
		{CKK_CAST3, "CAST3"},
		{CKK_CAST5, "CAST5"},
		{CKK_CAST128, "CAST128"},
		{CKK_RC5, "RC5"},
		{CKK_IDEA, "IDEA"},
		{CKK_SKIPJACK, "SKIPJACK"},
		{CKK_BATON, "BATON"},
		{CKK_JUNIPER, "JUNIPER"},
		{CKK_CDMF, "CDMF"},

		/* considering CKK_VENDOR_DEFINED and above in the code below */
	};

	p11_dumpType(
		value,
		size,
		(const p11_t2n*)t,
		sizeof(t) / sizeof(*t),
		CKK_VENDOR_DEFINED,
		out);
}


/* Dump info as certificate-type. */
void p11_dumpCertificateType(const void* value, int size, FILE* out)
{
	static struct {
		CK_CERTIFICATE_TYPE key;
		const char* value;
	} const t[] = {
		{CKC_X_509, "X_509"},
		{CKC_X_509_ATTR_CERT, "X_509_ATTR_CERT"},

		/* considering CKC_VENDOR_DEFINED and above in the code below */
	};

	p11_dumpType(
		value,
		size,
		(const p11_t2n*)t,
		sizeof(t) / sizeof(*t),
		CKC_VENDOR_DEFINED,
		out);
}


/* Dump PKCS#11 flags. */
void p11_dumpFlagsPlain(CK_FLAGS f, FILE* out)
{
	/* [guard(s)] */
	if (out == NULL) {
		return;
	}

	fprintf(out, "0x%lx", f);
}


/* Dump flags. */
static void p11_dumpFlags(
	CK_FLAGS f,
	const p11_f2n* f2n,
	int f2n_size,
	int no_notation_too,
	FILE* out)
{
	int n, i;

	/* [guard(s)] */
	if (out == NULL) {
		return;
	}

	/* Print out the flags in plain number (hex) notation. */
	p11_dumpFlagsPlain(f, out);

	if (f2n != NULL && f2n_size > 0) {

		/* If there are flags set, print their names. */
		if (f != 0 || no_notation_too) {

			fprintf(out, " (");

			/* Go thru the known names. */
			n = 0;
			for (i = 0; i < f2n_size; i++) {
				if (f & f2n[i].key) {
					if (n != 0) {
						fprintf(out, " ");
					}

					fprintf(out, "%s", f2n[i].value);
					n++;

					f &= ~f2n[i].key;

				} else if (no_notation_too) {
					if (n != 0) {
						fprintf(out, " ");
					}

					fprintf(out, "NOT_%s", f2n[i].value);
					n++;
				}
			}

			/* Print leftovers. */
			if (f) {
				if (n != 0) {
					fprintf(out, " ");
				}

				p11_dumpFlagsPlain(f, out);
				n++;
			}

			fprintf(out, ")");
		}
	}
}


/* Dump PKCS#11 library flags. */
void p11_dumpLibraryFlags(CK_FLAGS f, FILE* out)
{
	/* Note: these flags should be zero, as specified. */

	p11_dumpFlags(f, NULL, 0, 0, out);
}


/* Dump PKCS#11 slot flags. */
void p11_dumpSlotFlags(CK_FLAGS f, FILE* out)
{
	static const p11_f2n t[] = {
		{CKF_TOKEN_PRESENT, "TOKEN_PRESENT"},
		{CKF_REMOVABLE_DEVICE, "REMOVABLE_DEVICE"},
		{CKF_HW_SLOT, "HW_SLOT"},
	};

	p11_dumpFlags(f, t, sizeof(t) / sizeof(*t), 0, out);
}


/* Dump PKCS#11 token flags. */
void p11_dumpTokenFlags(CK_FLAGS f, FILE* out)
{
	static const p11_f2n t[] = {
		{CKF_RNG, "RNG"},
		{CKF_WRITE_PROTECTED, "WRITE_PROTECTED"},
		{CKF_LOGIN_REQUIRED, "LOGIN_REQUIRED"},
		{CKF_USER_PIN_INITIALIZED, "USER_PIN_INITIALIZED"},
		{CKF_RESTORE_KEY_NOT_NEEDED, "RESTORE_KEY_NOT_NEEDED"},
		{CKF_CLOCK_ON_TOKEN, "CLOCK_ON_TOKEN"},
		{CKF_PROTECTED_AUTHENTICATION_PATH, "PROTECTED_AUTHENTICATION_PATH"},
		{CKF_DUAL_CRYPTO_OPERATIONS, "DUAL_CRYPTO_OPERATIONS"},
		{CKF_TOKEN_INITIALIZED, "TOKEN_INITIALIZED"},
		{CKF_SECONDARY_AUTHENTICATION, "SECONDARY_AUTHENTICATION"},
		{CKF_USER_PIN_COUNT_LOW, "USER_PIN_COUNT_LOW"},
		{CKF_USER_PIN_FINAL_TRY, "USER_PIN_FINAL_TRY"},
		{CKF_USER_PIN_LOCKED, "USER_PIN_LOCKED"},
		{CKF_USER_PIN_TO_BE_CHANGED, "USER_PIN_TO_BE_CHANGED"},
		{CKF_SO_PIN_COUNT_LOW, "SO_PIN_COUNT_LOW"},
		{CKF_SO_PIN_FINAL_TRY, "SO_PIN_FINAL_TRY"},
		{CKF_SO_PIN_LOCKED, "SO_PIN_LOCKED"},
		{CKF_SO_PIN_TO_BE_CHANGED, "SO_PIN_TO_BE_CHANGED"},
	};

	p11_dumpFlags(f, t, sizeof(t) / sizeof(*t), 0, out);
}


/* Dump PKCS#11 session flags. */
void p11_dumpSessionFlags(CK_FLAGS f, FILE* out)
{
	static const p11_f2n t[] = {
		{CKF_RW_SESSION, "RW_SESSION"},
		{CKF_SERIAL_SESSION, "SERIAL_SESSION"},
	};

	p11_dumpFlags(f, t, sizeof(t) / sizeof(*t), 0, out);
}


/* Dump PKCS#11 mechanism flags. */
void p11_dumpMechanismFlags(CK_FLAGS f, FILE* out)
{
	static const p11_f2n t[] = {
		{CKF_HW, "HW"},
		{CKF_ENCRYPT, "ENCRYPT"},
		{CKF_DECRYPT, "DECRYPT"},
		{CKF_DIGEST, "DIGEST"},
		{CKF_SIGN, "SIGN"},
		{CKF_SIGN_RECOVER, "SIGN_RECOVER"},
		{CKF_VERIFY, "VERIFY"},
		{CKF_VERIFY_RECOVER, "VERIFY_RECOVER"},
		{CKF_GENERATE, "GENERATE"},
		{CKF_GENERATE_KEY_PAIR, "GENERATE_KEY_PAIR"},
		{CKF_WRAP, "WRAP"},
		{CKF_UNWRAP, "UNWRAP"},
		{CKF_DERIVE, "DERIVE"},
		{CKF_EXTENSION, "EXTENSION"},
	};

	p11_dumpFlags(f, t, sizeof(t) / sizeof(*t), 0, out);
}


/* PKCS#11 API error name. */
const char* p11_errorName(CK_RV rv)
{
	return p11_errorNameB(rv, NULL, 0);
}


/* PKCS#11 API error name. */
const char* p11_errorNameB(CK_RV rv, char* buf, int size)
{
	static struct {
		CK_RV key;
		const char* value;
	} const t[] = {
		{CKR_OK, "OK"},
		{CKR_CANCEL, "CANCEL"},
		{CKR_HOST_MEMORY, "HOST_MEMORY"},
		{CKR_SLOT_ID_INVALID, "SLOT_ID_INVALID"},
		{CKR_GENERAL_ERROR, "GENERAL_ERROR"},
		{CKR_FUNCTION_FAILED, "FUNCTION_FAILED"},
		{CKR_ARGUMENTS_BAD, "ARGUMENTS_BAD"},
		{CKR_NO_EVENT, "NO_EVENT"},
		{CKR_NEED_TO_CREATE_THREADS, "NEED_TO_CREATE_THREADS"},
		{CKR_CANT_LOCK, "CANT_LOCK"},
		{CKR_ATTRIBUTE_READ_ONLY, "ATTRIBUTE_READ_ONLY"},
		{CKR_ATTRIBUTE_SENSITIVE, "ATTRIBUTE_SENSITIVE"},
		{CKR_ATTRIBUTE_TYPE_INVALID, "ATTRIBUTE_TYPE_INVALID"},
		{CKR_ATTRIBUTE_VALUE_INVALID, "ATTRIBUTE_VALUE_INVALID"},
		{CKR_DATA_INVALID, "DATA_INVALID"},
		{CKR_DATA_LEN_RANGE, "DATA_LEN_RANGE"},
		{CKR_DEVICE_ERROR, "DEVICE_ERROR"},
		{CKR_DEVICE_MEMORY, "DEVICE_MEMORY"},
		{CKR_DEVICE_REMOVED, "DEVICE_REMOVED"},
		{CKR_ENCRYPTED_DATA_INVALID, "ENCRYPTED_DATA_INVALID"},
		{CKR_ENCRYPTED_DATA_LEN_RANGE, "ENCRYPTED_DATA_LEN_RANGE"},
		{CKR_FUNCTION_CANCELED, "FUNCTION_CANCELED"},
		{CKR_FUNCTION_NOT_PARALLEL, "FUNCTION_NOT_PARALLEL"},
		{CKR_FUNCTION_NOT_SUPPORTED, "FUNCTION_NOT_SUPPORTED"},
		{CKR_KEY_HANDLE_INVALID, "KEY_HANDLE_INVALID"},
		{CKR_KEY_SIZE_RANGE, "KEY_SIZE_RANGE"},
		{CKR_KEY_TYPE_INCONSISTENT, "KEY_TYPE_INCONSISTENT"},
		{CKR_KEY_NOT_NEEDED, "KEY_NOT_NEEDED"},
		{CKR_KEY_CHANGED, "KEY_CHANGED"},
		{CKR_KEY_NEEDED, "KEY_NEEDED"},
		{CKR_KEY_INDIGESTIBLE, "KEY_INDIGESTIBLE"},
		{CKR_KEY_FUNCTION_NOT_PERMITTED, "KEY_FUNCTION_NOT_PERMITTED"},
		{CKR_KEY_NOT_WRAPPABLE, "KEY_NOT_WRAPPABLE"},
		{CKR_KEY_UNEXTRACTABLE, "KEY_UNEXTRACTABLE"},
		{CKR_MECHANISM_INVALID, "MECHANISM_INVALID"},
		{CKR_MECHANISM_PARAM_INVALID, "MECHANISM_PARAM_INVALID"},
		{CKR_OBJECT_HANDLE_INVALID, "OBJECT_HANDLE_INVALID"},
		{CKR_OPERATION_ACTIVE, "OPERATION_ACTIVE"},
		{CKR_OPERATION_NOT_INITIALIZED, "OPERATION_NOT_INITIALIZED"},
		{CKR_PIN_INCORRECT, "PIN_INCORRECT"},
		{CKR_PIN_INVALID, "PIN_INVALID"},
		{CKR_PIN_LEN_RANGE, "PIN_LEN_RANGE"},
		{CKR_PIN_EXPIRED, "PIN_EXPIRED"},
		{CKR_PIN_LOCKED, "PIN_LOCKED"},
		{CKR_SESSION_CLOSED, "SESSION_CLOSED"},
		{CKR_SESSION_COUNT, "SESSION_COUNT"},
		{CKR_SESSION_HANDLE_INVALID, "SESSION_HANDLE_INVALID"},
		{CKR_SESSION_PARALLEL_NOT_SUPPORTED, "SESSION_PARALLEL_NOT_SUPPORTED"},
		{CKR_SESSION_READ_ONLY, "SESSION_READ_ONLY"},
		{CKR_SESSION_EXISTS, "SESSION_EXISTS"},
		{CKR_SESSION_READ_ONLY_EXISTS, "SESSION_READ_ONLY_EXISTS"},
		{CKR_SESSION_READ_WRITE_SO_EXISTS, "SESSION_READ_WRITE_SO_EXISTS"},
		{CKR_SIGNATURE_INVALID, "SIGNATURE_INVALID"},
		{CKR_SIGNATURE_LEN_RANGE, "SIGNATURE_LEN_RANGE"},
		{CKR_TEMPLATE_INCOMPLETE, "TEMPLATE_INCOMPLETE"},
		{CKR_TEMPLATE_INCONSISTENT, "TEMPLATE_INCONSISTENT"},
		{CKR_TOKEN_NOT_PRESENT, "TOKEN_NOT_PRESENT"},
		{CKR_TOKEN_NOT_RECOGNIZED, "TOKEN_NOT_RECOGNIZED"},
		{CKR_TOKEN_WRITE_PROTECTED, "TOKEN_WRITE_PROTECTED"},
		{CKR_UNWRAPPING_KEY_HANDLE_INVALID, "UNWRAPPING_KEY_HANDLE_INVALID"},
		{CKR_UNWRAPPING_KEY_SIZE_RANGE, "UNWRAPPING_KEY_SIZE_RANGE"},
		{CKR_UNWRAPPING_KEY_TYPE_INCONSISTENT, "UNWRAPPING_KEY_TYPE_INCONSISTENT"},
		{CKR_USER_ALREADY_LOGGED_IN, "USER_ALREADY_LOGGED_IN"},
		{CKR_USER_NOT_LOGGED_IN, "USER_NOT_LOGGED_IN"},
		{CKR_USER_PIN_NOT_INITIALIZED, "USER_PIN_NOT_INITIALIZED"},
		{CKR_USER_TYPE_INVALID, "USER_TYPE_INVALID"},
		{CKR_USER_ANOTHER_ALREADY_LOGGED_IN, "USER_ANOTHER_ALREADY_LOGGED_IN"},
		{CKR_USER_TOO_MANY_TYPES, "USER_TOO_MANY_TYPES"},
		{CKR_WRAPPED_KEY_INVALID, "WRAPPED_KEY_INVALID"},
		{CKR_WRAPPED_KEY_LEN_RANGE, "WRAPPED_KEY_LEN_RANGE"},
		{CKR_WRAPPING_KEY_HANDLE_INVALID, "WRAPPING_KEY_HANDLE_INVALID"},
		{CKR_WRAPPING_KEY_SIZE_RANGE, "WRAPPING_KEY_SIZE_RANGE"},
		{CKR_WRAPPING_KEY_TYPE_INCONSISTENT, "WRAPPING_KEY_TYPE_INCONSISTENT"},
		{CKR_RANDOM_SEED_NOT_SUPPORTED, "RANDOM_SEED_NOT_SUPPORTED"},
		{CKR_RANDOM_NO_RNG, "RANDOM_NO_RNG"},
		{CKR_BUFFER_TOO_SMALL, "BUFFER_TOO_SMALL"},
		{CKR_SAVED_STATE_INVALID, "SAVED_STATE_INVALID"},
		{CKR_INFORMATION_SENSITIVE, "INFORMATION_SENSITIVE"},
		{CKR_STATE_UNSAVEABLE, "STATE_UNSAVEABLE"},
		{CKR_CRYPTOKI_NOT_INITIALIZED, "CRYPTOKI_NOT_INITIALIZED"},
		{CKR_CRYPTOKI_ALREADY_INITIALIZED, "CRYPTOKI_ALREADY_INITIALIZED"},
		{CKR_MUTEX_BAD, "MUTEX_BAD"},
		{CKR_MUTEX_NOT_LOCKED, "MUTEX_NOT_LOCKED"},

		/* Note: CKR_VENDOR_DEFINED handled below */
	};

	int i;

	/* Search the table. */
	/* Note: we're using a linear search; shouldn't be too slow
	** with only about 84 entries...
	*/
	/* Return the _first_ match (order given by PKCS#11 specification). */

	for (i = 0; i < sizeof(t) / sizeof(*t); i++) {
		if (t[i].key == rv) {
			return t[i].value;
		}
	}

	if (buf == NULL || size < 64) {
		return "UNKNOWN_CRYPTOKI_ERRORCODE";
	}

	sprintf(buf, "%s_0x%08lx",
		(rv >= CKR_VENDOR_DEFINED ?
			"VENDOR_DEFINED_ERRORCODE" :
			"ERRORCODE"),
		rv);
	return (const char*)buf;
}


/* Map PKCS#11 API error reason to OpenSSL error reason. */
int p11_errorReason(CK_RV rv)
{
	static struct {
		CK_RV key;
		int value;
	} const t[] = {
#if defined(P11_NO_ERRORS)
		{0, 0},
#else
		{CKR_OK, PKCS11_R_CKR_OK},
		{CKR_CANCEL, PKCS11_R_CKR_CANCEL},
		{CKR_HOST_MEMORY, PKCS11_R_CKR_HOST_MEMORY},
		{CKR_SLOT_ID_INVALID, PKCS11_R_CKR_SLOT_ID_INVALID},
		{CKR_GENERAL_ERROR, PKCS11_R_CKR_GENERAL_ERROR},
		{CKR_FUNCTION_FAILED, PKCS11_R_CKR_FUNCTION_FAILED},
		{CKR_ARGUMENTS_BAD, PKCS11_R_CKR_ARGUMENTS_BAD},
		{CKR_NO_EVENT, PKCS11_R_CKR_NO_EVENT},
		{CKR_NEED_TO_CREATE_THREADS, PKCS11_R_CKR_NEED_TO_CREATE_THREADS},
		{CKR_CANT_LOCK, PKCS11_R_CKR_CANT_LOCK},
		{CKR_ATTRIBUTE_READ_ONLY, PKCS11_R_CKR_ATTRIBUTE_READ_ONLY},
		{CKR_ATTRIBUTE_SENSITIVE, PKCS11_R_CKR_ATTRIBUTE_SENSITIVE},
		{CKR_ATTRIBUTE_TYPE_INVALID, PKCS11_R_CKR_ATTRIBUTE_TYPE_INVALID},
		{CKR_ATTRIBUTE_VALUE_INVALID, PKCS11_R_CKR_ATTRIBUTE_VALUE_INVALID},
		{CKR_DATA_INVALID, PKCS11_R_CKR_DATA_INVALID},
		{CKR_DATA_LEN_RANGE, PKCS11_R_CKR_DATA_LEN_RANGE},
		{CKR_DEVICE_ERROR, PKCS11_R_CKR_DEVICE_ERROR},
		{CKR_DEVICE_MEMORY, PKCS11_R_CKR_DEVICE_MEMORY},
		{CKR_DEVICE_REMOVED, PKCS11_R_CKR_DEVICE_REMOVED},
		{CKR_ENCRYPTED_DATA_INVALID, PKCS11_R_CKR_ENCRYPTED_DATA_INVALID},
		{CKR_ENCRYPTED_DATA_LEN_RANGE, PKCS11_R_CKR_ENCRYPTED_DATA_LEN_RANGE},
		{CKR_FUNCTION_CANCELED, PKCS11_R_CKR_FUNCTION_CANCELED},
		{CKR_FUNCTION_NOT_PARALLEL, PKCS11_R_CKR_FUNCTION_NOT_PARALLEL},
		{CKR_FUNCTION_NOT_SUPPORTED, PKCS11_R_CKR_FUNCTION_NOT_SUPPORTED},
		{CKR_KEY_HANDLE_INVALID, PKCS11_R_CKR_KEY_HANDLE_INVALID},
		{CKR_KEY_SIZE_RANGE, PKCS11_R_CKR_KEY_SIZE_RANGE},
		{CKR_KEY_TYPE_INCONSISTENT, PKCS11_R_CKR_KEY_TYPE_INCONSISTENT},
		{CKR_KEY_NOT_NEEDED, PKCS11_R_CKR_KEY_NOT_NEEDED},
		{CKR_KEY_CHANGED, PKCS11_R_CKR_KEY_CHANGED},
		{CKR_KEY_NEEDED, PKCS11_R_CKR_KEY_NEEDED},
		{CKR_KEY_INDIGESTIBLE, PKCS11_R_CKR_KEY_INDIGESTIBLE},
		{CKR_KEY_FUNCTION_NOT_PERMITTED, PKCS11_R_CKR_KEY_FUNCTION_NOT_PERMITTED},
		{CKR_KEY_NOT_WRAPPABLE, PKCS11_R_CKR_KEY_NOT_WRAPPABLE},
		{CKR_KEY_UNEXTRACTABLE, PKCS11_R_CKR_KEY_UNEXTRACTABLE},
		{CKR_MECHANISM_INVALID, PKCS11_R_CKR_MECHANISM_INVALID},
		{CKR_MECHANISM_PARAM_INVALID, PKCS11_R_CKR_MECHANISM_PARAM_INVALID},
		{CKR_OBJECT_HANDLE_INVALID, PKCS11_R_CKR_OBJECT_HANDLE_INVALID},
		{CKR_OPERATION_ACTIVE, PKCS11_R_CKR_OPERATION_ACTIVE},
		{CKR_OPERATION_NOT_INITIALIZED, PKCS11_R_CKR_OPERATION_NOT_INITIALIZED},
		{CKR_PIN_INCORRECT, PKCS11_R_CKR_PIN_INCORRECT},
		{CKR_PIN_INVALID, PKCS11_R_CKR_PIN_INVALID},
		{CKR_PIN_LEN_RANGE, PKCS11_R_CKR_PIN_LEN_RANGE},
		{CKR_PIN_EXPIRED, PKCS11_R_CKR_PIN_EXPIRED},
		{CKR_PIN_LOCKED, PKCS11_R_CKR_PIN_LOCKED},
		{CKR_SESSION_CLOSED, PKCS11_R_CKR_SESSION_CLOSED},
		{CKR_SESSION_COUNT, PKCS11_R_CKR_SESSION_COUNT},
		{CKR_SESSION_HANDLE_INVALID, PKCS11_R_CKR_SESSION_HANDLE_INVALID},
		{CKR_SESSION_PARALLEL_NOT_SUPPORTED, PKCS11_R_CKR_SESSION_PARALLEL_NOT_SUPPORTED},
		{CKR_SESSION_READ_ONLY, PKCS11_R_CKR_SESSION_READ_ONLY},
		{CKR_SESSION_EXISTS, PKCS11_R_CKR_SESSION_EXISTS},
		{CKR_SESSION_READ_ONLY_EXISTS, PKCS11_R_CKR_SESSION_READ_ONLY_EXISTS},
		{CKR_SESSION_READ_WRITE_SO_EXISTS, PKCS11_R_CKR_SESSION_READ_WRITE_SO_EXISTS},
		{CKR_SIGNATURE_INVALID, PKCS11_R_CKR_SIGNATURE_INVALID},
		{CKR_SIGNATURE_LEN_RANGE, PKCS11_R_CKR_SIGNATURE_LEN_RANGE},
		{CKR_TEMPLATE_INCOMPLETE, PKCS11_R_CKR_TEMPLATE_INCOMPLETE},
		{CKR_TEMPLATE_INCONSISTENT, PKCS11_R_CKR_TEMPLATE_INCONSISTENT},
		{CKR_TOKEN_NOT_PRESENT, PKCS11_R_CKR_TOKEN_NOT_PRESENT},
		{CKR_TOKEN_NOT_RECOGNIZED, PKCS11_R_CKR_TOKEN_NOT_RECOGNIZED},
		{CKR_TOKEN_WRITE_PROTECTED, PKCS11_R_CKR_TOKEN_WRITE_PROTECTED},
		{CKR_UNWRAPPING_KEY_HANDLE_INVALID, PKCS11_R_CKR_UNWRAPPING_KEY_HANDLE_INVALID},
		{CKR_UNWRAPPING_KEY_SIZE_RANGE, PKCS11_R_CKR_UNWRAPPING_KEY_SIZE_RANGE},
		{CKR_UNWRAPPING_KEY_TYPE_INCONSISTENT, PKCS11_R_CKR_UNWRAPPING_KEY_TYPE_INCONSISTENT},
		{CKR_USER_ALREADY_LOGGED_IN, PKCS11_R_CKR_USER_ALREADY_LOGGED_IN},
		{CKR_USER_NOT_LOGGED_IN, PKCS11_R_CKR_USER_NOT_LOGGED_IN},
		{CKR_USER_PIN_NOT_INITIALIZED, PKCS11_R_CKR_USER_PIN_NOT_INITIALIZED},
		{CKR_USER_TYPE_INVALID, PKCS11_R_CKR_USER_TYPE_INVALID},
		{CKR_USER_ANOTHER_ALREADY_LOGGED_IN, PKCS11_R_CKR_USER_ANOTHER_ALREADY_LOGGED_IN},
		{CKR_USER_TOO_MANY_TYPES, PKCS11_R_CKR_USER_TOO_MANY_TYPES},
		{CKR_WRAPPED_KEY_INVALID, PKCS11_R_CKR_WRAPPED_KEY_INVALID},
		{CKR_WRAPPED_KEY_LEN_RANGE, PKCS11_R_CKR_WRAPPED_KEY_LEN_RANGE},
		{CKR_WRAPPING_KEY_HANDLE_INVALID, PKCS11_R_CKR_WRAPPING_KEY_HANDLE_INVALID},
		{CKR_WRAPPING_KEY_SIZE_RANGE, PKCS11_R_CKR_WRAPPING_KEY_SIZE_RANGE},
		{CKR_WRAPPING_KEY_TYPE_INCONSISTENT, PKCS11_R_CKR_WRAPPING_KEY_TYPE_INCONSISTENT},
		{CKR_RANDOM_SEED_NOT_SUPPORTED, PKCS11_R_CKR_RANDOM_SEED_NOT_SUPPORTED},
		{CKR_RANDOM_NO_RNG, PKCS11_R_CKR_RANDOM_NO_RNG},
		{CKR_BUFFER_TOO_SMALL, PKCS11_R_CKR_BUFFER_TOO_SMALL},
		{CKR_SAVED_STATE_INVALID, PKCS11_R_CKR_SAVED_STATE_INVALID},
		{CKR_INFORMATION_SENSITIVE, PKCS11_R_CKR_INFORMATION_SENSITIVE},
		{CKR_STATE_UNSAVEABLE, PKCS11_R_CKR_STATE_UNSAVEABLE},
		{CKR_CRYPTOKI_NOT_INITIALIZED, PKCS11_R_CKR_CRYPTOKI_NOT_INITIALIZED},
		{CKR_CRYPTOKI_ALREADY_INITIALIZED, PKCS11_R_CKR_CRYPTOKI_ALREADY_INITIALIZED},
		{CKR_MUTEX_BAD, PKCS11_R_CKR_MUTEX_BAD},
		{CKR_MUTEX_NOT_LOCKED, PKCS11_R_CKR_MUTEX_NOT_LOCKED},
		{CKR_VENDOR_DEFINED, PKCS11_R_CKR_VENDOR_DEFINED},
#endif
	};

	int i;

	/* Search the table. */
	/* Note: we're using a linear search; shouldn't be too slow
	** with only about 84 entries...
	*/
	/* Return the _first_ match (order given by PKCS#11 specification). */

	for (i = 0; i < sizeof(t) / sizeof(*t); i++) {
		if (t[i].key == rv) {
			return t[i].value;
		}
	}

	/* Push our own error, too. */
	PKCS11err(PKCS11_F_P11_ERRORREASON, PKCS11_R_UNKNOWN_CRYPTOKI_ERRORCODE);

#if defined(P11_NO_ERRORS)
	return 0;
#else
	return PKCS11_R_UNKNOWN_CRYPTOKI_ERRORCODE;
#endif
}


/* Map PKCS#11 API error reason to OpenSSL error hints. */
int p11_errorHints(CK_RV rv, int* hints, int size)
{
	static struct {
		CK_RV key;
		int value;
	} const t[] = {
#if defined(P11_NO_ERRORS)
		{0, 0},
#else
		{CKR_OK, PKCS11_R_HINT_NOT_AN_ERROR_JUST_IGNORE},
		{CKR_HOST_MEMORY, PKCS11_R_HINT_OUT_OF_MEMORY},
		{CKR_CRYPTOKI_NOT_INITIALIZED, PKCS11_R_HINT_PROCESS_FORKED_WITHOUT_NEW_PKCS11},
		{CKR_CRYPTOKI_ALREADY_INITIALIZED, PKCS11_R_HINT_PROCESS_ALREADY_USES_A_PKCS11},
#endif
	};

	int i, n;

	/* [guard(s)] */
	if (hints == NULL || size <= 0) {
		return 0;
	}

	/* Search the table. */
	/* Note: we're using a linear search; shouldn't be too slow... */
	/* Push as many hints as fit. */

	n = 0;
	for (i = 0; i < sizeof(t) / sizeof(*t) && n < size; i++) {
		if (t[i].key == rv) {
			hints[n] = t[i].value;
			n++;
		}
	}

	return n;
}

