/* p11_trc.h -- OpenSSL pkcs11 code -- tracing helper macros. */
/* Written by AdNovum Informatik AG, Nenad Tomasic (nenad.tomasic@adnovum.ch),
 * Matthias Loepfe (matthias.loepfe@adnovum.ch) and
 * Eric Laroche (eric.laroche@adnovum.ch) for the OpenSSL project 2001.
 */
/* ====================================================================
 * Copyright (c) 2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


/* [include guard] */
#ifndef P11_TRC_H
#define P11_TRC_H


#if defined(P11_TRACE)


#include <stdio.h>


/* Tracing flag. */
int p11_doTrace(void);

/* Tracing output. */
FILE* p11_traceOut(void);


/* Trace. */

/* Note: lint's CONSTCOND comment doesn't work with these macros. */

/* Note: we're neither interested in the (exact) timing, nor in process
** (or thread) ids, nor in any (function class, etc,) grouping.  Neither
** do we use 'severity' levels, it's all 'debug'.  However, we'd
** appreciate if the o.s. would be atomic on the fflush, i.e. not
** intermixing outputs from different processes.
*/

#define P11_TRC0(fmt) \
	do { \
		if (p11_doTrace()) { \
			fprintf(p11_traceOut(), (fmt)); \
			fprintf(p11_traceOut(), "\n"); \
			fflush(p11_traceOut()); \
		} \
	} while (0)

#define P11_TRC1(fmt, arg1) \
	do { \
		if (p11_doTrace()) { \
			fprintf(p11_traceOut(), (fmt), (arg1)); \
			fprintf(p11_traceOut(), "\n"); \
			fflush(p11_traceOut()); \
		} \
	} while (0)

#define P11_TRC2(fmt, arg1, arg2) \
	do { \
		if (p11_doTrace()) { \
			fprintf(p11_traceOut(), (fmt), (arg1), (arg2)); \
			fprintf(p11_traceOut(), "\n"); \
			fflush(p11_traceOut()); \
		} \
	} while (0)

#define P11_TRC3(fmt, arg1, arg2, arg3) \
	do { \
		if (p11_doTrace()) { \
			fprintf(p11_traceOut(), (fmt), (arg1), (arg2), (arg3)); \
			fprintf(p11_traceOut(), "\n"); \
			fflush(p11_traceOut()); \
		} \
	} while (0)


#else

/* Don't trace. */
#define P11_TRC0(fmt) ((void)0)
#define P11_TRC1(fmt, arg1) ((void)0)
#define P11_TRC2(fmt, arg1, arg2) ((void)0)
#define P11_TRC3(fmt, arg1, arg2, arg3) ((void)0)


#endif


#endif

