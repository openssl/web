/* crypto/engine/hw_zencod.c */
 /* Written by Fred Donnat (frederic.donnat@zencod.com) for "zencod"
 * engine integration in order to redirect crypto computing on a crypto
 * hardware accelerator zenssl32  ;-)
 *
 * Date : 04 Jan 2002
 * Revision : 17 Jul 2002
 * Version : zencod_engine-0.9.6x
 */

/* ====================================================================
 * Copyright (c) 1999-2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */

/*
 * This is the Zencod engine V-0.9.6x for OpenSSL openssl-engine-0.9.6x, which
 * supports RSA, DSA, DH, and RNG.
 *
 * It links with zenbridge library to access the hardware.
 */


#ifndef	OPENSSL_NO_HW
#ifndef	OPENSSL_NO_HW_ZENCOD

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <openssl/crypto.h>
#include <openssl/dso.h>
#include <openssl/err.h>
#include "engine_int.h"
#include <openssl/engine.h>

/* Stripped down version of zenbridge.h */
#ifdef FLAT_INC
#  include "hw_zencod.h"
#else
#  include "vendor_defns/hw_zencod.h"
#endif


#define	ZEN_LIBRARY	"zenbridge"

#if 0
#  define PERROR(s)	perror(s)
#  define CHEESE()	fputs("## [ZenEngine] ## " __FUNCTION__ "\n", stderr)
#else
#  define PERROR(s)
#  define CHEESE()
#endif


/* Sorry ;) */
#ifndef WIN32
static inline void esrever ( unsigned char *d, int l )
{
	for(;--l>0;--l,d++){*d^=*(d+l);*(d+l)^=*d;*d^=*(d+l);}
}

static inline void ypcmem ( unsigned char *d, const unsigned char *s, int l )
{
	for(d+=l;l--;)*--d=*s++;
}
#else
static __inline void esrever ( unsigned char *d, int l )
{
	for(;--l>0;--l,d++){*d^=*(d+l);*(d+l)^=*d;*d^=*(d+l);}
}

static __inline void ypcmem ( unsigned char *d, const unsigned char *s, int l )
{
	for(d+=l;l--;)*--d=*s++;
}
#endif /* WIN32 */


#define BIGNUM2ZEN(n, bn)	(ptr_zencod_init_number((n), \
						       (unsigned long) ((bn)->top * BN_BITS2), \
						       (unsigned char *) ((bn)->d)))

#define ZEN_BITS(n, bytes)	(ptr_zencod_bytes2bits((unsigned char *) (n), (unsigned long) (bytes)))
#define ZEN_BYTES(bits)	(ptr_zencod_bits2bytes((unsigned long) (bits)))


/* Function for ENGINE detection and control */
static int zencod_init ( void ) ;
static int zencod_finish ( void ) ;


/* BIGNUM stuff (Modular Exponentiation) */
static int zencod_bn_mod_exp ( BIGNUM *r, BIGNUM *a, const BIGNUM *p, const BIGNUM *m, BN_CTX *ctx ) ;

/* RSA stuff */
#ifndef OPENSSL_NO_RSA
static int RSA_zencod_rsa_mod_exp ( BIGNUM *r0, BIGNUM *i, RSA *rsa ) ;
static int RSA_zencod_bn_mod_exp ( BIGNUM *r, BIGNUM *a, const BIGNUM *p,
		const BIGNUM *m, BN_CTX *ctx, BN_MONT_CTX *m_ctx ) ;
#endif

/* DSA stuff */
#ifndef OPENSSL_NO_DSA
static int DSA_zencod_bn_mod_exp ( DSA *dsa, BIGNUM *r, BIGNUM *a, const BIGNUM *p, const BIGNUM *m, BN_CTX *ctx,
		BN_MONT_CTX *m_ctx ) ;

static DSA_SIG *DSA_zencod_do_sign ( const unsigned char *dgst, int dlen, DSA *dsa ) ;
static int DSA_zencod_do_verify ( const unsigned char *dgst, int dgst_len, DSA_SIG *sig,
		DSA *dsa ) ;
#endif

/* DH stuff */
#ifndef OPENSSL_NO_DH
static int DH_zencod_bn_mod_exp ( DH *dh, BIGNUM *r, BIGNUM *a, const BIGNUM *p, const BIGNUM *m, BN_CTX *ctx,
		BN_MONT_CTX *m_ctx ) ;
static int DH_zencod_generate_key ( DH *dh ) ;
static int DH_zencod_compute_key ( unsigned char *key, BIGNUM *pub_key, DH *dh ) ;
#endif

/* Rand stuff */
static int RAND_zencod_rand_bytes ( unsigned char *buf, int num ) ;
static int RAND_zencod_status ( void ) ;


#ifndef OPENSSL_NO_RSA
/* Our internal RSA_METHOD specific to zencod ENGINE providing pointers to our function */
static RSA_METHOD zencod_rsa = {
	"ZENCOD RSA method",
	NULL,
	NULL,
	NULL,
	NULL,
	/* Prototype :
	* int (*rsa_mod_exp) ( BIGNUM *r0, BIGNUM *I, RSA *rsa ) ; */
	RSA_zencod_rsa_mod_exp,
	/* Prototype :
	 * int (*bn_mod_exp) ( BIGNUM *r, BIGNUM *a, const BIGNUM *p, const BIGNUM *m,
	 *		BN_CTX *ctx, BN_MONT_CTX *m_ctx ) ; */
	RSA_zencod_bn_mod_exp,
	NULL,
	NULL,
	0,
	NULL,
	NULL,
	NULL
} ;
#endif

#ifndef OPENSSL_NO_DSA
/* Our internal DSA_METHOD specific to zencod ENGINE providing pointers to our function */
static DSA_METHOD zencod_dsa = {
	"ZENCOD DSA method",
	DSA_zencod_do_sign,
	NULL,
	DSA_zencod_do_verify,
	NULL,
	DSA_zencod_bn_mod_exp,
	NULL,
	NULL,
	0,
	NULL
} ;
#endif

#ifndef OPENSSL_NO_DH
/* Our internal DH_METHOD specific to zencod ENGINE providing pointers to our function */
static DH_METHOD zencod_dh = {
	"ZENCOD DH method",
	DH_zencod_generate_key,
	/* Prototype :
	 * int (*compute_key) ( unsigned char *key, BIGNUM *pub_key, DH *dh ) ; */
	DH_zencod_compute_key,
	/* Prototype :
	 * int (*bn_mod_exp) ( DH *dh, BIGNUM *r, BIGNUM *a, const BIGNUM *p, const BIGNUM *m,
	 *		BN_CTX *ctx, BN_MONT_CTX *m_ctx ) ; */
	DH_zencod_bn_mod_exp,
	NULL,
	NULL,
	0,
	NULL
} ;
#endif

/* Our internal RAND_meth specific to zencod ZNGINE providing pointers to  our function */
static RAND_METHOD zencod_rand = {
	NULL,
	RAND_zencod_rand_bytes,
	NULL,
	NULL,
	NULL,
	RAND_zencod_status
} ;


/* Our ENGINE structure. */
static ENGINE engine_zencod = {
	"zencod",
	"ZENCOD hardware engine support",
	&( zencod_rsa ),
	&( zencod_dsa ),
	&( zencod_dh ),
	&( zencod_rand ) ,
	zencod_bn_mod_exp,
	NULL,
	zencod_init,
	zencod_finish,
	NULL, /* no ctrl() */
	NULL, /* no load_privkey() */
	NULL, /* no load_pubkey() */
	0, /* no flags */
	0, 0, /* no references */
	NULL, NULL /* unlinked */
} ;


/* As this is only ever called once, there's no need for locking
 * (indeed - the lock will already be held by our caller!!!)
 */
ENGINE *ENGINE_zencod ( void )
{

#ifndef OPENSSL_NO_RSA
	const RSA_METHOD *meth_rsa ;
#endif
#ifndef OPENSSL_NO_DSA
	const DSA_METHOD *meth_dsa ;
#endif
#ifndef OPENSSL_NO_DH
	const DH_METHOD *meth_dh ;
#endif

	const RAND_METHOD *meth_rand ;

	CHEESE();

#ifndef OPENSSL_NO_RSA
	/* We know that the "PKCS1_SSLeay()" functions hook properly
	 * to the Zencod-specific mod_exp and mod_exp_crt so we use
	 * those functions. NB: We don't use ENGINE_openssl() or
	 * anything "more generic" because something like the RSAref
	 * code may not hook properly, and if you own one of these
	 * cards then you have the right to do RSA operations on it
	 * anyway!
	 */
	meth_rsa = RSA_PKCS1_SSLeay () ;

	zencod_rsa.rsa_pub_enc = meth_rsa->rsa_pub_enc ;
	zencod_rsa.rsa_pub_dec = meth_rsa->rsa_pub_dec ;
	zencod_rsa.rsa_priv_enc = meth_rsa->rsa_priv_enc ;
	zencod_rsa.rsa_priv_dec = meth_rsa->rsa_priv_dec ;
	/* meth_rsa->rsa_mod_exp */
	/* meth_rsa->bn_mod_exp */
	zencod_rsa.init = meth_rsa->init ;
	zencod_rsa.finish = meth_rsa->finish ;
#endif

#ifndef OPENSSL_NO_DSA
	/* We use OpenSSL meth to supply what we don't provide ;-)
	 */
	meth_dsa = DSA_OpenSSL () ;

	/* meth_dsa->dsa_do_sign */
	zencod_dsa.dsa_sign_setup = meth_dsa->dsa_sign_setup ;
	/* meth_dsa->dsa_do_verify */
	zencod_dsa.dsa_mod_exp = meth_dsa->dsa_mod_exp ;
	/* zencod_dsa.bn_mod_exp = meth_dsa->bn_mod_exp ; */
	zencod_dsa.init = meth_dsa->init ;
	zencod_dsa.finish = meth_dsa->finish ;
#endif

#ifndef OPENSSL_NO_DH
	/* We use OpenSSL meth to supply what we don't provide ;-)
	 */
	meth_dh = DH_OpenSSL () ;

	/* zencod_dh.generate_key = meth_dh->generate_key ; */
	/* zencod_dh.compute_key = meth_dh->compute_key ; */
	/* zencod_dh.bn_mod_exp = meth_dh->bn_mod_exp ; */
	zencod_dh.init = meth_dh->init ;
	zencod_dh.finish = meth_dh->finish ;
#endif

	/* We use OpenSSL (SSLeay) meth to supply what we don't provide ;-)
	 */
	meth_rand = RAND_SSLeay () ;

	zencod_rand.seed = meth_rand->seed ;
	/* meth_rand->bytes ; */
	zencod_rand.cleanup = meth_rand->cleanup ;
	zencod_rand.add = meth_rand->add ;
	zencod_rand.pseudorand = meth_rand->pseudorand ;
	/* meth_rand->status ; */
	/* To avoid ventual problem with RAND status let's use the classic function ... */
	zencod_rand.status = meth_rand->status ;

	return &( engine_zencod ) ;
}


/* This is a process-global DSO handle used for loading and unloading
 * the ZENBRIDGE library.
 * NB: This is only set (or unset) during an * init () or finish () call
 * (reference counts permitting) and they're  * operating with global locks,
 * so this should be thread-safe * implicitly.
 */
static DSO *zencod_dso = NULL ;

static t_zencod_test *ptr_zencod_test = NULL ;
static t_zencod_bytes2bits *ptr_zencod_bytes2bits = NULL ;
static t_zencod_bits2bytes *ptr_zencod_bits2bytes = NULL ;
static t_zencod_new_number *ptr_zencod_new_number = NULL ;
static t_zencod_init_number *ptr_zencod_init_number = NULL ;

static t_zencod_rsa_mod_exp *ptr_zencod_rsa_mod_exp = NULL ;
static t_zencod_rsa_mod_exp_crt *ptr_zencod_rsa_mod_exp_crt = NULL ;
static t_zencod_dsa_do_sign *ptr_zencod_dsa_do_sign = NULL ;
static t_zencod_dsa_do_verify *ptr_zencod_dsa_do_verify = NULL ;
static t_zencod_dh_generate_key *ptr_zencod_dh_generate_key = NULL ;
static t_zencod_dh_compute_key *ptr_zencod_dh_compute_key = NULL ;
static t_zencod_rand_bytes *ptr_zencod_rand_bytes = NULL ;
static t_zencod_math_mod_exp *ptr_zencod_math_mod_exp = NULL ;


/* These are the static string constants for the DSO file name and the function
 * symbol names to bind to.
 */
static const char *ZENCOD_LIBNAME = ZEN_LIBRARY ;

static const char *ZENCOD_Fct_0 = "test_device" ;
static const char *ZENCOD_Fct_1 = "zenbridge_bytes2bits" ;
static const char *ZENCOD_Fct_2 = "zenbridge_bits2bytes" ;
static const char *ZENCOD_Fct_3 = "zenbridge_new_number" ;
static const char *ZENCOD_Fct_4 = "zenbridge_init_number" ;

static const char *ZENCOD_Fct_exp_1 = "zenbridge_rsa_mod_exp" ;
static const char *ZENCOD_Fct_exp_2 = "zenbridge_rsa_mod_exp_crt" ;
static const char *ZENCOD_Fct_dsa_1 = "zenbridge_dsa_do_sign" ;
static const char *ZENCOD_Fct_dsa_2 = "zenbridge_dsa_do_verify" ;
static const char *ZENCOD_Fct_dh_1 = "zenbridge_dh_generate_key" ;
static const char *ZENCOD_Fct_dh_2 = "zenbridge_dh_compute_key" ;
static const char *ZENCOD_Fct_rand_1 = "zenbridge_rand_bytes" ;
static const char *ZENCOD_Fct_math_1 = "zenbridge_math_mod_exp" ;


/* (de)initialisation functions. Control Function
 */
static int zencod_init ( void )
{

	t_zencod_test *ptr_0 ;
	t_zencod_bytes2bits *ptr_1 ;
	t_zencod_bits2bytes *ptr_2 ;
	t_zencod_new_number *ptr_3 ;
	t_zencod_init_number *ptr_4 ;
	t_zencod_rsa_mod_exp *ptr_exp_1 ;
	t_zencod_rsa_mod_exp_crt *ptr_exp_2 ;
	t_zencod_dsa_do_sign *ptr_dsa_1 ;
	t_zencod_dsa_do_verify *ptr_dsa_2 ;
	t_zencod_dh_generate_key *ptr_dh_1 ;
	t_zencod_dh_compute_key *ptr_dh_2 ;
	t_zencod_rand_bytes *ptr_rand_1 ;
	t_zencod_math_mod_exp *ptr_math_1 ;

	CHEESE();

	/*
	 * We Should add some tests for non NULL parameters or bad value !!
	 * Stuff to be done ...
	 */
	if ( zencod_dso != NULL ) {
		ENGINEerr ( ENGINE_F_ZENCOD_INIT, ENGINE_R_ALREADY_LOADED ) ;
		goto err ;
	}
	/* Trying to load the Library "cryptozen"
	 */

	zencod_dso = DSO_load ( NULL, ZENCOD_LIBNAME, NULL, DSO_FLAG_NAME_TRANSLATION ) ;
	if ( zencod_dso == NULL ) {
		ENGINEerr ( ENGINE_F_ZENCOD_INIT, ENGINE_R_DSO_FAILURE ) ;
		goto err ;
	}

	/* Trying to load Function from the Library
	 */
	if ( ! ( ptr_1 = (t_zencod_bytes2bits*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_1 ) ) ||
			! ( ptr_2 = (t_zencod_bits2bytes*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_2 ) ) ||
			! ( ptr_3 = (t_zencod_new_number*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_3 ) ) ||
			! ( ptr_4 = (t_zencod_init_number*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_4 ) ) ||
			! ( ptr_exp_1 = (t_zencod_rsa_mod_exp*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_exp_1 ) ) ||
			! ( ptr_exp_2 = (t_zencod_rsa_mod_exp_crt*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_exp_2 ) ) ||
			! ( ptr_dsa_1 = (t_zencod_dsa_do_sign*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_dsa_1 ) ) ||
			! ( ptr_dsa_2 = (t_zencod_dsa_do_verify*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_dsa_2 ) ) ||
			! ( ptr_dh_1 = (t_zencod_dh_generate_key*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_dh_1 ) ) ||
			! ( ptr_dh_2 = (t_zencod_dh_compute_key*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_dh_2 ) ) ||
			! ( ptr_rand_1 = (t_zencod_rand_bytes*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_rand_1 ) ) ||
			! ( ptr_math_1 = (t_zencod_math_mod_exp*) DSO_bind_func ( zencod_dso, ZENCOD_Fct_math_1 ) ) ||
			! ( ptr_0 = (t_zencod_test *) DSO_bind_func ( zencod_dso, ZENCOD_Fct_0 ) ) ) {

		ENGINEerr ( ENGINE_F_ZENCOD_INIT, ENGINE_R_DSO_FAILURE ) ;
		goto err ;
	}

	/* The function from "cryptozen" Library have been correctly loaded so copy them
	 */
	ptr_zencod_test = ptr_0 ;
	ptr_zencod_bytes2bits = ptr_1 ;
	ptr_zencod_bits2bytes = ptr_2 ;
	ptr_zencod_new_number = ptr_3 ;
	ptr_zencod_init_number = ptr_4 ;
	ptr_zencod_rsa_mod_exp = ptr_exp_1 ;
	ptr_zencod_rsa_mod_exp_crt = ptr_exp_2 ;
	ptr_zencod_dsa_do_sign = ptr_dsa_1 ;
	ptr_zencod_dsa_do_verify = ptr_dsa_2 ;
	ptr_zencod_dh_generate_key = ptr_dh_1 ;
	ptr_zencod_dh_compute_key = ptr_dh_2 ;
	ptr_zencod_rand_bytes = ptr_rand_1 ;
	ptr_zencod_math_mod_exp = ptr_math_1 ;

	/* We should peform a test to see if there is actually any unit runnig on the system ...
	 * Even if the cryptozen library is loaded the module coul not be loaded on the system ...
	 * For now we may just open and close the device !!
	 */

	if ( ptr_zencod_test () != 0 ) {
		ENGINEerr ( ENGINE_F_ZENCOD_INIT, ENGINE_R_UNIT_FAILURE ) ;
		goto err ;
	}

	return 1 ;

err :
	if ( zencod_dso ) {
		DSO_free ( zencod_dso ) ;
	}
	ptr_zencod_bytes2bits = NULL ;
	ptr_zencod_bits2bytes = NULL ;
	ptr_zencod_new_number = NULL ;
	ptr_zencod_init_number = NULL ;
	ptr_zencod_rsa_mod_exp = NULL ;
	ptr_zencod_rsa_mod_exp_crt = NULL ;
	ptr_zencod_dsa_do_sign = NULL ;
	ptr_zencod_dsa_do_verify = NULL ;
	ptr_zencod_dh_generate_key = NULL ;
	ptr_zencod_dh_compute_key = NULL ;
	ptr_zencod_rand_bytes = NULL ;
	ptr_zencod_math_mod_exp = NULL ;

	return 0 ;
}


static int zencod_finish ( void )
{
	CHEESE();

	/*
	 * We Should add some tests for non NULL parameters or bad value !!
	 * Stuff to be done ...
	 */
	if ( zencod_dso == NULL ) {
		ENGINEerr ( ENGINE_F_ZENCOD_FINISH, ENGINE_R_NOT_LOADED ) ;
		return 0 ;
	}
	if ( !DSO_free ( zencod_dso ) ) {
		ENGINEerr ( ENGINE_F_ZENCOD_FINISH, ENGINE_R_DSO_FAILURE ) ;
		return 0 ;
	}

	zencod_dso = NULL ;

	ptr_zencod_bytes2bits = NULL ;
	ptr_zencod_bits2bytes = NULL ;
	ptr_zencod_new_number = NULL ;
	ptr_zencod_init_number = NULL ;
	ptr_zencod_rsa_mod_exp = NULL ;
	ptr_zencod_rsa_mod_exp_crt = NULL ;
	ptr_zencod_dsa_do_sign = NULL ;
	ptr_zencod_dsa_do_verify = NULL ;
	ptr_zencod_dh_generate_key = NULL ;
	ptr_zencod_dh_compute_key = NULL ;
	ptr_zencod_rand_bytes = NULL ;
	ptr_zencod_math_mod_exp = NULL ;

	return 1 ;
}


static int zencod_ctrl ( int cmd, long i, void *p, void (*f) () )
{

	CHEESE();

	switch ( cmd )
	{
	default:
		break;
	}
	ENGINEerr ( ENGINE_F_ZENCOD_CTRL, ENGINE_R_CTRL_COMMAND_NOT_IMPLEMENTED ) ;
	return 0 ;
}


/* BIGNUM stuff
 */
static int zencod_bn_mod_exp ( BIGNUM *r, BIGNUM *a, const BIGNUM *p, const BIGNUM *m, BN_CTX *ctx )
{
	zen_nb_t y, x, e, n;
	int ret;

	CHEESE();

	if ( !zencod_dso ) {
		ENGINEerr(ENGINE_F_ZENCOD_BN_MOD_EXP, ENGINE_R_NOT_LOADED);
		return 0;
	}

	if ( !bn_wexpand(r, m->top + 1) ) {
		ENGINEerr(ENGINE_F_ZENCOD_BN_MOD_EXP, ENGINE_R_BN_EXPAND_FAIL);
		return 0;
	}

	memset(r->d, 0, BN_num_bytes(m));

	ptr_zencod_init_number ( &y, (r->dmax - 1) * sizeof (BN_ULONG) * 8, (unsigned char *) r->d ) ;
	BIGNUM2ZEN ( &x, a ) ;
	BIGNUM2ZEN ( &e, p ) ;
	BIGNUM2ZEN ( &n, m ) ;

	/* Must invert x and e parameter due to BN mod exp prototype ... */
	ret = ptr_zencod_math_mod_exp ( &y, &e, &x, &n ) ;

	if ( ret )  {
		PERROR("zenbridge_math_mod_exp");
		ENGINEerr(ENGINE_F_ZENCOD_BN_MOD_EXP, ENGINE_R_REQUEST_FAILED);
		return 0;
	}

	r->top = (BN_num_bits(m) + BN_BITS2 - 1) / BN_BITS2;

	return 1;
}


/* RSA stuff
 */
#ifndef OPENSSL_NO_RSA
static int RSA_zencod_rsa_mod_exp ( BIGNUM *r0, BIGNUM *i, RSA *rsa )
{
	CHEESE();

	if ( !zencod_dso ) {
		ENGINEerr(ENGINE_F_ZENCOD_RSA_MOD_EXP_CRT, ENGINE_R_NOT_LOADED);
		return 0;
	}

	if ( !rsa->p || !rsa->q || !rsa->dmp1 || !rsa->dmq1 || !rsa->iqmp ) {
		ENGINEerr(ENGINE_F_ZENCOD_RSA_MOD_EXP_CRT, ENGINE_R_MISSING_KEY_COMPONENTS);
		return 0;
	}

	/* Do in software if argument is too large for hardware */
	if ( RSA_size(rsa) * 8 > ZENBRIDGE_MAX_KEYSIZE_RSA_CRT ) {
		RSA_METHOD *meth;

		meth = RSA_PKCS1_SSLeay();
		return meth->rsa_mod_exp(r0, i, rsa);
	} else {
		zen_nb_t y, x, p, q, dmp1, dmq1, iqmp;

		if ( !bn_expand(r0, RSA_size(rsa) * 8) ) {
			ENGINEerr(ENGINE_F_ZENCOD_RSA_MOD_EXP_CRT, ENGINE_R_BN_EXPAND_FAIL);
			return 0;
		}
		r0->top = (RSA_size(rsa) * 8 + BN_BITS2 - 1) / BN_BITS2;

		BIGNUM2ZEN ( &x, i ) ;
		BIGNUM2ZEN ( &y, r0 ) ;
		BIGNUM2ZEN ( &p, rsa->p ) ;
		BIGNUM2ZEN ( &q, rsa->q ) ;
		BIGNUM2ZEN ( &dmp1, rsa->dmp1 ) ;
		BIGNUM2ZEN ( &dmq1, rsa->dmq1 ) ;
		BIGNUM2ZEN ( &iqmp, rsa->iqmp ) ;

		if ( ptr_zencod_rsa_mod_exp_crt ( &y, &x, &p, &q, &dmp1, &dmq1, &iqmp ) < 0 ) {
			PERROR("zenbridge_rsa_mod_exp_crt");
			ENGINEerr(ENGINE_F_ZENCOD_RSA_MOD_EXP_CRT, ENGINE_R_REQUEST_FAILED);
			return 0;
		}

		return 1;
	}
}


static int RSA_zencod_bn_mod_exp ( BIGNUM *r, BIGNUM *a, const BIGNUM *p, const BIGNUM *m,
			  BN_CTX *ctx, BN_MONT_CTX *m_ctx )
{
	CHEESE();

	if ( !zencod_dso ) {
		ENGINEerr(ENGINE_F_ZENCOD_RSA_MOD_EXP, ENGINE_R_NOT_LOADED);
		return 0;
	}

	/* Do in software if argument is too large for hardware */
	if ( BN_num_bits(m) > ZENBRIDGE_MAX_KEYSIZE_RSA ) {
		RSA_METHOD *meth;

		meth = RSA_PKCS1_SSLeay();
		return meth->bn_mod_exp(r, a, p, m, ctx, m_ctx);
	} else {
		zen_nb_t y, x, e, n;

		if ( !bn_expand(r, BN_num_bits(m)) ) {
			ENGINEerr(ENGINE_F_ZENCOD_RSA_MOD_EXP, ENGINE_R_BN_EXPAND_FAIL);
			return 0;
		}
		r->top = (BN_num_bits(m) + BN_BITS2 - 1) / BN_BITS2;

		BIGNUM2ZEN ( &x, a ) ;
		BIGNUM2ZEN ( &y, r ) ;
		BIGNUM2ZEN ( &e, p ) ;
		BIGNUM2ZEN ( &n, m ) ;

		if ( ptr_zencod_rsa_mod_exp ( &y, &x, &n, &e ) < 0 ) {
			PERROR("zenbridge_rsa_mod_exp");
			ENGINEerr(ENGINE_F_ZENCOD_RSA_MOD_EXP, ENGINE_R_REQUEST_FAILED);
			return 0;
		}

		return 1;
	}
}
#endif	/* !OPENSSL_NO_RSA */


/* DSA stuff
 */
#ifndef OPENSSL_NO_DSA
static DSA_SIG *DSA_zencod_do_sign ( const unsigned char *dgst, int dlen, DSA *dsa )
{
	zen_nb_t p, q, g, x, y, r, s, data;
	DSA_SIG *sig;
	BIGNUM *bn_r = NULL;
	BIGNUM *bn_s = NULL;
	char msg[20];

	CHEESE();

	if ( !zencod_dso ) {
		ENGINEerr(ENGINE_F_ZENCOD_DSA_DO_SIGN, ENGINE_R_NOT_LOADED);
		goto FAILED;
	}

	if ( dlen > 160 ) {
		ENGINEerr(ENGINE_F_ZENCOD_DSA_DO_SIGN, ENGINE_R_REQUEST_FAILED);
		goto FAILED;
	}

	/* Do in software if argument is too large for hardware */
	/* DONS: This is n'awack ENGINE in ENGINE ??? */
	if ( BN_num_bits(dsa->p) > ZENBRIDGE_MAX_KEYSIZE_DSA_SIGN ||
		BN_num_bits(dsa->g) > ZENBRIDGE_MAX_KEYSIZE_DSA_SIGN ) {
		void *engine = dsa->engine;
		void *ret;

		dsa->engine = ENGINE_openssl();
		ret = (DSA_OpenSSL())->dsa_do_sign(dgst, dlen, dsa);
		dsa->engine = engine;
		return ret;
	}

	if ( !(bn_s = BN_new()) || !(bn_r = BN_new()) ) {
		ENGINEerr(ENGINE_F_ZENCOD_DSA_DO_SIGN, ENGINE_R_MISSING_KEY_COMPONENTS);
		goto FAILED;
	}

	if ( !bn_expand(bn_r, 160) || !bn_expand(bn_s, 160) ) {
		ENGINEerr(ENGINE_F_ZENCOD_DSA_DO_SIGN, ENGINE_R_BN_EXPAND_FAIL);
		goto FAILED;
	}

	bn_r->top = bn_s->top = (160 + BN_BITS2 - 1) / BN_BITS2;
	BIGNUM2ZEN ( &p, dsa->p ) ;
	BIGNUM2ZEN ( &q, dsa->q ) ;
	BIGNUM2ZEN ( &g, dsa->g ) ;
	BIGNUM2ZEN ( &x, dsa->priv_key ) ;
	BIGNUM2ZEN ( &y, dsa->pub_key ) ;
	BIGNUM2ZEN ( &r, bn_r ) ;
	BIGNUM2ZEN ( &s, bn_s ) ;
	q.len = x.len = 160;

	ypcmem(msg, dgst, 20);
	ptr_zencod_init_number ( &data, 160, msg ) ;

	if ( ptr_zencod_dsa_do_sign ( 0, &data, &y, &p, &q, &g, &x, &r, &s ) < 0 ) {
		PERROR("zenbridge_dsa_do_sign");
		ENGINEerr(ENGINE_F_ZENCOD_DSA_DO_SIGN, ENGINE_R_REQUEST_FAILED);
		goto FAILED;
	}

	if ( !( sig = DSA_SIG_new () ) ) {
		ENGINEerr(ENGINE_F_ZENCOD_DSA_DO_SIGN, ENGINE_R_REQUEST_FAILED);
		goto FAILED;
	}
	sig->r = bn_r;
	sig->s = bn_s;
	return sig;

 FAILED:
	if (bn_r)
		BN_free(bn_r);
	if (bn_s)
		BN_free(bn_s);
	return NULL;
}


static int DSA_zencod_do_verify ( const unsigned char *dgst, int dlen, DSA_SIG *sig, DSA *dsa )
{
	zen_nb_t data, p, q, g, y, r, s, v;
	char msg[20];
	char v_data[20];
	int ret;

	CHEESE();

	if ( !zencod_dso ) {
		ENGINEerr(ENGINE_F_ZENCOD_DSA_DO_VERIFY, ENGINE_R_NOT_LOADED);
		return 0;
	}

	if ( dlen > 160 ) {
		ENGINEerr(ENGINE_F_ZENCOD_DSA_DO_SIGN, ENGINE_R_REQUEST_FAILED);
		return 0;
	}

	/* Do in software if argument is too large for hardware */
	/* DONS: This is n'awack ENGINE in ENGINE ??? */
	if ( BN_num_bits(dsa->p) > ZENBRIDGE_MAX_KEYSIZE_DSA_SIGN ||
		BN_num_bits(dsa->g) > ZENBRIDGE_MAX_KEYSIZE_DSA_SIGN ) {
		void *engine = dsa->engine;

		dsa->engine = ENGINE_openssl();
		ret = (DSA_OpenSSL())->dsa_do_verify(dgst, dlen, sig, dsa);
		dsa->engine = engine;
		return ret;
	}

	BIGNUM2ZEN ( &p, dsa->p ) ;
	BIGNUM2ZEN ( &q, dsa->q ) ;
	BIGNUM2ZEN ( &g, dsa->g ) ;
	BIGNUM2ZEN ( &y, dsa->pub_key ) ;
	BIGNUM2ZEN ( &r, sig->r ) ;
	BIGNUM2ZEN ( &s, sig->s ) ;
	ptr_zencod_init_number ( &v, 160, v_data ) ;
	ypcmem(msg, dgst, 20);
	ptr_zencod_init_number ( &data, 160, msg ) ;

	if ( ( ret = ptr_zencod_dsa_do_verify ( 0, &data, &p, &q, &g, &y, &r, &s, &v ) ) < 0 ) {
		PERROR("zenbridge_dsa_do_verify");
		ENGINEerr(ENGINE_F_ZENCOD_DSA_DO_VERIFY, ENGINE_R_REQUEST_FAILED);
		return 0;
	}

	return ( ( ret == 0 ) ? 1 : ret ) ;
}


static int DSA_zencod_bn_mod_exp ( DSA *dsa, BIGNUM *r, BIGNUM *a, const BIGNUM *p, const BIGNUM *m,
			     BN_CTX *ctx, BN_MONT_CTX *m_ctx )
{
	CHEESE();

	return zencod_bn_mod_exp ( r, a, p, m, ctx ) ;
}
#endif	/* !OPENSSL_NO_DSA */


#ifndef OPENSSL_NO_DH
static int DH_zencod_generate_key ( DH *dh )
{
	BIGNUM *bn_prv = NULL;
	BIGNUM *bn_pub = NULL;
	zen_nb_t y, x, g, p;
	int generate_x;

	CHEESE();

	if ( !zencod_dso ) {
		ENGINEerr(ENGINE_F_ZENCOD_DH_GENERATE, ENGINE_R_NOT_LOADED);
		return 0;
	}

	/* Private key */
	if ( dh->priv_key ) {
		bn_prv = dh->priv_key;
		generate_x = 0;
	} else {
		if (!(bn_prv = BN_new())) {
			ENGINEerr(ENGINE_F_ZENCOD_DH_GENERATE, ENGINE_R_BN_EXPAND_FAIL);
			goto FAILED;
		}
		generate_x = 1;
	}

	/* Public key */
	if ( dh->pub_key )
		bn_pub = dh->pub_key;
	else
		if ( !( bn_pub = BN_new () ) ) {
			ENGINEerr(ENGINE_F_ZENCOD_DH_GENERATE, ENGINE_R_BN_EXPAND_FAIL);
			goto FAILED;
		}

	/* Expand */
	if ( !bn_wexpand ( bn_prv, dh->p->dmax ) ||
	    !bn_wexpand ( bn_pub, dh->p->dmax ) ) {
		ENGINEerr(ENGINE_F_ZENCOD_DH_GENERATE, ENGINE_R_BN_EXPAND_FAIL);
		goto FAILED;
	}
	bn_prv->top = dh->p->top;
	bn_pub->top = dh->p->top;

	/* Convert all keys */
	BIGNUM2ZEN ( &p, dh->p ) ;
	BIGNUM2ZEN ( &g, dh->g ) ;
	BIGNUM2ZEN ( &y, bn_pub ) ;
	BIGNUM2ZEN ( &x, bn_prv ) ;
	x.len = DH_size(dh) * 8;

	/* Adjust the lengths of P and G */
	p.len = ptr_zencod_bytes2bits ( p.data, ZEN_BYTES ( p.len ) ) ;
	g.len = ptr_zencod_bytes2bits ( g.data, ZEN_BYTES ( g.len ) ) ;

	/* Send the request to the driver */
	if ( ptr_zencod_dh_generate_key ( &y, &x, &g, &p, generate_x ) < 0 ) {
		perror("zenbridge_dh_generate_key");
		ENGINEerr(ENGINE_F_ZENCOD_DH_GENERATE, ENGINE_R_REQUEST_FAILED);
		goto FAILED;
	}

	dh->priv_key = bn_prv;
	dh->pub_key  = bn_pub;

	return 1;

 FAILED:
	if (!dh->priv_key && bn_prv)
		BN_free(bn_prv);
	if (!dh->pub_key && bn_pub)
		BN_free(bn_pub);

	return 0;
}


static int DH_zencod_compute_key ( unsigned char *key, BIGNUM *pub_key, DH *dh )
{
	zen_nb_t y, x, p, k;

	CHEESE();

	if ( !zencod_dso ) {
		ENGINEerr(ENGINE_F_ZENCOD_DH_COMPUTE, ENGINE_R_NOT_LOADED);
		return 0;
	}

	if ( !dh->priv_key ) {
		ENGINEerr(ENGINE_F_ZENCOD_DH_COMPUTE, ENGINE_R_MISSING_KEY_COMPONENTS);
		return 0;
	}

	/* Convert all keys */
	BIGNUM2ZEN ( &y, pub_key ) ;
	BIGNUM2ZEN ( &x, dh->priv_key ) ;
	BIGNUM2ZEN ( &p, dh->p ) ;
	ptr_zencod_init_number ( &k, p.len, key ) ;

	/* Adjust the lengths */
	p.len = ptr_zencod_bytes2bits ( p.data, ZEN_BYTES ( p.len ) ) ;
	y.len = ptr_zencod_bytes2bits ( y.data, ZEN_BYTES ( y.len ) ) ;
	x.len = ptr_zencod_bytes2bits ( x.data, ZEN_BYTES ( x.len ) ) ;

	/* Call the hardware */
	if ( ptr_zencod_dh_compute_key ( &k, &y, &x, &p ) < 0 ) {
		ENGINEerr(ENGINE_F_ZENCOD_DH_COMPUTE, ENGINE_R_REQUEST_FAILED);
		return 0;
	}

	/* The key must be written MSB -> LSB */
	k.len = ptr_zencod_bytes2bits ( k.data, ZEN_BYTES ( k.len ) ) ;
	esrever ( key, ZEN_BYTES ( k.len ) ) ;

	return ZEN_BYTES(k.len);
}


static int DH_zencod_bn_mod_exp ( DH *dh, BIGNUM *r, BIGNUM *a, const BIGNUM *p, const BIGNUM *m,
			    BN_CTX *ctx, BN_MONT_CTX *m_ctx )
{
	CHEESE();

	return zencod_bn_mod_exp ( r, a, p, m, ctx ) ;
}
#endif	/* !OPENSSL_NO_DH */


/* RAND stuff
 */
static int RAND_zencod_rand_bytes ( unsigned char *buf, int num )
{
	zen_nb_t r;

	CHEESE();

	if ( !zencod_dso ) {
		ENGINEerr(ENGINE_F_ZENCOD_RAND, ENGINE_R_NOT_LOADED);
		return 0;
	}

	ptr_zencod_init_number ( &r, num * 8, buf ) ;

	if ( ptr_zencod_rand_bytes ( &r, ZENBRIDGE_RNG_DIRECT ) < 0 ) {
		PERROR("zenbridge_rand_bytes");
		ENGINEerr(ENGINE_F_ZENCOD_RAND, ENGINE_R_REQUEST_FAILED);
		return 0;
	}

	return 1;
}


static int RAND_zencod_status ( void )
{
	CHEESE();

	return 1;
}


#endif	/* !OPENSSL_NO_HW_ZENCOD */
#endif	/* !OPENSSL_NO_HW */
