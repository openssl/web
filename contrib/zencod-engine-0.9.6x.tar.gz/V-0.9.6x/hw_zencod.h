/* crypto/engine/vendor_defns/hw_zencod.h */
 /* Written by Fred Donnat (frederic.donnat@zencod.com) for "zencod"
 * engine integration in order to redirect crypto computing on a crypto
 * hardware accelerator zenssl32  ;-)
 *
 * Date : 04 Jan 2002
 * Revision : 17 Jul 2002
 * Version : zencod_engine-0.9.6x
 */

/* ====================================================================
 * Copyright (c) 1999-2001 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 * This product includes cryptographic software written by Eric Young
 * (eay@cryptsoft.com).  This product includes software written by Tim
 * Hudson (tjh@cryptsoft.com).
 *
 */


#ifndef	_HW_ZENCOD_H_
#define	_HW_ZENCOD_H_

#include <stdio.h>

#ifdef	__cplusplus
extern "C" {
#endif	/* __cplusplus */

#define ZENBRIDGE_MAX_KEYSIZE_RSA	2048
#define ZENBRIDGE_MAX_KEYSIZE_RSA_CRT	1024
#define ZENBRIDGE_MAX_KEYSIZE_DSA_SIGN	1024
#define ZENBRIDGE_MAX_KEYSIZE_DSA_VRFY	1024

/* Library version computation */
#define	ZENBRIDGE_VERSION_MAJOR(x)	(((x) >> 16) | 0xff)
#define	ZENBRIDGE_VERSION_MINOR(x)	(((x) >>  8) | 0xff)
#define	ZENBRIDGE_VERSION_PATCH(x)	(((x) >>  0) | 0xff)
#define	ZENBRIDGE_VERSION(x, y, z)		((x) << 16 | (y) << 8 | (z))

/*
 * Memory type
 */
typedef struct zencod_number_s {
	unsigned long len;
	unsigned char *data;
} zen_nb_t;

#define KEY	zen_nb_t


/*
 * Misc
 */
typedef int t_zencod_lib_version (void);
typedef int t_zencod_hw_version (void);
typedef int t_zencod_test (void);
typedef int t_zencod_dump_key (FILE *stream, char *msg, KEY *key);


/*
 * Key managment tools
 */
typedef KEY *t_zencod_new_number (unsigned long len, unsigned char *data);
typedef int t_zencod_init_number (KEY *n, unsigned long len, unsigned char *data);
typedef unsigned long t_zencod_bytes2bits (unsigned char *n, unsigned long bytes);
typedef unsigned long t_zencod_bits2bytes (unsigned long bits);


/*
 * RSA API
 */
typedef int t_zencod_rsa_mod_exp (KEY *y, KEY *x, KEY *n, KEY *e);
typedef int t_zencod_rsa_mod_exp_crt (KEY *y, KEY *x, KEY *p, KEY *q,
					KEY *edp, KEY *edq, KEY *qinv);

/*
 * DSA API
 */
typedef int t_zencod_dsa_do_sign (unsigned int hash, KEY *data, KEY *random,
				    KEY *p, KEY *q, KEY *g, KEY *x, KEY *r, KEY *s);
typedef int t_zencod_dsa_do_verify (unsigned int hash, KEY *data,
				      KEY *p, KEY *q, KEY *g, KEY *y,
				      KEY *r, KEY *s, KEY *v);
/*
 * DH API
 */
typedef int t_zencod_dh_generate_key (KEY *y, KEY *x, KEY *g, KEY *n, int gen_x);
typedef int t_zencod_dh_compute_key (KEY *k, KEY *y, KEY *x, KEY *n);


/*
 * RNG API
 */
#define ZENBRIDGE_RNG_DIRECT		0
#define ZENBRIDGE_RNG_SHA1		1
typedef int t_zencod_rand_bytes (KEY *rand, unsigned int flags);


/*
 * Math API
 */
typedef int t_zencod_math_mod_exp (KEY *r, KEY *a, KEY *e, KEY *n);

#undef KEY

#ifdef	__cplusplus
}
#endif	/* __cplusplus */

#endif	/* !_HW_ZENCOD_H_ */
