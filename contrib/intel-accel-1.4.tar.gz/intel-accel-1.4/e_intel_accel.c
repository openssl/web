/* ====================================================================
 * Copyright (c) 2011 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 */


#include <openssl/opensslconf.h>

#include <stdio.h>
#include <string.h>
#include <openssl/engine.h>
#include <openssl/evp.h>
#include <openssl/aes.h>
#include <openssl/sha.h>
#include <openssl/rc4.h>
#ifndef OPENSSL_NO_RSA
#include <openssl/rsa.h>
#endif
#include <openssl/bn.h>
#include <openssl/err.h>

#include "e_intel_accel_err.c"

/*
 * Ciphers section: AES-NI and RC4.
 */
#if !defined(EVP_CIPH_FLAG_DEFAULT_ASN1)
#define EVP_CIPH_FLAG_DEFAULT_ASN1 0
#endif

int aesni_set_encrypt_key(const unsigned char *userKey, int bits,
			      AES_KEY *key);
int aesni_set_decrypt_key(const unsigned char *userKey, int bits,
			      AES_KEY *key);

void aesni_cbc_encrypt(const unsigned char *in,
			   unsigned char *out,
			   size_t length,
			   const AES_KEY *key,
			   unsigned char *ivec, int enc);

static int
aesni_init_key(EVP_CIPHER_CTX *ctx, const unsigned char *user_key,
		    const unsigned char *iv, int enc)
{	int ret;

	if (((ctx->cipher->flags & EVP_CIPH_MODE) == EVP_CIPH_ECB_MODE
	    || (ctx->cipher->flags & EVP_CIPH_MODE) == EVP_CIPH_CBC_MODE)
	    && !enc)
		ret=aesni_set_decrypt_key(user_key, ctx->key_len * 8, ctx->cipher_data);
	else
		ret=aesni_set_encrypt_key(user_key, ctx->key_len * 8, ctx->cipher_data);

	if(ret < 0) {
		INTEL_ACCELerr(INTEL_ACCEL_F_AESNI_INIT_KEY,INTEL_ACCEL_R_AES_KEY_SETUP_FAILED);
		return 0;
	}

	if (ctx->cipher->flags&EVP_CIPH_CUSTOM_IV)
		{
		if (iv!=NULL)
			memcpy (ctx->iv,iv,ctx->cipher->iv_len);
		else	{
			INTEL_ACCELerr(INTEL_ACCEL_F_AESNI_INIT_KEY,INTEL_ACCEL_R_AES_IV_SETUP_FAILED);
			return 0;
			}
		}

	return 1;
}

static int aesni_cipher_cbc(EVP_CIPHER_CTX *ctx, unsigned char *out,
		 const unsigned char *in, size_t inl)
{	aesni_cbc_encrypt(in, out, inl, ctx->cipher_data,
			      ctx->iv, ctx->encrypt);
	return 1;
}

#define	DECLARE_AES_EVP(ksize,lmode,umode)		\
static const EVP_CIPHER aesni_##ksize##_##lmode = {	\
	NID_aes_##ksize##_##lmode,			\
	16, ksize / 8, 16,				\
	EVP_CIPH_FLAG_DEFAULT_ASN1|EVP_CIPH_##umode##_MODE,		\
	aesni_init_key,					\
	aesni_cipher_##lmode,				\
	NULL,						\
	sizeof(AES_KEY),				\
	EVP_CIPH_FLAG_DEFAULT_ASN1?NULL:EVP_CIPHER_set_asn1_iv,		\
	EVP_CIPH_FLAG_DEFAULT_ASN1?NULL:EVP_CIPHER_get_asn1_iv,		\
	NULL,						\
	NULL						\
}

DECLARE_AES_EVP(128,cbc,CBC);
DECLARE_AES_EVP(192,cbc,CBC);
DECLARE_AES_EVP(256,cbc,CBC);

static int rc4_init_key(EVP_CIPHER_CTX *ctx, const unsigned char *key,
			const unsigned char *iv, int enc)
{	RC4_set_key(ctx->cipher_data,EVP_CIPHER_CTX_key_length(ctx),key);
	return 1;
}

static int rc4_cipher(EVP_CIPHER_CTX *ctx, unsigned char *out,
			const unsigned char *in, size_t len)
{	RC4(ctx->cipher_data,len,in,out);
	return 1;
}

static const EVP_CIPHER rc4 =
	{
	NID_rc4,
	1,16,0,
	EVP_CIPH_VARIABLE_LENGTH,
	rc4_init_key,
	rc4_cipher,
	NULL,
	sizeof(int)*(256+2),
	NULL,
	NULL,
	NULL,
	NULL
	};

static int cipher_nids[16];
static const EVP_CIPHER *cipher_evps[16];
static int cipher_num = 0;

static int
intel_accel_ciphers (ENGINE *e, const EVP_CIPHER **cipher,
		      const int **nids, int nid)
{	int i;

	/* No specific cipher => return a list of supported nids ... */
	if (!cipher) {
		*nids = cipher_nids;
		return cipher_num;
	}

	for (i=0;i<cipher_num;i++) {
		if (cipher_nids[i]==nid) {
			*cipher = cipher_evps[i];
			return 1;
		}
	}

	return 0;
}

/*
 * Digests section: SHA1
 */
void sha1_block_data_order (void *c,const void *p,size_t len);

static int sha1_init(EVP_MD_CTX *ctx)
{	return SHA1_Init(ctx->md_data);		}

static int sha1_update(EVP_MD_CTX *ctx,const void *data,size_t len)
{	SHA_CTX *c = ctx->md_data;
	const unsigned char *ptr = data;
	size_t res;

	if ((res = c->num)) {
		res = SHA_CBLOCK-res;
		if (len<res) res=len;
		SHA1_Update (c,ptr,res);
		ptr += res;
		len -= res;
	}

	res = len % SHA_CBLOCK;
	len -= res;

	if (len) {
		sha1_block_data_order(c,ptr,len/SHA_CBLOCK);

		ptr += len;
		c->Nh += len>>29;
		c->Nl += len<<=3;
		if (c->Nl<(unsigned int)len) c->Nh++;
	}

	if (res)
		SHA1_Update(c,ptr,res);

	return 1;
}

#define l2c(l,c)	({ unsigned int r=(l);				\
			   asm ("bswapl %0" : "=r"(r) : "0"(r));	\
			   *((unsigned int *)(c))=r;			})

static int sha1_final(EVP_MD_CTX *ctx,unsigned char *md)
#if OPENSSL_VERSION_NUMBER < 0x00908000
{	return SHA1_Final(md,ctx->md_data);	}
#else
{	SHA_CTX *c = ctx->md_data;
	unsigned char final[2*SHA_CBLOCK],*len;
	size_t num = c->num;
	unsigned int *h;

	memset(final,0,sizeof(final));
	if (num) memcpy(final,c->data,num);

	final[num++]=0x80;
	if ((SHA_CBLOCK-num)>=8) {
		len=final+SHA_CBLOCK-8;
		num=1;
	} else {
		len=final+2*SHA_CBLOCK-8;
		num=2;
	}
	l2c(c->Nh,len); l2c(c->Nl,len+4);

	sha1_block_data_order(c,final,num);

	h = (unsigned int *)c;
	l2c(h[0],md), l2c(h[1],md+4), l2c(h[2],md+8), l2c(h[3],md+12), l2c(h[4],md+16);

	return 1;
}
#endif

static const EVP_MD sha1_md=
	{
	NID_sha1,
	NID_sha1WithRSAEncryption,
	SHA_DIGEST_LENGTH,
#ifdef EVP_MD_FLAG_PKEY_METHOD_SIGNATURE
	EVP_MD_FLAG_PKEY_METHOD_SIGNATURE |
#endif
#ifdef EVP_MD_FLAG_DIGALGID_ABSENT
	EVP_MD_FLAG_DIGALGID_ABSENT |
#endif
	0,
	sha1_init,
	sha1_update,
	sha1_final,
	NULL,
	NULL,
	EVP_PKEY_NULL_method,
	SHA_CBLOCK,
	sizeof(SHA_CTX),
	};

static int md_nids[1];
static const EVP_MD *md_evps[1];
static int md_num = 0;

static int
intel_accel_digests (ENGINE *e, const EVP_MD **digest,
		      const int **nids, int nid)
{
	int i;

	/* No specific cipher => return a list of supported nids ... */
	if (!digest) {
		*nids = md_nids;
		return md_num;
	}

	for (i=0;i<md_num;i++) {
		if (md_nids[i]==nid) {
			*digest = md_evps[i];
			return 1;
		}
	}

	return 0;
}

/*
 * RDRAND section
 */
size_t OPENSSL_ia32_rdrand(void);

static int intel_accel_get_random_bytes (unsigned char *buf, size_t num)
{
	size_t rnd;

	while (num>=sizeof(size_t)) {
		if ((rnd = OPENSSL_ia32_rdrand()) == 0) return 0;

		*((size_t *)buf) = rnd;
		buf += sizeof(size_t);
		num -= sizeof(size_t);
	}
	if (num) {
		if ((rnd = OPENSSL_ia32_rdrand()) == 0) return 0;

		memcpy (buf,&rnd,num);
	}

	return 1;
}

static int intel_accel_random_status (void)
{	return 1;	}

static RAND_METHOD intel_accel_rand =
	{
	NULL,	/* seed */
	intel_accel_get_random_bytes,
	NULL,	/* cleanup */
	NULL,	/* add */
	intel_accel_get_random_bytes,
	intel_accel_random_status,
	};

#if !defined(__x86_64) && !defined(__x86_64__)
#define OPENSSL_NO_RSA
#endif
/*
 * RSA section
 *
 * Copyright (c) 2010-2010 Intel Corp.
 *  Authors: Vinodh.Gopal@intel.com
 *           Jim.Guilford@intel.com
 *           Erdinc.Ozturk@intel.com
 *           Maxim.Perminov@intel.com
 *           Ying.Huang@intel.com
 *
 * More information about algorithm used can be found at:
 *   http://www.cse.buffalo.edu/srds2009/escs2009_submission_Gopal.pdf
 */

#ifndef OPENSSL_NO_RSA
/* Used to attach our own key-data to an RSA structure */
static int rsax_ex_data_idx = -1;

#ifdef _WIN32
typedef unsinged __int64 UINT64;
#else
typedef unsigned long long UINT64;
#endif
typedef unsigned short UINT16;

/* Table t is interleaved in the following manner:
 * The order in memory is t[0][0], t[0][1], ..., t[0][7], t[1][0], ...
 * A particular 512-bit value is stored in t[][index] rather than the more
 * normal t[index][]; i.e. the qwords of a particular entry in t are not
 * adjacent in memory
 */

/* Init BIGNUM b from the interleaved UINT64 array */
static int interleaved_array_to_bn_512(BIGNUM* b, UINT64 *array);

/* Extract array elements from BIGNUM b
 * To set the whole array from b, call with n=8
 */
static int bn_extract_to_array_512(const BIGNUM* b, unsigned int n, UINT64 *array);

struct mod_ctx_512 {
    UINT64 t[8][8];
    UINT64 m[8];
    UINT64 m1[8]; /* 2^278 % m */
    UINT64 m2[8]; /* 2^640 % m */
    UINT64 k1[2]; /* (- 1/m) % 2^128 */
};

static int mod_exp_pre_compute_data_512(UINT64 *m, struct mod_ctx_512 *data);

void mod_exp_512(UINT64 *result, /* 512 bits, 8 qwords */
		 UINT64 *g,      /* 512 bits, 8 qwords */
		 UINT64 *exp,    /* 512 bits, 8 qwords */
		 struct mod_ctx_512 *data);

typedef struct st_e_rsax_mod_ctx
{
  UINT64 type;
  union {
    struct mod_ctx_512  b512;
  } ctx;

} E_RSAX_MOD_CTX;

static E_RSAX_MOD_CTX *e_rsax_get_ctx(RSA *rsa, int idx, BIGNUM* m)
{
    E_RSAX_MOD_CTX *hptr;

    if (idx < 0 || idx > 2)
        return NULL;

	hptr = RSA_get_ex_data(rsa, rsax_ex_data_idx);
	if (!hptr) {
	    hptr = OPENSSL_malloc(3*sizeof(E_RSAX_MOD_CTX));
	    if (!hptr) return NULL;
        hptr[2].type = hptr[1].type= hptr[0].type = 0;
	    RSA_set_ex_data(rsa, rsax_ex_data_idx, hptr);
        }

    if (hptr[idx].type == BN_num_bits(m))
        return hptr+idx;

    if (BN_num_bits(m) == 512) {
  	    UINT64 _m[8];
	    bn_extract_to_array_512(m, 8, _m);
	    memset( &hptr[idx].ctx.b512, 0, sizeof(struct mod_ctx_512));
	    mod_exp_pre_compute_data_512(_m, &hptr[idx].ctx.b512);
	}

    hptr[idx].type = BN_num_bits(m);
	return hptr+idx;
}

static int e_rsax_rsa_finish(RSA *rsa)
{
	E_RSAX_MOD_CTX *hptr = RSA_get_ex_data(rsa, rsax_ex_data_idx);
	if(!hptr) return 0;

	OPENSSL_free(hptr);
	RSA_set_ex_data(rsa, rsax_ex_data_idx, NULL);
	return 1;
}


static int e_rsax_bn_mod_exp(BIGNUM *r, const BIGNUM *g, const BIGNUM *e,
                    const BIGNUM *m, BN_CTX *ctx, BN_MONT_CTX *in_mont, E_RSAX_MOD_CTX* rsax_mod_ctx )
{
    if (rsax_mod_ctx && BN_get_flags(e, BN_FLG_CONSTTIME) != 0) {
		if (BN_num_bits(m) == 512) {
           UINT64 _r[8];
           UINT64 _g[8];
           UINT64 _e[8];

           /* Init the arrays from the BIGNUMs */
           bn_extract_to_array_512(g, 8, _g);
           bn_extract_to_array_512(e, 8, _e);
         
           mod_exp_512(_r, _g, _e, &rsax_mod_ctx->ctx.b512);
           /* Return the result in the BIGNUM */
           interleaved_array_to_bn_512(r, _r);
           return 1;
        } 
    }

	return BN_mod_exp_mont(r, g, e, m, ctx, in_mont);
}

/* Declares for the Intel CIAP 512-bit / CRT / 1024 bit RSA modular
 * exponentiation routine precalculations and a structure to hold the
 * necessary values.  These files are meant to live in crypto/rsa/ in
 * the target openssl.
 */

/*
 * Local method: extracts a piece from a BIGNUM, to fit it into
 * an array. Call with n=8 to extract an entire 512-bit BIGNUM
 */
static int bn_extract_to_array_512(const BIGNUM* b, unsigned int n, UINT64 *array)
{
	int i;
	UINT64 tmp;
	unsigned char bn_buff[64];
	memset(bn_buff, 0, 64);
	if (BN_num_bytes(b) > 64) {
		INTEL_ACCELerr(INTEL_ACCEL_F_BN_EXTRACT_TO_ARRAY_512,INTEL_ACCEL_R_UNSUPPORTED_SIZE);
		return 0; }
	if (BN_num_bytes(b)!=0) {
		if (!BN_bn2bin(b, bn_buff+(64-BN_num_bytes(b)))) {
			INTEL_ACCELerr(INTEL_ACCEL_F_BN_EXTRACT_TO_ARRAY_512,INTEL_ACCEL_R_BN2BIN_FAILED);
			/* We have to error, here */
			return 0; } }
	while (n-- > 0) {
		array[n] = 0;
		for (i=7; i>=0; i--) {
			tmp = bn_buff[63-(n*8+i)];
			array[n] |= tmp << (8*i); } }
	return 1;
}

/* Init a 512-bit BIGNUM from the UINT64*_ (8 * 64) interleaved array */
static int interleaved_array_to_bn_512(BIGNUM* b, UINT64 *array)
{
	unsigned char tmp[64];
	int n=8;
	int i;
	while (n-- > 0) {
		for (i = 7; i>=0; i--) {
			tmp[63-(n*8+i)] = (unsigned char)(array[n]>>(8*i)); } }
	BN_bin2bn(tmp, 64, b);
    return 0;
}


/* The main 512bit precompute call */
static int mod_exp_pre_compute_data_512(UINT64 *m, struct mod_ctx_512 *data)
{
    BIGNUM two_768, two_640, two_128, two_512, tmp, _m, tmp2;

    /* We need a BN_CTX for the modulo functions */
    BN_CTX* ctx;
    /* Some tmps */
    UINT64 _t[8];
    int i, j, ret = 0;

    /* Init _m with m */
    BN_init(&_m);
    interleaved_array_to_bn_512(&_m, m);
    memset(_t, 0, 64);

    /* Inits */
    BN_init(&two_768);
    BN_init(&two_640);
    BN_init(&two_128);
    BN_init(&two_512);
    BN_init(&tmp);
    BN_init(&tmp2);

    /* Create our context */
    if ((ctx=BN_CTX_new()) == NULL) { goto err; }
	BN_CTX_start(ctx);

    /*
     * For production, if you care, these only need to be set once,
     * and may be made constants.
     */
    BN_lshift(&two_768, BN_value_one(), 768);
    BN_lshift(&two_640, BN_value_one(), 640);
    BN_lshift(&two_128, BN_value_one(), 128);
    BN_lshift(&two_512, BN_value_one(), 512);

    if (0 == (m[7] & 0x8000000000000000)) {
        exit(1);
    }
    if (0 == (m[0] & 0x1)) { /* Odd modulus required for Mont */
        exit(1);
    }

    /* Precompute m1 */
    BN_mod(&tmp, &two_768, &_m, ctx);
    if (!bn_extract_to_array_512(&tmp, 8, &data->m1[0])) {
	    goto err; }

    /* Precompute m2 */
    BN_mod(&tmp, &two_640, &_m, ctx);
    if (!bn_extract_to_array_512(&tmp, 8, &data->m2[0])) {
	    goto err;
    }

    /*
     * Precompute k1, a 128b number = ((-1)* m-1 ) mod 2128; k1 should
     * be non-negative.
     */
    BN_mod_inverse(&tmp, &_m, &two_128, ctx);
    if (!BN_is_zero(&tmp)) { BN_sub(&tmp, &two_128, &tmp); }
    if (!bn_extract_to_array_512(&tmp, 2, &data->k1[0])) {
	    goto err; }

    /* Precompute t */
    for (i=0; i<8; i++) {
        BN_zero(&tmp);
        if (i & 1) { BN_add(&tmp, &two_512, &tmp); }
        if (i & 2) { BN_add(&tmp, &two_512, &tmp); }
        if (i & 4) { BN_add(&tmp, &two_640, &tmp); }

        BN_nnmod(&tmp2, &tmp, &_m, ctx);
        if (!bn_extract_to_array_512(&tmp2, 8, _t)) {
	        goto err; }
        for (j=0; j<8; j++) data->t[j][i] = _t[j]; }

    /* Precompute m */
    for (i=0; i<8; i++) {
        data->m[i] = m[i]; }

    ret = 1;

err:
    /* Cleanup */
	if (ctx != NULL) {
		BN_CTX_end(ctx); }
    BN_free(&two_768);
    BN_free(&two_640);
    BN_free(&two_128);
    BN_free(&two_512);
    BN_free(&tmp);
    BN_free(&tmp2);
    BN_free(&_m);

    return ret;
}


static int e_rsax_rsa_mod_exp(BIGNUM *r0, const BIGNUM *I, RSA *rsa, BN_CTX *ctx)
	{
	BIGNUM *r1,*m1,*vrfy;
	BIGNUM local_dmp1,local_dmq1,local_c,local_r1;
	BIGNUM *dmp1,*dmq1,*c,*pr1;
	int ret=0;

	BN_CTX_start(ctx);
	r1 = BN_CTX_get(ctx);
	m1 = BN_CTX_get(ctx);
	vrfy = BN_CTX_get(ctx);

	{
		BIGNUM local_p, local_q;
		BIGNUM *p = NULL, *q = NULL;
		int error = 0;

		/* Make sure BN_mod_inverse in Montgomery
		 * intialization uses the BN_FLG_CONSTTIME flag
		 * (unless RSA_FLAG_NO_CONSTTIME is set)
		 */
		if (!(rsa->flags & RSA_FLAG_NO_CONSTTIME))
			{
			BN_init(&local_p);
			p = &local_p;
			BN_with_flags(p, rsa->p, BN_FLG_CONSTTIME);

			BN_init(&local_q);
			q = &local_q;
			BN_with_flags(q, rsa->q, BN_FLG_CONSTTIME);
			}
		else
			{
			p = rsa->p;
			q = rsa->q;
			}

		if (rsa->flags & RSA_FLAG_CACHE_PRIVATE)
			{
			if (!BN_MONT_CTX_set_locked(&rsa->_method_mod_p, CRYPTO_LOCK_RSA, p, ctx))
			    error = 1;
			if (!BN_MONT_CTX_set_locked(&rsa->_method_mod_q, CRYPTO_LOCK_RSA, q, ctx))
			    error = 1;
			}

		/* clean up */
		if (!(rsa->flags & RSA_FLAG_NO_CONSTTIME))
			{
			BN_free(&local_p);
			BN_free(&local_q);
			}
		if ( error )
			goto err;
	}

	if (rsa->flags & RSA_FLAG_CACHE_PUBLIC)
		if (!BN_MONT_CTX_set_locked(&rsa->_method_mod_n, CRYPTO_LOCK_RSA, rsa->n, ctx))
			goto err;

	/* compute I mod q */
	if (!(rsa->flags & RSA_FLAG_NO_CONSTTIME))
		{
		c = &local_c;
		BN_with_flags(c, I, BN_FLG_CONSTTIME);
		if (!BN_mod(r1,c,rsa->q,ctx)) goto err;
		}
	else
		{
		if (!BN_mod(r1,I,rsa->q,ctx)) goto err;
		}

	/* compute r1^dmq1 mod q */
	if (!(rsa->flags & RSA_FLAG_NO_CONSTTIME))
		{
		dmq1 = &local_dmq1;
		BN_with_flags(dmq1, rsa->dmq1, BN_FLG_CONSTTIME);
		}
	else
		dmq1 = rsa->dmq1;

	if (!e_rsax_bn_mod_exp(m1,r1,dmq1,rsa->q,ctx,
		rsa->_method_mod_q, e_rsax_get_ctx(rsa, 0, rsa->q) )) goto err;

	/* compute I mod p */
	if (!(rsa->flags & RSA_FLAG_NO_CONSTTIME))
		{
		c = &local_c;
		BN_with_flags(c, I, BN_FLG_CONSTTIME);
		if (!BN_mod(r1,c,rsa->p,ctx)) goto err;
		}
	else
		{
		if (!BN_mod(r1,I,rsa->p,ctx)) goto err;
		}

	/* compute r1^dmp1 mod p */
	if (!(rsa->flags & RSA_FLAG_NO_CONSTTIME))
		{
		dmp1 = &local_dmp1;
		BN_with_flags(dmp1, rsa->dmp1, BN_FLG_CONSTTIME);
		}
	else
		dmp1 = rsa->dmp1;

	if (!e_rsax_bn_mod_exp(r0,r1,dmp1,rsa->p,ctx,
		rsa->_method_mod_p, e_rsax_get_ctx(rsa, 1, rsa->p) )) goto err;

	if (!BN_sub(r0,r0,m1)) goto err;
	/* This will help stop the size of r0 increasing, which does
	 * affect the multiply if it optimised for a power of 2 size */
	if (BN_is_negative(r0))
		if (!BN_add(r0,r0,rsa->p)) goto err;

	if (!BN_mul(r1,r0,rsa->iqmp,ctx)) goto err;

	/* Turn BN_FLG_CONSTTIME flag on before division operation */
	if (!(rsa->flags & RSA_FLAG_NO_CONSTTIME))
		{
		pr1 = &local_r1;
		BN_with_flags(pr1, r1, BN_FLG_CONSTTIME);
		}
	else
		pr1 = r1;
	if (!BN_mod(r0,pr1,rsa->p,ctx)) goto err;

	/* If p < q it is occasionally possible for the correction of
         * adding 'p' if r0 is negative above to leave the result still
	 * negative. This can break the private key operations: the following
	 * second correction should *always* correct this rare occurrence.
	 * This will *never* happen with OpenSSL generated keys because
         * they ensure p > q [steve]
         */
	if (BN_is_negative(r0))
		if (!BN_add(r0,r0,rsa->p)) goto err;
	if (!BN_mul(r1,r0,rsa->q,ctx)) goto err;
	if (!BN_add(r0,r1,m1)) goto err;

	if (rsa->e && rsa->n)
		{
		if (!e_rsax_bn_mod_exp(vrfy,r0,rsa->e,rsa->n,ctx,rsa->_method_mod_n, e_rsax_get_ctx(rsa, 2, rsa->n) ))
                    goto err;

		/* If 'I' was greater than (or equal to) rsa->n, the operation
		 * will be equivalent to using 'I mod n'. However, the result of
		 * the verify will *always* be less than 'n' so we don't check
		 * for absolute equality, just congruency. */
		if (!BN_sub(vrfy, vrfy, I)) goto err;
		if (!BN_mod(vrfy, vrfy, rsa->n, ctx)) goto err;
		if (BN_is_negative(vrfy))
			if (!BN_add(vrfy, vrfy, rsa->n)) goto err;
		if (!BN_is_zero(vrfy))
			{
			/* 'I' and 'vrfy' aren't congruent mod n. Don't leak
			 * miscalculated CRT output, just do a raw (slower)
			 * mod_exp and return that instead. */

			BIGNUM local_d;
			BIGNUM *d = NULL;

			if (!(rsa->flags & RSA_FLAG_NO_CONSTTIME))
				{
				d = &local_d;
				BN_with_flags(d, rsa->d, BN_FLG_CONSTTIME);
				}
			else
				d = rsa->d;
			if (!e_rsax_bn_mod_exp(r0,I,d,rsa->n,ctx,
						   rsa->_method_mod_n, e_rsax_get_ctx(rsa, 2, rsa->n) )) goto err;
			}
		}
	ret = 1;

err:
	BN_CTX_end(ctx);

	return ret;
}

/* Our internal RSA_METHOD that we provide pointers to */
static RSA_METHOD e_rsax_rsa =
	{
	"Intel RSA-X method",
	NULL,
	NULL,
	NULL,
	NULL,
	e_rsax_rsa_mod_exp,
	NULL,
	NULL,
	e_rsax_rsa_finish,
	RSA_FLAG_CACHE_PUBLIC|RSA_FLAG_CACHE_PRIVATE,
	NULL,
	NULL,
	NULL
	};
#endif


/*
 * Engine "management" section
 */
static const char   intel_accel_id[] = "intel-accel",
		    intel_accel_name[] = "Intel Accelerator engine";

static int intel_accel_init(ENGINE *e)
{
#ifndef OPENSSL_NO_RSA
	if (rsax_ex_data_idx == -1)
		rsax_ex_data_idx = RSA_get_ex_new_index(0,
			NULL,
			NULL, NULL, NULL);

	if (rsax_ex_data_idx  == -1)
		return 0;
#endif
	return 1;
}

static int intel_accel_destroy(ENGINE *e)
{	ERR_unload_INTEL_ACCEL_strings();
	return 1;
}

static int intel_accel_finish(ENGINE *e)
{	return 1;	}

unsigned int OPENSSL_ia32cap_P[2];

void OPENSSL_cpuid_setup()
{
	unsigned long long OPENSSL_ia32_cpuid();
	unsigned long long vec = OPENSSL_ia32_cpuid();

	OPENSSL_ia32cap_P[0] = vec;
	OPENSSL_ia32cap_P[1] = vec>>32;
}

int bind_engine(ENGINE *e, const char *id, const dynamic_fns *fns)
{	int nid;
#ifndef OPENSSL_NO_RSA
	const RSA_METHOD *meth1;
#endif
	static int inited=0;

	if (id && strcmp(id,intel_accel_id))
		return 0;

					if (!inited) {
	OPENSSL_cpuid_setup();

	if (OPENSSL_ia32cap_P[1] & (1 << (57-32))) {
	    if ((nid=OBJ_txt2nid("aes-128-cbc"))!=NID_undef) {
		cipher_nids[cipher_num] = nid;
		cipher_evps[cipher_num] = &aesni_128_cbc;
		cipher_num++;
	    }
	    if ((nid=OBJ_txt2nid("aes-192-cbc"))!=NID_undef) {
		cipher_nids[cipher_num] = nid;
		cipher_evps[cipher_num] = &aesni_192_cbc;
		cipher_num++;
	    }
	    if ((nid=OBJ_txt2nid("aes-256-cbc"))!=NID_undef) {
		cipher_nids[cipher_num] = nid;
		cipher_evps[cipher_num] = &aesni_256_cbc;
		cipher_num++;
	    }
	    if ((nid=OBJ_create("1.3.6.1.4.1.16604.5524563.4277587.128.1397244209",
		"AES-128-CBC-HMAC-SHA1","aes-128-cbc-hmac-sha1"))!=NID_undef) {
		EVP_CIPHER *EVP_aesni_128_cbc_hmac_sha1();
		EVP_CIPHER *evp = EVP_aesni_128_cbc_hmac_sha1();

		cipher_nids[cipher_num] = evp->nid = nid;
		cipher_evps[cipher_num] = evp;
		cipher_num++;
		EVP_add_cipher(evp);
	    }
	    if ((nid=OBJ_create("1.3.6.1.4.1.16604.5524563.4277587.256.1397244209",
		"AES-256-CBC-HMAC-SHA1","aes-256-cbc-hmac-sha1"))!=NID_undef) {
		EVP_CIPHER *EVP_aesni_256_cbc_hmac_sha1();
		EVP_CIPHER *evp = EVP_aesni_256_cbc_hmac_sha1();

		cipher_nids[cipher_num] = evp->nid = nid;
		cipher_evps[cipher_num] = evp;
		cipher_num++;
		EVP_add_cipher(evp);
	    }
	}

	if ((nid=OBJ_txt2nid("rc4"))!=NID_undef) {
		cipher_nids[cipher_num] = nid;
		cipher_evps[cipher_num] = &rc4;
		cipher_num++;
	}
	if ((nid=OBJ_create("1.3.6.1.4.1.16604.5524563.5391156.5063733",
		"RC4-HMAC-MD5","rc4-hmac-md5"))!=NID_undef) {
		EVP_CIPHER *EVP_rc4_hmac_md5();
		EVP_CIPHER *evp = EVP_rc4_hmac_md5();

		cipher_nids[cipher_num] = evp->nid = nid;
		cipher_evps[cipher_num] = evp;
		cipher_num++;
		EVP_add_cipher(evp);
	}

	if ((nid=OBJ_txt2nid("sha1"))!=NID_undef) {
		md_nids[md_num] = nid;
		md_evps[md_num] = &sha1_md;
		md_num++;
	}

#ifndef OPENSSL_NO_RSA
	meth1 = RSA_PKCS1_SSLeay();
	e_rsax_rsa.rsa_pub_enc = meth1->rsa_pub_enc;
	e_rsax_rsa.rsa_pub_dec = meth1->rsa_pub_dec;
	e_rsax_rsa.rsa_priv_enc = meth1->rsa_priv_enc;
	e_rsax_rsa.rsa_priv_dec = meth1->rsa_priv_dec;
	e_rsax_rsa.bn_mod_exp = meth1->bn_mod_exp;
#endif

	ERR_load_INTEL_ACCEL_strings();
					} else inited=1;

	/* Register everything or return with an error */
	if (!ENGINE_set_id(e, intel_accel_id)			||
	    !ENGINE_set_name(e, intel_accel_name)		||
	    !ENGINE_set_init_function(e, intel_accel_init)	||
	    !ENGINE_set_finish_function(e, intel_accel_finish)	||
	    !ENGINE_set_destroy_function(e, intel_accel_destroy)||
#ifndef OPENSSL_NO_RSA
	    !ENGINE_set_RSA(e, &e_rsax_rsa)			||
#endif
	    ((OPENSSL_ia32cap_P[1] & (1<<(62-32))) &&
	     !ENGINE_set_RAND(e, &intel_accel_rand))		||
	    (md_num && !ENGINE_set_digests(e, intel_accel_digests))	||
	    (cipher_num && !ENGINE_set_ciphers (e, intel_accel_ciphers))
	    )
		return 0;

	/* Everything looks good, so stick around */
	ENGINE_set_flags(e,ENGINE_get_flags(e)&~ENGINE_FLAGS_BY_ID_COPY);
	ENGINE_add(e);
	ERR_clear_error();
	return 1;
}

IMPLEMENT_DYNAMIC_CHECK_FN()
